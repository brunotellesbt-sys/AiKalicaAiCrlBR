#include "global.h"
#include "data/journey_atlas_runtime.h"
#include "journey_sevii_surf.h"
#include "battle_pyramid.h"
#include "bg.h"
#include "fieldmap.h"
#include "fldeff.h"
#include "fldeff_misc.h"
#include "frontier_util.h"
#include "menu.h"
#include "mirage_tower.h"
#include "overworld.h"
#include "palette.h"
#include "pokenav.h"
#include "script.h"
#include "secret_base.h"
#include "trainer_hill.h"
#include "tv.h"
#include "tilesets.h"
#include "constants/rgb.h"
#include "constants/metatile_behaviors.h"
#include "constants/metatile_behaviors_frlg.h"
#include "wild_encounter.h"
#include "data/journey_atlas_physical.h"

struct ConnectionFlags
{
    u8 south:1;
    u8 north:1;
    u8 west:1;
    u8 east:1;
};

EWRAM_DATA u16 ALIGNED(4) sBackupMapData[MAX_MAP_DATA_SIZE] = {0};
EWRAM_DATA struct MapHeader gMapHeader = {0};
EWRAM_DATA struct Camera gCamera = {0};
EWRAM_DATA static struct ConnectionFlags sMapConnectionFlags = {0};

COMMON_DATA struct BackupMapLayout gBackupMapLayout = {0};

static const struct ConnectionFlags sDummyConnectionFlags = {0};

static void InitMapLayoutData(struct MapHeader *mapHeader);
static void InitBackupMapLayoutData(const u16 *map, u16 width, u16 height);
static void FillSouthConnection(struct MapHeader const *mapHeader, struct MapHeader const *connectedMapHeader, s32 offset);
static void FillNorthConnection(struct MapHeader const *mapHeader, struct MapHeader const *connectedMapHeader, s32 offset);
static void FillWestConnection(struct MapHeader const *mapHeader, struct MapHeader const *connectedMapHeader, s32 offset);
static void FillEastConnection(struct MapHeader const *mapHeader, struct MapHeader const *connectedMapHeader, s32 offset);
static void InitBackupMapLayoutConnections(struct MapHeader *mapHeader);
static void JourneyAtlasFillPhysicalView(const struct MapHeader *current);
static void LoadSavedMapView(void);
static void ClearSavedMapView(void);
static bool8 SkipCopyingMetatileFromSavedMap(u16 *mapBlock, u16 mapWidth, u8 yMode);
static const struct MapConnection *GetIncomingConnection(enum Connection direction, int x, int y);
static bool8 IsPosInIncomingConnectingMap(enum Connection direction, int x, int y, const struct MapConnection *connection);
static bool8 IsCoordInIncomingConnectingMap(int coord, int srcMax, int destMax, int offset);

#include "journey_dewford_coast.h"

static inline u16 GetBorderBlockAt(int x, int y)
{
    const struct MapLayout *mapLayout = gMapHeader.mapLayout;
    u16 coastBlock;
    if (JourneyDewfordSouthBorderBlock(x, y, &coastBlock))
        return coastBlock;

    if (mapLayout->isFrlg)
    {
        s32 xprime;
        s32 yprime;

        xprime = x - MAP_OFFSET;
        xprime += 8 * mapLayout->borderWidth;
        xprime %= mapLayout->borderWidth;

        yprime = y - MAP_OFFSET;
        yprime += 8 * mapLayout->borderHeight;
        yprime %= mapLayout->borderHeight;

        return mapLayout->border[xprime + yprime * mapLayout->borderWidth] | MAPGRID_COLLISION_MASK;
    }

    int i = (x + 1) & 1;
    i += ((y + 1) & 1) * 2;
    return gMapHeader.mapLayout->border[i] | MAPGRID_IMPASSABLE;
}

#define AreCoordsWithinMapGridBounds(x, y) (x >= 0 && x < gBackupMapLayout.width && y >= 0 && y < gBackupMapLayout.height)

#define GetMapGridBlockAt(x, y) (AreCoordsWithinMapGridBounds(x, y) ? gBackupMapLayout.map[x + gBackupMapLayout.width * y] : GetBorderBlockAt(x, y))

// Masks/shifts for metatile attributes
// This is the format of the data stored in each data/tilesets/*/*/metatile_attributes.bin file
static const u32 sMetatileAttrMasks[METATILE_ATTRIBUTE_COUNT] = {
    [METATILE_ATTRIBUTE_BEHAVIOR]       = METATILE_ATTR_BEHAVIOR_MASK_FRLG, // Bits 0-8
    [METATILE_ATTRIBUTE_TERRAIN]        = 0x00003e00, // Bits 9-13
    [METATILE_ATTRIBUTE_2]              = 0x0003c000, // Bits 14-17
    [METATILE_ATTRIBUTE_3]              = 0x00fc0000, // Bits 18-23
    [METATILE_ATTRIBUTE_ENCOUNTER_TYPE] = 0x07000000, // Bits 24-26
    [METATILE_ATTRIBUTE_5]              = 0x18000000, // Bits 27-28
    [METATILE_ATTRIBUTE_LAYER_TYPE]     = METATILE_ATTR_LAYER_MASK_FRLG, // Bits 29-30
    [METATILE_ATTRIBUTE_7]              = 0x80000000  // Bit  31
};

static const u8 sMetatileAttrShifts[METATILE_ATTRIBUTE_COUNT] = {
    [METATILE_ATTRIBUTE_BEHAVIOR]       = METATILE_ATTR_BEHAVIOR_SHIFT_FRLG,
    [METATILE_ATTRIBUTE_TERRAIN]        = 9,
    [METATILE_ATTRIBUTE_2]              = 14,
    [METATILE_ATTRIBUTE_3]              = 18,
    [METATILE_ATTRIBUTE_ENCOUNTER_TYPE] = 24,
    [METATILE_ATTRIBUTE_5]              = 27,
    [METATILE_ATTRIBUTE_LAYER_TYPE]     = METATILE_ATTR_LAYER_SHIFT_FRLG,
    [METATILE_ATTRIBUTE_7]              = 31
};

static const u32 sMetatileAttrMasksEmerald[METATILE_ATTRIBUTE_COUNT] = {

    [METATILE_ATTRIBUTE_BEHAVIOR]       = METATILE_ATTR_BEHAVIOR_MASK,
    [METATILE_ATTRIBUTE_TERRAIN]        = 0xFFFFFFFF,
    [METATILE_ATTRIBUTE_2]              = 0xFFFFFFFF,
    [METATILE_ATTRIBUTE_3]              = 0xFFFFFFFF,
    [METATILE_ATTRIBUTE_ENCOUNTER_TYPE] = 0xFFFFFFFF,
    [METATILE_ATTRIBUTE_5]              = 0xFFFFFFFF,
    [METATILE_ATTRIBUTE_LAYER_TYPE]     = METATILE_ATTR_LAYER_MASK,
    [METATILE_ATTRIBUTE_7]              = 0xFFFFFFFF
};

static const u8 sMetatileAttrShiftsEmerald[METATILE_ATTRIBUTE_COUNT] = {

    [METATILE_ATTRIBUTE_BEHAVIOR]       = METATILE_ATTR_BEHAVIOR_SHIFT,
    [METATILE_ATTRIBUTE_TERRAIN]        = 0,
    [METATILE_ATTRIBUTE_2]              = 0,
    [METATILE_ATTRIBUTE_3]              = 0,
    [METATILE_ATTRIBUTE_ENCOUNTER_TYPE] = 0,
    [METATILE_ATTRIBUTE_5]              = 0,
    [METATILE_ATTRIBUTE_LAYER_TYPE]     = METATILE_ATTR_LAYER_SHIFT,
    [METATILE_ATTRIBUTE_7]              = 0
};

const struct MapHeader *const GetMapHeaderFromConnection(const struct MapConnection *connection)
{
    return Overworld_GetMapHeaderByGroupAndId(connection->mapGroup, connection->mapNum);
}

#include "journey_dewford_coast_view.h"

void InitMap(void)
{
    InitMapLayoutData(&gMapHeader);
    SetOccupiedSecretBaseEntranceMetatiles(gMapHeader.events);
    RunOnLoadMapScript();
}

void InitMapFromSavedGame(void)
{
    InitMapLayoutData(&gMapHeader);
    if (JourneyDewfordIsCoastMap(gSaveBlock1Ptr->location.mapGroup,
                                gSaveBlock1Ptr->location.mapNum))
        ClearSavedMapView();
    InitSecretBaseAppearance(FALSE);
    SetOccupiedSecretBaseEntranceMetatiles(gMapHeader.events);
    LoadSavedMapView();
    JourneyAtlasFillPhysicalView(&gMapHeader);
    RunOnLoadMapScript();
    UpdateTVScreensOnMap(gBackupMapLayout.width, gBackupMapLayout.height);
}

void InitBattlePyramidMap(bool8 setPlayerPosition)
{
    CpuFastFill16(MAPGRID_UNDEFINED, sBackupMapData, sizeof(sBackupMapData));
    GenerateBattlePyramidFloorLayout(sBackupMapData, setPlayerPosition);
}

void InitTrainerHillMap(void)
{
    CpuFastFill16(MAPGRID_UNDEFINED, sBackupMapData, sizeof(sBackupMapData));
    GenerateTrainerHillFloorLayout(sBackupMapData);
}

static void InitMapLayoutData(struct MapHeader *mapHeader)
{
    struct MapLayout const *mapLayout;
    int width;
    int height;
    mapLayout = mapHeader->mapLayout;
    CpuFastFill16(MAPGRID_UNDEFINED, sBackupMapData, sizeof(sBackupMapData));
    gBackupMapLayout.map = sBackupMapData;
    width = mapLayout->width + MAP_OFFSET_W;
    gBackupMapLayout.width = width;
    height = mapLayout->height + MAP_OFFSET_H;
    gBackupMapLayout.height = height;
    if (width * height <= MAX_MAP_DATA_SIZE)
    {
        InitBackupMapLayoutData(mapLayout->map, mapLayout->width, mapLayout->height);
        if (JourneyAtlasHeaderChunk(mapHeader) != NULL)
            sMapConnectionFlags = sDummyConnectionFlags;
        InitBackupMapLayoutConnections(mapHeader);
        JourneyAtlasFillPhysicalView(mapHeader);
        JourneyDewfordFillCornerViews(mapHeader);
    }
}

static void InitBackupMapLayoutData(const u16 *map, u16 width, u16 height)
{
    u16 *dest;
    int y;
    dest = gBackupMapLayout.map;
    dest += gBackupMapLayout.width * 7 + MAP_OFFSET;
    for (y = 0; y < height; y++)
    {
        CpuCopy16(map, dest, width * 2);
        dest += width + MAP_OFFSET_W;
        map += width;
    }
}

static void InitBackupMapLayoutConnections(struct MapHeader *mapHeader)
{
    int count;
    const struct MapConnection *connection;
    int i;

    if (mapHeader->connections)
    {
        count = mapHeader->connections->count;
        connection = mapHeader->connections->connections;
        sMapConnectionFlags = sDummyConnectionFlags;
        for (i = 0; i < count; i++, connection++)
        {
            struct MapHeader const *cMap = GetMapHeaderFromConnection(connection);
            s32 offset = connection->offset;
            switch (connection->direction)
            {
            case CONNECTION_SOUTH:
                FillSouthConnection(mapHeader, cMap, offset);
                sMapConnectionFlags.south = TRUE;
                break;
            case CONNECTION_NORTH:
                FillNorthConnection(mapHeader, cMap, offset);
                sMapConnectionFlags.north = TRUE;
                break;
            case CONNECTION_WEST:
                FillWestConnection(mapHeader, cMap, offset);
                sMapConnectionFlags.west = TRUE;
                break;
            case CONNECTION_EAST:
                FillEastConnection(mapHeader, cMap, offset);
                sMapConnectionFlags.east = TRUE;
                break;
            }
        }
    }
}


// Generated ocean routes can expose a third map around an elbow. Resolve its
// artwork only: the underlying undefined cell must retain its invalid movement
// boundary, collision and elevation. At most two cardinal hops are inspected.
static bool8 JourneyMarineViewGroup(u16 group)
{
    if (JourneyAtlasGroup(group))
        return TRUE;
    return group == MAP_GROUP(MAP_JOURNEYSURFLINK00000)
        || group == MAP_GROUP(MAP_JOURNEYSURFLINK03002);
}

static bool8 JourneyMarineViewMap(const struct MapHeader *header)
{
    s32 i;
    if (header->mapType != MAP_TYPE_ROUTE && header->mapType != MAP_TYPE_OCEAN_ROUTE
        && header->mapType != MAP_TYPE_TOWN && header->mapType != MAP_TYPE_CITY)
        return FALSE;
    // Dedicated generated coasts also expose diagonal scenery outside
    // the original link groups. This changes drawing queries only.
    if (header->mapType == MAP_TYPE_OCEAN_ROUTE
        && header->mapLayout->primaryTileset == &gTileset_JourneySeviiSea)
        return TRUE;
    if (JourneyMarineViewGroup(gSaveBlock1Ptr->location.mapGroup))
        return TRUE;
    if (header->connections == NULL)
        return FALSE;
    for (i = 0; i < header->connections->count; i++)
    {
        const struct MapConnection *c = &header->connections->connections[i];
        if (c->direction >= CONNECTION_SOUTH && c->direction <= CONNECTION_EAST
            && JourneyMarineViewGroup(c->mapGroup))
            return TRUE;
    }
    return FALSE;
}

static u16 JourneyMarineTranslateBlock(const struct MapLayout *from,
                                      const struct MapLayout *to, u16 block)
{
    u16 id = block & MAPGRID_METATILE_ID_MASK;
    u16 translated;
    if (from->isFrlg == to->isFrlg)
        return block;
    translated = (to->isFrlg ? 0x112B : 0x1170) | (block & MAPGRID_COLLISION_MASK);
    if (id == (to->isFrlg ? 0x1F9 : 0x243))
        translated = (block & ~MAPGRID_METATILE_ID_MASK) | (to->isFrlg ? 0x243 : 0x1F9);
    else if (JourneyMarineViewMap(&gMapHeader) && !to->isFrlg
        && ((id >= 0x110 && id <= 0x111) || (id >= 0x118 && id <= 0x119)))
        translated = (block & ~MAPGRID_METATILE_ID_MASK) | (id + 0x40);
    else if (JourneyMarineViewMap(&gMapHeader) && to->isFrlg
        && ((id >= 0x150 && id <= 0x151) || (id >= 0x158 && id <= 0x159)))
        translated = (block & ~MAPGRID_METATILE_ID_MASK) | (id - 0x40);
    else if (!to->isFrlg && ((id >= 0x10C && id <= 0x10E) || (id >= 0x114 && id <= 0x116) || (id >= 0x11C && id <= 0x11E)))
        translated = (block & ~MAPGRID_METATILE_ID_MASK) | (id + 15);
    else if (to->isFrlg && ((id >= 0x11B && id <= 0x11D) || (id >= 0x123 && id <= 0x125) || (id >= 0x12B && id <= 0x12D)))
        translated = (block & ~MAPGRID_METATILE_ID_MASK) | (id - 15);
    return translated;
}

static bool8 JourneyMarineConnectionOrigin(const struct MapLayout *from,
    const struct MapConnection *connection, const struct MapHeader **next, s32 *x, s32 *y)
{
    *next = GetMapHeaderFromConnection(connection);
    if (*next == NULL)
        return FALSE;
    *x = *y = 0;
    switch (connection->direction)
    {
    case CONNECTION_WEST: *x = -(*next)->mapLayout->width; *y = connection->offset; break;
    case CONNECTION_EAST: *x = from->width; *y = connection->offset; break;
    case CONNECTION_NORTH: *x = connection->offset; *y = -(*next)->mapLayout->height; break;
    case CONNECTION_SOUTH: *x = connection->offset; *y = from->height; break;
    default: return FALSE;
    }
    return TRUE;
}

static bool8 JourneyMarineViewCompatible(const struct MapLayout *from, u16 block, u16 *result)
{
    const struct MapLayout *to = gMapHeader.mapLayout;
    u16 id = block & MAPGRID_METATILE_ID_MASK;
    u16 translated = JourneyMarineTranslateBlock(from, to, block) & MAPGRID_METATILE_ID_MASK;
    u32 cutoff, i, j;
    const struct Tileset *a, *b;
    const u16 *wordsA, *wordsB;
    if (from->isFrlg != to->isFrlg)
    {
        // Unknown objects must not become an invented patch of ocean.
        if (id != (from->isFrlg ? 0x12B : 0x170)
            && id != (from->isFrlg ? 0x243 : 0x1F9)
            && !((from->isFrlg ? 0x110 : 0x150) <= id && id <= (from->isFrlg ? 0x111 : 0x151))
            && !((from->isFrlg ? 0x118 : 0x158) <= id && id <= (from->isFrlg ? 0x119 : 0x159))
            && !(from->isFrlg && ((id >= 0x10C && id <= 0x10E) || (id >= 0x114 && id <= 0x116) || (id >= 0x11C && id <= 0x11E)))
            && !(!from->isFrlg && ((id >= 0x11B && id <= 0x11D) || (id >= 0x123 && id <= 0x125) || (id >= 0x12B && id <= 0x12D))))
            return FALSE;
        *result = translated;
        return TRUE;
    }
    cutoff = GetNumMetatilesInPrimary(to);
    a = id < cutoff ? from->primaryTileset : from->secondaryTileset;
    b = id < cutoff ? to->primaryTileset : to->secondaryTileset;
    id = id < cutoff ? id : id - cutoff;
    if (from->isFrlg)
    {
        if (((const u32 *)a->metatileAttributes)[id] != ((const u32 *)b->metatileAttributes)[id])
            return FALSE;
    }
    else if (a->metatileAttributes[id] != b->metatileAttributes[id])
        return FALSE;
    wordsA = &a->metatiles[id * NUM_TILES_PER_METATILE];
    wordsB = &b->metatiles[id * NUM_TILES_PER_METATILE];
    for (i = 0; i < NUM_TILES_PER_METATILE; i++)
    {
        u32 palette;
        if (wordsA[i] != wordsB[i])
            return FALSE;
        a = (wordsA[i] & 0x3FF) < cutoff ? from->primaryTileset : from->secondaryTileset;
        b = (wordsB[i] & 0x3FF) < cutoff ? to->primaryTileset : to->secondaryTileset;
        if (a->tiles != b->tiles || a->callback != b->callback)
            return FALSE;
        palette = wordsA[i] >> 12;
        a = palette < GetNumPalsInPrimary(to) ? from->primaryTileset : from->secondaryTileset;
        b = palette < GetNumPalsInPrimary(to) ? to->primaryTileset : to->secondaryTileset;
        for (j = 0; j < 16; j++)
            if (a->palettes[palette][j] != b->palettes[palette][j])
                return FALSE;
    }
    *result = translated;
    return TRUE;
}

static bool8 JourneyMarineActualView(const struct MapLayout *layout, s32 x, s32 y, u16 *result)
{
    return x >= 0 && y >= 0 && x < layout->width && y < layout->height
        && JourneyMarineViewCompatible(layout, layout->map[y * layout->width + x], result);
}


// Only the two standalone generated oceans below need an apron owner. Their
// graph contains folded, distant routes as well as the adjacent visible coast.
// Pick the closest direct rectangle, independently of player/camera position.
static s32 JourneyMarineRectangleDistance(const struct MapLayout *layout, s32 x, s32 y)
{
    s32 dx = x < 0 ? -x : x >= layout->width ? x - layout->width + 1 : 0;
    s32 dy = y < 0 ? -y : y >= layout->height ? y - layout->height + 1 : 0;
    return dx + dy;
}

static bool8 JourneyMarineApronMetatile(s32 x, s32 y, u16 *result)
{
    const struct MapHeader *current = &gMapHeader;
    s32 i, j, closest = 0x7FFFFFFF;
    bool8 found = FALSE;
    u16 value = 0;
    if (current->connections == NULL)
        return FALSE;
    for (i = 0; i < current->connections->count; i++)
    {
        const struct MapHeader *next;
        s32 nx, ny, distance;
        if (!JourneyMarineConnectionOrigin(current->mapLayout,
            &current->connections->connections[i], &next, &nx, &ny))
            continue;
        distance = JourneyMarineRectangleDistance(next->mapLayout, x - nx, y - ny);
        if (distance < closest) closest = distance;
    }
    for (i = 0; i < current->connections->count; i++)
    {
        const struct MapHeader *next;
        const struct MapLayout *layout, *artLayout;
        s32 nx, ny, xx, yy, bw, bh;
        u16 block, candidate;
        bool8 actual;
        if (!JourneyMarineConnectionOrigin(current->mapLayout,
            &current->connections->connections[i], &next, &nx, &ny))
            continue;
        layout = next->mapLayout;
        xx = x - nx; yy = y - ny;
        if (JourneyMarineRectangleDistance(layout, xx, yy) != closest)
            continue;
        artLayout = layout;
        actual = xx >= 0 && yy >= 0 && xx < layout->width && yy < layout->height;
        block = actual ? layout->map[yy * layout->width + xx] : 0;
        // Mirror the owner's native connection strips. A perpendicular
        // overhang is valid; later connections overwrite earlier ones.
        if (!actual && xx >= -7 && xx < layout->width + 8
            && yy >= -7 && yy < layout->height + 7 && next->connections != NULL)
        {
            for (j = 0; j < next->connections->count; j++)
            {
                const struct MapConnection *c = &next->connections->connections[j];
                const struct MapHeader *other;
                s32 ox, oy, tx, ty;
                bool8 strip = (c->direction == CONNECTION_WEST && xx >= -7 && xx < 0)
                    || (c->direction == CONNECTION_EAST && xx >= layout->width && xx < layout->width + 8)
                    || (c->direction == CONNECTION_NORTH && yy >= -7 && yy < 0)
                    || (c->direction == CONNECTION_SOUTH && yy >= layout->height && yy < layout->height + 7);
                if (!strip || !JourneyMarineConnectionOrigin(layout, c, &other, &ox, &oy))
                    continue;
                tx = xx - ox; ty = yy - oy;
                if (tx >= 0 && ty >= 0 && tx < other->mapLayout->width && ty < other->mapLayout->height)
                {
                    artLayout = other->mapLayout;
                    block = artLayout->map[ty * artLayout->width + tx];
                    actual = TRUE;
                }
            }
        }
        if (!actual)
        {
            bw = layout->isFrlg ? layout->borderWidth : 2;
            bh = layout->isFrlg ? layout->borderHeight : 2;
            if (bw == 0 || bh == 0) return FALSE;
            xx %= bw; if (xx < 0) xx += bw;
            yy %= bh; if (yy < 0) yy += bh;
            block = layout->border[yy * bw + xx];
        }
        if (!JourneyMarineViewCompatible(artLayout, block, &candidate))
            return FALSE;
        if (found && value != candidate)
            return FALSE;
        value = candidate; found = TRUE;
    }
    if (found) *result = value;
    return found;
}


// Atlas rectangles share physical world coordinates. Resolve only actual
// neighboring artwork; this function never opens an undefined movement cell.

static bool8 JourneyAtlasUndefinedWater(s32 x, s32 y, u16 *result)
{
    static const struct { u16 map,water,reef; } limits[]={
{23040,299,579},
{23041,299,579},
{23043,299,579},
{23046,299,579},
{23047,299,579},
{23048,299,579},
{23049,299,579},
{23050,299,579},
{23051,299,579},
{23052,299,579},
{23055,299,579},
{23056,299,579},
{23057,299,579},
{23058,299,579},
{23059,299,579},
{23060,299,579},
{23062,299,579},
{23063,299,579},
{23065,299,579},
{23066,299,579},
{23068,299,579},
{23070,299,579},
{23071,299,579},
{23072,299,579},
{23073,299,579},
{23074,299,579},
{23075,299,579},
{23077,299,579},
{23079,299,579},
{23080,299,579},
{23081,299,579},
{23082,299,579},
{23083,299,579},
{23085,299,579},
{23086,299,579},
{23088,299,579},
{23089,299,579},
{23091,299,579},
{23095,299,579},
{23099,299,579},
{23100,299,579},
{23101,299,579},
{23102,299,579},
{23103,299,579},
{23104,299,579},
{23105,299,579},
{23106,299,579},
{23107,299,579},
{23108,299,579},
{23109,299,579},
{23110,299,579},
{23111,299,579},
{23112,299,579},
{23113,299,579},
{23114,299,579},
{23115,299,579},
{23116,299,579},
{23117,299,579},
{23119,299,579},
{23120,299,579},
{23121,299,579},
{23122,299,579},
{23125,299,579},
{23127,299,579},
{23128,299,579},
{23132,299,579},
{23134,299,579},
{23135,299,579},
{23136,299,579},
{23137,299,579},
{23138,299,579},
{23139,299,579},
{23296,299,579},
{23297,299,579},
{23298,299,579},
{23299,299,579},
{23300,299,579},
{23301,299,579},
{23302,299,579},
{23303,299,579},
{23306,299,579},
{23308,299,579},
{23309,299,579},
{23310,368,505},
{23311,299,579},
{23312,299,579},
{23313,299,579},
{23314,299,579},
{23315,299,579},
{23316,299,579},
{23317,299,579},
{23318,299,579},
{23319,299,579},
{23320,368,505},
{23321,299,579},
{23322,299,579},
{23325,299,579},
{23326,299,579},
{23328,299,579},
{23329,299,579},
{23330,299,579},
{23331,299,579},
{23332,299,579},
{23333,299,579},
{23334,299,579},
{23335,299,579},
{23336,299,579},
{23338,299,579},
{23339,299,579},
{23340,368,505},
{23341,299,579},
{23342,299,579},
{23343,299,579},
{23344,299,579},
{23345,299,579},
{23346,299,579},
{23348,299,579},
{23349,299,579},
{23350,299,579},
{23351,299,579},
{23352,299,579},
{23353,299,579},
{23356,299,579},
{23357,299,579},
{23358,299,579},
{23359,299,579},
{23360,299,579},
{23361,299,579},
{23362,299,579},
{23363,299,579},
{23364,299,579},
{23366,299,579},
{23371,299,579},
{23372,299,579},
{23373,299,579},
{23374,299,579},
{23375,299,579},
{23377,299,579},
{23379,368,505},
{23380,299,579},
{23381,299,579},
{23382,299,579},
{23383,299,579},
{23384,299,579},
{23385,299,579},
{23386,299,579},
{23387,299,579},
{23388,299,579},
{23389,299,579},
{23390,299,579},
{23391,299,579},
{23392,299,579},
{23393,299,579},
{23394,299,579},
{23395,299,579},
{23552,368,505},
{23553,299,579},
{23554,299,579},
{23555,299,579},
{23556,299,579},
{23557,299,579},
{23559,299,579},
{23560,299,579},
{23562,299,579},
{23563,299,579},
{23564,299,579},
{23565,299,579},
{23568,299,579},
{23569,299,579},
{23570,299,579},
{23571,299,579},
{23574,299,579},
{23575,299,579},
{23576,299,579},
{23577,299,579},
{23578,299,579},
{23580,299,579},
{23581,299,579},
{23584,299,579},
{23585,299,579},
{23586,299,579},
{23587,299,579},
{23588,299,579},
{23589,299,579},
{23590,299,579},
{23591,299,579},
{23592,299,579},
{23593,299,579},
{23594,299,579},
{23595,368,505},
{23596,368,505},
{23597,368,505},
{23599,299,579},
{23602,299,579},
{23603,299,579},
{23604,299,579},
{23605,368,505},
{23606,299,579},
{23607,299,579},
{23608,368,505},
{23609,299,579},
{23610,299,579},
{23612,299,579},
{23613,299,579},
{23614,299,579},
{23615,299,579},
{23616,368,505},
{23618,368,505},
{23619,368,505},
{23620,368,505},
{23623,368,505},
{23626,368,505},
{23627,299,579},
{23628,299,579},
{23630,368,505},
{23631,299,579},
{23632,299,579},
{23634,368,505},
{23635,299,579},
{23636,299,579},
{23637,368,505},
{23639,368,505},
{23641,368,505},
{23643,299,579},
{23644,368,505},
{23645,368,505},
{23646,299,579},
{23647,368,505},
{23648,368,505},
{23649,299,579},
{23650,299,579},
{23651,299,579},
{23808,299,579},
{23809,299,579},
{23810,299,579},
{23811,299,579},
{23812,299,579},
{23814,368,505},
{23816,368,505},
{23817,368,505},
{23820,368,505},
{23821,368,505},
{23822,368,505},
{23823,299,579},
{23826,368,505},
{23827,299,579},
{23828,299,579},
{23829,299,579},
{23830,299,579},
{23831,368,505},
{23832,368,505},
{23833,368,505},
{23834,368,505},
{23835,368,505},
{23836,368,505},
{23837,299,579},
{23839,368,505},
{23840,368,505},
{23841,299,579},
{23842,299,579},
{23843,299,579},
{23844,299,579},
{23845,299,579},
{23846,368,505},
{23847,299,579},
{23848,368,505},
{23850,368,505},
{23851,368,505},
{23852,368,505},
{23853,368,505},
{23854,299,579},
{23855,299,579},
{23856,299,579},
{23857,299,579},
{23858,299,579},
{23859,299,579},
{23860,299,579},
{23861,299,579},
{23862,299,579},
{23863,299,579},
{23864,299,579},
{23865,299,579},
{23866,368,505},
{23867,368,505},
{23868,368,505},
{23869,368,505},
{23870,368,505},
{23871,368,505},
{23872,368,505},
{23874,368,505},
{23878,368,505},
{23879,368,505},
{23880,368,505},
{23881,368,505},
{23882,299,579},
{23883,299,579},
{23884,299,579},
{23886,368,505},
{23888,368,505},
{23889,368,505},
{23890,368,505},
{23891,368,505},
{23893,368,505},
{23894,299,579},
{23895,299,579},
{23896,368,505},
{23897,368,505},
{23898,299,579},
{23899,299,579},
{23900,368,505},
{23901,368,505},
{23902,368,505},
{23903,368,505},
{23904,299,579},
{23906,368,505},
{23907,368,505},
{24065,299,579},
{24066,368,505},
{24067,368,505},
{24069,368,505},
{24070,368,505},
{24071,299,579},
{24072,299,579},
{24073,299,579},
{24074,299,579},
{24075,299,579},
{24076,368,505},
{24078,368,505},
{24080,368,505},
{24081,368,505},
{24082,299,579},
{24083,299,579},
{24084,299,579},
{24085,299,579},
{24086,299,579},
{24089,368,505},
{24091,368,505},
{24092,368,505},
{24093,368,505},
{24094,368,505},
{24095,368,505},
{24096,368,505},
{24097,299,579},
{24098,299,579},
{24099,299,579},
{24100,299,579},
{24102,368,505},
{24104,368,505},
{24105,299,579},
{24106,299,579},
{24107,299,579},
{24108,299,579},
{24109,299,579},
{24110,368,505},
{24111,368,505},
{24112,368,505},
{24113,299,579},
{24114,299,579},
{24115,299,579},
{24116,299,579},
{24120,368,505},
{24121,368,505},
{24122,368,505},
{24123,368,505},
{24124,368,505},
{24125,299,579},
{24128,299,579},
{24129,368,505},
{24130,299,579},
{24131,299,579},
{24132,299,579},
{24133,299,579},
{24134,299,579},
{24135,299,579},
{24136,299,579},
{24137,368,505},
{24138,299,579},
{24140,368,505},
{24141,368,505},
{24144,368,505},
{24145,368,505},
{24146,299,579},
{24149,368,505},
{24150,299,579},
{24152,299,579},
{24153,299,579},
{24154,299,579},
{24155,299,579},
{24156,299,579},
{24157,299,579},
{24158,299,579},
{24159,299,579},
{24160,299,579},
{24162,299,579},
{24163,299,579},
{24322,299,579},
{24323,368,505},
{24324,368,505},
{24325,368,505},
{24326,299,579},
{24327,299,579},
{24330,299,579},
{24332,299,579},
{24333,299,579},
{24334,368,505},
{24335,368,505},
{24336,368,505},
{24337,368,505},
{24338,368,505},
{24339,368,505},
{24340,368,505},
{24341,299,579},
{24342,299,579},
{24343,299,579},
{24344,299,579},
{24346,299,579},
{24347,299,579},
{24348,299,579},
{24349,299,579},
{24350,299,579},
{24351,299,579},
{24353,299,579},
{24354,299,579},
{24356,299,579},
{24357,299,579},
{24358,299,579},
{24359,299,579},
{24360,299,579},
{24361,299,579},
{24362,299,579},
{24363,299,579},
{24364,299,579},
{24365,299,579},
{24366,299,579},
{24367,299,579},
{24368,299,579},
{24369,299,579},
{24370,299,579},
{24371,299,579},
{24372,299,579},
{24373,299,579},
{24374,299,579},
{24375,299,579},
{24376,299,579},
{24377,299,579},
{24378,299,579},
{24379,299,579},
{24380,299,579},
{24381,299,579},
{24382,299,579},
{24383,299,579},
{24384,299,579},
{24385,299,579},
{24386,299,579},
{24387,368,505},
{24388,299,579},
{24389,299,579},
{24390,299,579},
{24391,299,579},
{24392,368,505},
{24393,299,579},
{24394,299,579},
{24395,368,505},
{24396,299,579},
{24397,368,505},
{24398,368,505},
{24399,368,505},
{24400,299,579},
{24401,368,505},
{24402,368,505},
{24403,299,579},
{24404,368,505},
{24405,368,505},
{24406,368,505},
{24407,368,505},
{24408,368,505},
{24409,368,505},
{24410,368,505},
{24411,368,505},
{24412,368,505},
{24413,368,505},
{24414,299,579},
{24415,299,579},
{24416,368,505},
{24417,299,579},
{24418,368,505},
{24419,368,505},
{24576,299,579},
{24577,368,505},
{24578,368,505},
{24579,368,505},
{24580,299,579},
{24581,299,579},
};
    u16 map=((u16)(u8)gSaveBlock1Ptr->location.mapGroup<<8)|(u8)gSaveBlock1Ptr->location.mapNum;
    const struct MapLayout *layout=gMapHeader.mapLayout;
    u32 lo=0,hi=ARRAY_COUNT(limits),mid;
    s32 xx=x,yy=y;
    bool8 edge=FALSE;
    while(lo<hi) { mid=lo+(hi-lo)/2; if(limits[mid].map<map) lo=mid+1; else hi=mid; }
    if(lo==ARRAY_COUNT(limits) || limits[lo].map!=map || layout==NULL) return FALSE;
    if(x==-1 && y>=0 && y<layout->height) {xx=0;edge=TRUE;}
    if(x==layout->width && y>=0 && y<layout->height) {xx=layout->width-1;edge=TRUE;}
    if(y==-1 && x>=0 && x<layout->width) {yy=0;edge=TRUE;}
    if(y==layout->height && x>=0 && x<layout->width) {yy=layout->height-1;edge=TRUE;}
    *result=(edge && !(layout->map[yy*layout->width+xx]&MAPGRID_COLLISION_MASK))
        ?limits[lo].reef:limits[lo].water;
    return TRUE;
}

static bool8 JourneyAtlasVisualBlock(s32 x, s32 y, u16 *result)
{
    const struct JourneyAtlasChunk *current = JourneyAtlasChunk(
        gSaveBlock1Ptr->location.mapGroup, gSaveBlock1Ptr->location.mapNum);
    const struct JourneyAtlasChunk *owner;
    const struct MapHeader *header;
    const struct MapLayout *layout;
    s32 wx, wy, xx, yy;
    if (current == NULL)
        return FALSE;
    wx = current->x + x; wy = current->y + y;
    owner = JourneyAtlasWorldChunk(wx, wy);
    if (owner == NULL)
        return JourneyAtlasUndefinedWater(x, y, result);
    header = Overworld_GetMapHeaderByGroupAndId(owner->map >> 8, owner->map & 255);
    if (header == NULL)
        return FALSE;
    layout = header->mapLayout;
    xx = wx - owner->x; yy = wy - owner->y;
    if (layout == NULL || xx < 0 || yy < 0 || xx >= layout->width || yy >= layout->height)
        return FALSE;
    return JourneyMarineViewCompatible(layout, layout->map[yy * layout->width + xx], result);
}

static bool8 JourneyMarineCornerMetatile(s32 x, s32 y, u16 *result)
{
    const struct MapHeader *current = &gMapHeader;
    s32 i, j;
    bool8 found = FALSE;
    u16 candidate, value = 0;
    // Preserve the established resolver on every previously eligible coast.
    if ((gSaveBlock1Ptr->location.mapGroup == MAP_GROUP(MAP_JOURNEYWORLDSEA02)
            && gSaveBlock1Ptr->location.mapNum == MAP_NUM(MAP_JOURNEYWORLDSEA02))
        || (gSaveBlock1Ptr->location.mapGroup == MAP_GROUP(MAP_JOURNEYWORLDFILL21RIGHT)
            && gSaveBlock1Ptr->location.mapNum == MAP_NUM(MAP_JOURNEYWORLDFILL21RIGHT)))
        return JourneyMarineApronMetatile(x, y, result);
    if (JourneyAtlasVisualBlock(x, y, result))
        return TRUE;
    if (!JourneyMarineViewMap(current) || current->connections == NULL)
        return FALSE;
    // Actual terrain always precedes repeated border patterns. Keep direct
    // connection order out of the decision when two paths expose one corner.
    for (i = 0; i < current->connections->count; i++)
    {
        const struct MapHeader *next;
        s32 nx, ny;
        if (!JourneyMarineConnectionOrigin(current->mapLayout,
            &current->connections->connections[i], &next, &nx, &ny))
            continue;
        if (JourneyMarineActualView(next->mapLayout, x - nx, y - ny, &candidate))
        {
            if (found && candidate != value) return FALSE;
            value = candidate; found = TRUE;
        }
        if (next->connections == NULL)
            continue;
        for (j = 0; j < next->connections->count; j++)
        {
            const struct MapHeader *other;
            s32 ox, oy;
            if (JourneyMarineConnectionOrigin(next->mapLayout,
                &next->connections->connections[j], &other, &ox, &oy)
                && JourneyMarineActualView(other->mapLayout, x - nx - ox, y - ny - oy, &candidate))
            {
                if (found && candidate != value) return FALSE;
                value = candidate; found = TRUE;
            }
        }
    }
    if (found)
    {
        *result = value;
        return TRUE;
    }
    // Continue a connected map's outer pattern only on its side of the seam.
    // Local modulo preserves the phase for odd dimensions and signed offsets.
    for (i = 0; i < current->connections->count; i++)
    {
        const struct MapConnection *c = &current->connections->connections[i];
        const struct MapHeader *next;
        const struct MapLayout *layout;
        s32 nx, ny, xx, yy, bw, bh;
        if (!JourneyMarineConnectionOrigin(current->mapLayout, c, &next, &nx, &ny))
            continue;
        if (!((c->direction == CONNECTION_WEST && x < 0)
            || (c->direction == CONNECTION_EAST && x >= current->mapLayout->width)
            || (c->direction == CONNECTION_NORTH && y < 0)
            || (c->direction == CONNECTION_SOUTH && y >= current->mapLayout->height)))
            continue;
        layout = next->mapLayout;
        bw = layout->isFrlg ? layout->borderWidth : 2;
        bh = layout->isFrlg ? layout->borderHeight : 2;
        if (bw == 0 || bh == 0)
            continue;
        xx = (x - nx) % bw; if (xx < 0) xx += bw;
        yy = (y - ny) % bh; if (yy < 0) yy += bh;
        if (JourneyMarineViewCompatible(layout, layout->border[xx + yy * bw], &candidate))
        {
            if (found && candidate != value) return FALSE;
            value = candidate; found = TRUE;
        }
    }
    if (found) *result = value;
    return found;
}


static bool8 JourneyAtlasPhysicalWord(const struct MapLayout *from, u16 word, u16 *result)
{
    u16 translated;
    if (from->isFrlg == gMapHeader.mapLayout->isFrlg
        && from->primaryTileset == gMapHeader.mapLayout->primaryTileset
        && from->secondaryTileset == gMapHeader.mapLayout->secondaryTileset)
    {
        *result = word;
        return TRUE;
    }
    if (!JourneyMarineViewCompatible(from, word, &translated))
        return FALSE;
    *result = (word & ~MAPGRID_METATILE_ID_MASK) | (translated & MAPGRID_METATILE_ID_MASK);
    return TRUE;
}

// An Atlas connection may be narrower than the engine's seven-tile apron.
// Intersect source and destination coordinates BEFORE forming any pointer.
static void JourneyAtlasCopyConnection(int x, int y,
    const struct MapHeader *next, int x2, int y2, int width, int height)
{
    s32 i, j, left = 0, top = 0, right = width, bottom = height;
    const struct MapLayout *layout = next->mapLayout;
    u16 word, value;
    if (-x2 > left) left = -x2;
    if (-x > left) left = -x;
    if (-y2 > top) top = -y2;
    if (-y > top) top = -y;
    if (layout->width - x2 < right) right = layout->width - x2;
    if (gBackupMapLayout.width - x < right) right = gBackupMapLayout.width - x;
    if (layout->height - y2 < bottom) bottom = layout->height - y2;
    if (gBackupMapLayout.height - y < bottom) bottom = gBackupMapLayout.height - y;
    for (i = top; i < bottom; i++)
        for (j = left; j < right; j++)
        {
            word = layout->map[(y2 + i) * layout->width + x2 + j];
            value = MAPGRID_UNDEFINED;
            JourneyAtlasPhysicalWord(layout, word, &value);
            gBackupMapLayout.map[(y + i) * gBackupMapLayout.width + x + j] = value;
        }
}

// A direct native coast owns its entrance face, including blocked scenery.
// It precedes global rectangle lookup so a blocked Atlas background cannot
// hide a legitimate return to shore. Conflicting owners fail closed.
static bool8 JourneyAtlasNativeFace(const struct MapHeader *current,
    s32 x, s32 y, u16 *result)
{
    s32 i, nx, ny, xx, yy;
    bool8 found = FALSE;
    u16 candidate, value = MAPGRID_UNDEFINED;
    const struct MapHeader *next;
    const struct MapConnection *connection;
    if (current->connections == NULL)
        return FALSE;
    for (i = 0; i < current->connections->count; i++)
    {
        connection = &current->connections->connections[i];
        if (!((connection->direction == CONNECTION_WEST && x < 0)
            || (connection->direction == CONNECTION_EAST && x >= current->mapLayout->width)
            || (connection->direction == CONNECTION_NORTH && y < 0)
            || (connection->direction == CONNECTION_SOUTH && y >= current->mapLayout->height)))
            continue;
        if (!JourneyMarineConnectionOrigin(current->mapLayout, connection, &next, &nx, &ny)
            || JourneyAtlasHeaderChunk(next) != NULL)
            continue;
        xx = x - nx; yy = y - ny;
        if (xx < 0 || yy < 0 || xx >= next->mapLayout->width || yy >= next->mapLayout->height)
            continue;
        candidate = MAPGRID_UNDEFINED;
        JourneyAtlasPhysicalWord(next->mapLayout,
            next->mapLayout->map[yy * next->mapLayout->width + xx], &candidate);
        if (found && candidate != value)
        {
            *result = MAPGRID_UNDEFINED;
            return TRUE;
        }
        found = TRUE; value = candidate;
    }
    if (found) *result = value;
    return found;
}

// Match GetMapConnectionAtPos: the first actual connection owns this face.
// This also restores native apron cells after a later Atlas perimeter copy.
static bool8 JourneyAtlasFirstConnectionFace(const struct MapHeader *current,
    s32 x, s32 y, u16 *result)
{
    s32 i, nx, ny, xx, yy;
    const struct MapHeader *next;
    const struct MapConnection *connection;
    if (current->connections == NULL) return FALSE;
    for (i = 0; i < current->connections->count; i++)
    {
        connection = &current->connections->connections[i];
        if (!((connection->direction == CONNECTION_WEST && x < 0)
            || (connection->direction == CONNECTION_EAST && x >= current->mapLayout->width)
            || (connection->direction == CONNECTION_NORTH && y < 0)
            || (connection->direction == CONNECTION_SOUTH && y >= current->mapLayout->height)))
            continue;
        if (!JourneyMarineConnectionOrigin(current->mapLayout, connection, &next, &nx, &ny))
            continue;
        xx = x - nx; yy = y - ny;
        if (xx < 0 || yy < 0 || xx >= next->mapLayout->width || yy >= next->mapLayout->height)
            continue;
        if (JourneyAtlasHeaderChunk(next) == NULL)
        {
            // Native-to-native copies retain the original engine's full
            // words. Do not replace existing city scenery with undefined
            // cells merely because an Atlas neighbor was added elsewhere.
            *result = next->mapLayout->map[yy * next->mapLayout->width + xx];
            return TRUE;
        }
        *result = MAPGRID_UNDEFINED;
        JourneyAtlasPhysicalWord(next->mapLayout,
            next->mapLayout->map[yy * next->mapLayout->width + xx], result);
        return TRUE;
    }
    return FALSE;
}

static void JourneyAtlasFillPhysicalView(const struct MapHeader *current)
{
    const struct JourneyAtlasChunk *chunk = JourneyAtlasHeaderChunk(current);
    const struct JourneyAtlasChunk *owner;
    const struct MapHeader *next;
    const struct MapLayout *layout;
    s32 x, y, xx, yy, gx, gy, i;
    u16 value;
    if (chunk == NULL)
    {
        // Unrelated native maps retain their original implementation. Only
        // native hosts of a new Atlas connection need apron precedence repair.
        if (current->connections == NULL) return;
        for (i = 0; i < current->connections->count; i++)
        {
            const struct MapConnection *c = &current->connections->connections[i];
            if (c->direction < CONNECTION_SOUTH || c->direction > CONNECTION_EAST) continue;
            next = Overworld_GetMapHeaderByGroupAndId(c->mapGroup, c->mapNum);
            if (JourneyAtlasHeaderChunk(next) != NULL) break;
        }
        if (i == current->connections->count) return;
        for (y = 0; y < gBackupMapLayout.height; y++)
            for (x = 0; x < gBackupMapLayout.width; x++)
            {
                xx = x - MAP_OFFSET; yy = y - MAP_OFFSET;
                if (xx >= 0 && yy >= 0 && xx < current->mapLayout->width && yy < current->mapLayout->height)
                    continue;
                if (JourneyAtlasFirstConnectionFace(current, xx, yy, &value))
                    gBackupMapLayout.map[y * gBackupMapLayout.width + x] = value;
            }
        return;
    }
    for (y = 0; y < gBackupMapLayout.height; y++)
        for (x = 0; x < gBackupMapLayout.width; x++)
        {
            xx = x - MAP_OFFSET; yy = y - MAP_OFFSET;
            // Never replace the current map, including runtime changes.
            if (xx >= 0 && yy >= 0 && xx < current->mapLayout->width && yy < current->mapLayout->height)
                continue;
            value = MAPGRID_UNDEFINED;
            if (!JourneyAtlasNativeFace(current, xx, yy, &value))
            {
                gx = chunk->x + xx; gy = chunk->y + yy;
                owner = JourneyAtlasWorldChunk(gx, gy);
                if (owner != NULL)
                {
                    next = Overworld_GetMapHeaderByGroupAndId(owner->map >> 8, owner->map & 255);
                    layout = next->mapLayout;
                    xx = gx - owner->x; yy = gy - owner->y;
                    if (xx >= 0 && yy >= 0 && xx < layout->width && yy < layout->height)
                        JourneyAtlasPhysicalWord(layout, layout->map[yy * layout->width + xx], &value);
                }
            }
            gBackupMapLayout.map[y * gBackupMapLayout.width + x] = value;
        }
}

// A diagonal halo cell may be visible and have real terrain, but crossing a
// face still requires the engine's actual direct connection at that offset.
static bool8 JourneyAtlasBorderConnectionValid(s32 x, s32 y)
{
    const struct JourneyAtlasChunk *chunk = JourneyAtlasHeaderChunk(&gMapHeader);
    const struct JourneyAtlasChunk *owner;
    const struct MapConnection *connection;
    enum Connection direction;
    if (chunk == NULL)
        return TRUE;
    x -= MAP_OFFSET; y -= MAP_OFFSET;
    if (x >= gMapHeader.mapLayout->width) direction = CONNECTION_EAST;
    else if (x < 0) direction = CONNECTION_WEST;
    else if (y >= gMapHeader.mapLayout->height) direction = CONNECTION_SOUTH;
    else if (y < 0) direction = CONNECTION_NORTH;
    else return TRUE;
    if (gMapHeader.connections == NULL || gMapHeader.connections->connections == NULL)
        return FALSE;
    connection = GetIncomingConnection(direction, x, y);
    if (connection == NULL)
        return FALSE;
    if (JourneyAtlasChunk(connection->mapGroup, connection->mapNum) == NULL)
        return TRUE;
    owner = JourneyAtlasWorldChunk(chunk->x + x, chunk->y + y);
    return owner != NULL && owner->map == ((connection->mapGroup << 8) | connection->mapNum);
}

static void FillConnection(int x, int y, struct MapHeader const *connectedMapHeader, int x2, int y2, int width, int height)
{
    int i;
    const u16 *src;
    u16 *dest;
    int mapWidth;

    if (JourneyAtlasHeaderChunk(&gMapHeader) != NULL
        || JourneyAtlasHeaderChunk(connectedMapHeader) != NULL)
    {
        JourneyAtlasCopyConnection(x, y, connectedMapHeader, x2, y2, width, height);
        return;
    }
    mapWidth = connectedMapHeader->mapLayout->width;
    src = &connectedMapHeader->mapLayout->map[mapWidth * y2 + x2];
    dest = &gBackupMapLayout.map[gBackupMapLayout.width * y + x];

    for (i = 0; i < height; i++)
    {
        if (connectedMapHeader->mapLayout->isFrlg != gMapHeader.mapLayout->isFrlg)
        {
            int j;
            for (j = 0; j < width; j++)
            {
                dest[j] = JourneyMarineTranslateBlock(connectedMapHeader->mapLayout,
                    gMapHeader.mapLayout, src[j]);
            }
        }
        else
            CpuCopy16(src, dest, width * 2);
        dest += gBackupMapLayout.width;
        src += mapWidth;
    }
}

static void FillSouthConnection(struct MapHeader const *mapHeader, struct MapHeader const *connectedMapHeader, s32 offset)
{
    int x, y;
    int x2;
    int width;
    int cWidth;

    if (connectedMapHeader)
    {
        cWidth = connectedMapHeader->mapLayout->width;
        x = offset + MAP_OFFSET;
        y = mapHeader->mapLayout->height + MAP_OFFSET;
        if (x < 0)
        {
            x2 = -x;
            x += cWidth;
            if (x < gBackupMapLayout.width)
                width = x;
            else
                width = gBackupMapLayout.width;
            x = 0;
        }
        else
        {
            x2 = 0;
            if (x + cWidth < gBackupMapLayout.width)
                width = cWidth;
            else
                width = gBackupMapLayout.width - x;
        }

        FillConnection(
            x, y,
            connectedMapHeader,
            x2, /*y2*/ 0,
            width, /*height*/ MAP_OFFSET);
    }
}

static void FillNorthConnection(struct MapHeader const *mapHeader, struct MapHeader const *connectedMapHeader, s32 offset)
{
    int x;
    int x2, y2;
    int width;
    int cWidth, cHeight;

    if (connectedMapHeader)
    {
        cWidth = connectedMapHeader->mapLayout->width;
        cHeight = connectedMapHeader->mapLayout->height;
        x = offset + MAP_OFFSET;
        y2 = cHeight - MAP_OFFSET;
        if (x < 0)
        {
            x2 = -x;
            x += cWidth;
            if (x < gBackupMapLayout.width)
                width = x;
            else
                width = gBackupMapLayout.width;
            x = 0;
        }
        else
        {
            x2 = 0;
            if (x + cWidth < gBackupMapLayout.width)
                width = cWidth;
            else
                width = gBackupMapLayout.width - x;
        }

        FillConnection(
            x, /*y*/ 0,
            connectedMapHeader,
            x2, y2,
            width, /*height*/ MAP_OFFSET);

    }
}

static void FillWestConnection(struct MapHeader const *mapHeader, struct MapHeader const *connectedMapHeader, s32 offset)
{
    int y;
    int x2, y2;
    int height;
    int cWidth, cHeight;
    if (connectedMapHeader)
    {
        cWidth = connectedMapHeader->mapLayout->width;
        cHeight = connectedMapHeader->mapLayout->height;
        y = offset + MAP_OFFSET;
        x2 = cWidth - MAP_OFFSET;
        if (y < 0)
        {
            y2 = -y;
            if (y + cHeight < gBackupMapLayout.height)
                height = y + cHeight;
            else
                height = gBackupMapLayout.height;
            y = 0;
        }
        else
        {
            y2 = 0;
            if (y + cHeight < gBackupMapLayout.height)
                height = cHeight;
            else
                height = gBackupMapLayout.height - y;
        }

        FillConnection(
            /*x*/ 0, y,
            connectedMapHeader,
            x2, y2,
            /*width*/ MAP_OFFSET, height);
    }
}

static void FillEastConnection(struct MapHeader const *mapHeader, struct MapHeader const *connectedMapHeader, s32 offset)
{
    int x, y;
    int y2;
    int height;
    int cHeight;
    if (connectedMapHeader)
    {
        cHeight = connectedMapHeader->mapLayout->height;
        x = mapHeader->mapLayout->width + MAP_OFFSET;
        y = offset + MAP_OFFSET;
        if (y < 0)
        {
            y2 = -y;
            if (y + cHeight < gBackupMapLayout.height)
                height = y + cHeight;
            else
                height = gBackupMapLayout.height;
            y = 0;
        }
        else
        {
            y2 = 0;
            if (y + cHeight < gBackupMapLayout.height)
                height = cHeight;
            else
                height = gBackupMapLayout.height - y;
        }

        FillConnection(
            x, y,
            connectedMapHeader,
            /*x2*/ 0, y2,
            /*width*/ MAP_OFFSET + 1, height);
    }
}

u8 MapGridGetElevationAt(int x, int y)
{
    u16 block = GetMapGridBlockAt(x, y);

    if (block == MAPGRID_UNDEFINED)
        return 0;

    return UNPACK_ELEVATION(block);
}

u8 MapGridGetCollisionAt(int x, int y)
{
    u16 block = GetMapGridBlockAt(x, y);

    if (block == MAPGRID_UNDEFINED)
        return TRUE;

    return UNPACK_COLLISION(block);
}

u32 GetNumTilesInPrimary(struct MapLayout const *mapLayout)
{
    return mapLayout->isFrlg ? NUM_TILES_IN_PRIMARY_FRLG : NUM_TILES_IN_PRIMARY;
}

u32 GetNumMetatilesInPrimary(struct MapLayout const *mapLayout)
{
    return mapLayout->isFrlg ? NUM_METATILES_IN_PRIMARY_FRLG : NUM_METATILES_IN_PRIMARY;
}

u32 GetNumPalsInPrimary(struct MapLayout const *mapLayout)
{
    return mapLayout->isFrlg ? NUM_PALS_IN_PRIMARY_FRLG : NUM_PALS_IN_PRIMARY;
}

u32 MapGridGetMetatileIdAt(int x, int y)
{
    u16 block = GetMapGridBlockAt(x, y);

    if (block == MAPGRID_UNDEFINED)
    {
        u16 visible;
        if (JourneyMarineCornerMetatile(x - MAP_OFFSET, y - MAP_OFFSET, &visible))
            return visible;
        return GetBorderBlockAt(x, y) & MAPGRID_METATILE_ID_MASK;
    }

    return UNPACK_METATILE(block);
}

u32 MapGridGetMetatileAttributeAt(s16 x, s16 y, u8 attributeType)
{
    u16 metatileId = MapGridGetMetatileIdAt(x, y);
    return GetAttributeByMetatileIdAndMapLayout(metatileId, attributeType, gMapHeader.mapLayout->isFrlg);
}

u32 MapGridGetMetatileBehaviorAt(int x, int y)
{
    return MapGridGetMetatileAttributeAt(x, y, METATILE_ATTRIBUTE_BEHAVIOR);
}

u8 MapGridGetMetatileLayerTypeAt(int x, int y)
{
    return MapGridGetMetatileAttributeAt(x, y, METATILE_ATTRIBUTE_LAYER_TYPE);
}

void MapGridSetMetatileIdAt(int x, int y, u16 metatile)
{
    int i;
    if (AreCoordsWithinMapGridBounds(x, y))
    {
        i = x + y * gBackupMapLayout.width;

        // Elevation is ignored in the argument, but copy metatile ID and collision
        gBackupMapLayout.map[i] = (gBackupMapLayout.map[i] & MAPGRID_ELEVATION_MASK) | (metatile & ~MAPGRID_ELEVATION_MASK);
    }
}

void MapGridSetMetatileEntryAt(int x, int y, u16 metatile)
{
    int i;
    if (AreCoordsWithinMapGridBounds(x, y))
    {
        i = x + gBackupMapLayout.width * y;
        gBackupMapLayout.map[i] = metatile;
    }
}

u32 ExtractMetatileAttribute(u32 attributes, u8 attributeType, bool32 isFrlg)
{
    if (attributeType >= METATILE_ATTRIBUTE_COUNT) // Check for METATILE_ATTRIBUTES_ALL
        return attributes;

    if (isFrlg)
        return (attributes & sMetatileAttrMasks[attributeType]) >> sMetatileAttrShifts[attributeType];

    return (attributes & sMetatileAttrMasksEmerald[attributeType]) >> sMetatileAttrShiftsEmerald[attributeType];
}

static u32 GetAttributeByMetatileIdAndMapLayoutFrlg(u16 metatile, u8 attributeType)
{
    u32 attribute;
    if (metatile < GetNumMetatilesInPrimary(gMapHeader.mapLayout))
    {
        const u32 *attributes = (const u32*)gMapHeader.mapLayout->primaryTileset->metatileAttributes;
        attribute = attributes[metatile];
    }
    else if (metatile < NUM_METATILES_TOTAL)
    {
        const u32 *attributes = (const u32*) gMapHeader.mapLayout->secondaryTileset->metatileAttributes;
        metatile -= GetNumMetatilesInPrimary(gMapHeader.mapLayout);
        attribute = attributes[metatile];
    }
    else
    {
        return MB_INVALID;
    }

    return ExtractMetatileAttribute(attribute, attributeType, TRUE);
}

u32 GetAttributeByMetatileIdAndMapLayout(u16 metatile, u8 attributeType, bool32 isFrlg)
{
    u32 attribute;

    if (isFrlg)
        return GetAttributeByMetatileIdAndMapLayoutFrlg(metatile, attributeType);

    if (metatile < GetNumMetatilesInPrimary(gMapHeader.mapLayout))
    {
        const u16 *attributes = (const u16*)gMapHeader.mapLayout->primaryTileset->metatileAttributes;
        attribute = attributes[metatile];
    }
    else if (metatile < NUM_METATILES_TOTAL)
    {
        const u16 *attributes = (const u16*)gMapHeader.mapLayout->secondaryTileset->metatileAttributes;
        metatile -= GetNumMetatilesInPrimary(gMapHeader.mapLayout);
        attribute = attributes[metatile];
    }
    else
    {
        return MB_INVALID;
    }

    return ExtractMetatileAttribute(attribute, attributeType, FALSE);
}

void SaveMapView(void)
{
    int i, j;
    int x, y;
    u16 *mapView;
    int width;
    mapView = gSaveBlock1Ptr->mapView;
    width = gBackupMapLayout.width;
    x = gSaveBlock1Ptr->pos.x;
    y = gSaveBlock1Ptr->pos.y;
    for (i = y; i < y + MAP_OFFSET_H; i++)
    {
        for (j = x; j < x + MAP_OFFSET_W; j++)
            *mapView++ = sBackupMapData[width * i + j];
    }
}

static bool32 SavedMapViewIsEmpty(void)
{
    u16 i;
    u32 marker = 0;

#ifndef UBFIX
    // BUG: This loop extends past the bounds of the mapView array. Its size is only 0x100.
    for (i = 0; i < 0x200; i++)
        marker |= gSaveBlock1Ptr->mapView[i];
#else
    // UBFIX: Only iterate over 0x100
    for (i = 0; i < ARRAY_COUNT(gSaveBlock1Ptr->mapView); i++)
        marker |= gSaveBlock1Ptr->mapView[i];
#endif


    if (marker == 0)
        return TRUE;
    else
        return FALSE;
}

static void ClearSavedMapView(void)
{
    CpuFill16(0, gSaveBlock1Ptr->mapView, sizeof(gSaveBlock1Ptr->mapView));
}

static void LoadSavedMapView(void)
{
    u8 yMode;
    int i, j;
    int x, y;
    u16 *mapView;
    int width;
    mapView = gSaveBlock1Ptr->mapView;
    if (!SavedMapViewIsEmpty())
    {
        width = gBackupMapLayout.width;
        x = gSaveBlock1Ptr->pos.x;
        y = gSaveBlock1Ptr->pos.y;
        for (i = y; i < y + MAP_OFFSET_H; i++)
        {
            if (i == y && i != 0)
                yMode = 0;
            else if (i == y + MAP_OFFSET_H - 1 && i != gMapHeader.mapLayout->height - 1)
                yMode = 1;
            else
                yMode = 0xFF;

            for (j = x; j < x + MAP_OFFSET_W; j++)
            {
                if (!SkipCopyingMetatileFromSavedMap(&sBackupMapData[j + width * i], width, yMode))
                    sBackupMapData[j + width * i] = *mapView;
                mapView++;
            }
        }
        for (j = x; j < x + MAP_OFFSET_W; j++)
        {
            if (y != 0)
                FixLongGrassMetatilesWindowTop(j, y - 1);
            if (i < gMapHeader.mapLayout->height - 1)
                FixLongGrassMetatilesWindowBottom(j, y + MAP_OFFSET_H - 1);
        }
        ClearSavedMapView();
    }
}

static void MoveMapViewToBackup(enum Connection direction)
{
    int width;
    u16 *mapView;
    int x0, y0;
    int x2, y2;
    u16 *src, *dest;
    int srci, desti;
    int r9, r8;
    int x, y;
    int i, j;
    mapView = gSaveBlock1Ptr->mapView;
    width = gBackupMapLayout.width;
    r9 = 0;
    r8 = 0;
    x0 = gSaveBlock1Ptr->pos.x;
    y0 = gSaveBlock1Ptr->pos.y;
    x2 = MAP_OFFSET_W;
    y2 = MAP_OFFSET_H;

    switch (direction)
    {
    case CONNECTION_NORTH:
        y0 += 1;
        y2 = MAP_OFFSET_H - 1;
        break;
    case CONNECTION_SOUTH:
        r8 = 1;
        y2 = MAP_OFFSET_H - 1;
        break;
    case CONNECTION_WEST:
        x0 += 1;
        x2 = MAP_OFFSET_W - 1;
        break;
    case CONNECTION_EAST:
        r9 = 1;
        x2 = MAP_OFFSET_W - 1;
        break;
    default:
        break;
    }

    for (y = 0; y < y2; y++)
    {
        i = 0;
        j = 0;
        for (x = 0; x < x2; x++)
        {
            desti = width * (y + y0);
            srci = (y + r8) * MAP_OFFSET_W + r9;
            src = &mapView[srci + i];
            dest = &sBackupMapData[x0 + desti + j];
            *dest = *src;
            i++;
            j++;
        }
    }

    ClearSavedMapView();
}

enum Connection GetMapBorderIdAt(int x, int y)
{
    if (!JourneyAtlasBorderConnectionValid(x, y))
        return CONNECTION_INVALID;

    if (GetMapGridBlockAt(x, y) == MAPGRID_UNDEFINED)
        return CONNECTION_INVALID;

    if (x >= (gBackupMapLayout.width - (MAP_OFFSET + 1)))
    {
        if (!sMapConnectionFlags.east)
            return CONNECTION_INVALID;

        return CONNECTION_EAST;
    }
    else if (x < MAP_OFFSET)
    {
        if (!sMapConnectionFlags.west)
            return CONNECTION_INVALID;

        return CONNECTION_WEST;
    }
    else if (y >= (gBackupMapLayout.height - MAP_OFFSET))
    {
        if (!sMapConnectionFlags.south)
            return CONNECTION_INVALID;

        return CONNECTION_SOUTH;
    }
    else if (y < MAP_OFFSET)
    {
        if (!sMapConnectionFlags.north)
            return CONNECTION_INVALID;

        return CONNECTION_NORTH;
    }
    else
    {
        return CONNECTION_NONE;
    }
}

enum Connection GetPostCameraMoveMapBorderId(int x, int y)
{
    return GetMapBorderIdAt(gSaveBlock1Ptr->pos.x + MAP_OFFSET + x, gSaveBlock1Ptr->pos.y + MAP_OFFSET + y);
}

bool32 CanCameraMoveInDirection(enum Direction direction)
{
    int x, y;
    x = gSaveBlock1Ptr->pos.x + MAP_OFFSET + gDirectionToVectors[direction].x;
    y = gSaveBlock1Ptr->pos.y + MAP_OFFSET + gDirectionToVectors[direction].y;

    if (GetMapBorderIdAt(x, y) == CONNECTION_INVALID)
        return FALSE;

    return TRUE;
}

static void SetPositionFromConnection(const struct MapConnection *connection, enum Connection direction, int x, int y)
{
    struct MapHeader const *mapHeader = GetMapHeaderFromConnection(connection);

    switch (direction)
    {
    case CONNECTION_EAST:
        gSaveBlock1Ptr->pos.x = -x;
        gSaveBlock1Ptr->pos.y -= connection->offset;
        break;
    case CONNECTION_WEST:
        gSaveBlock1Ptr->pos.x = mapHeader->mapLayout->width;
        gSaveBlock1Ptr->pos.y -= connection->offset;
        break;
    case CONNECTION_SOUTH:
        gSaveBlock1Ptr->pos.x -= connection->offset;
        gSaveBlock1Ptr->pos.y = -y;
        break;
    case CONNECTION_NORTH:
        gSaveBlock1Ptr->pos.x -= connection->offset;
        gSaveBlock1Ptr->pos.y = mapHeader->mapLayout->height;
        break;
    default:
        errorf("invalid direction: %d", direction);
        break;
    }
}

bool8 CameraMove(int x, int y)
{
    enum Connection direction;
    const struct MapConnection *connection;
    int old_x, old_y;
    bool32 freshCoastView;
    gCamera.active = FALSE;
    direction = GetPostCameraMoveMapBorderId(x, y);
    if (direction == CONNECTION_NONE || direction == CONNECTION_INVALID)
    {
        gSaveBlock1Ptr->pos.x += x;
        gSaveBlock1Ptr->pos.y += y;
    }
    else
    {
        SaveMapView();
        ClearMirageTowerPulseBlendEffect();
        old_x = gSaveBlock1Ptr->pos.x;
        old_y = gSaveBlock1Ptr->pos.y;
        connection = GetIncomingConnection(direction, gSaveBlock1Ptr->pos.x, gSaveBlock1Ptr->pos.y);
        assertf(connection)
        {
            return gCamera.active;
        }

        freshCoastView = JourneySeviiNeedsFreshCoastView(
            gSaveBlock1Ptr->location.mapGroup, gSaveBlock1Ptr->location.mapNum,
            connection->mapGroup, connection->mapNum);
        {
            const struct MapLayout *next = GetMapHeaderFromConnection(connection)->mapLayout;
            freshCoastView |= next->primaryTileset != gMapHeader.mapLayout->primaryTileset
                           || next->secondaryTileset != gMapHeader.mapLayout->secondaryTileset
                           || gSaveBlock1Ptr->location.mapGroup >= MAP_GROUP(MAP_JOURNEYSURFLINK00000)
                           || connection->mapGroup >= MAP_GROUP(MAP_JOURNEYSURFLINK00000);
        }
        freshCoastView |= JourneyDewfordIsCoastMap(
            gSaveBlock1Ptr->location.mapGroup, gSaveBlock1Ptr->location.mapNum)
            || JourneyDewfordIsCoastMap(connection->mapGroup, connection->mapNum);
        // Clear BEFORE InitMap/LoadSavedMapView can replay foreign bank IDs.
        if (freshCoastView)
            ClearSavedMapView();
        SetPositionFromConnection(connection, direction, x, y);
        LoadMapFromCameraTransition(connection->mapGroup, connection->mapNum);
        gCamera.active = TRUE;
        gCamera.x = old_x - gSaveBlock1Ptr->pos.x;
        gCamera.y = old_y - gSaveBlock1Ptr->pos.y;
        gSaveBlock1Ptr->pos.x += x;
        gSaveBlock1Ptr->pos.y += y;
        // A short island map can still contain a third map's blocked corner
        // in its saved apron. Keep the newly loaded coast/collision grid.
        if (freshCoastView)
            ClearSavedMapView();
        else
            MoveMapViewToBackup(direction);
    }

    return gCamera.active;
}

static const struct MapConnection *GetIncomingConnection(enum Connection direction, int x, int y)
{
    int count;
    int i;
    const struct MapConnection *connection;
    const struct MapConnections *connections = gMapHeader.connections;

#ifdef UBFIX // UB: Multiple possible null dereferences
    if (connections == NULL || connections->connections == NULL)
        return NULL;
#endif
    count = connections->count;
    connection = connections->connections;
    for (i = 0; i < count; i++, connection++)
    {
        if (connection->direction == direction && IsPosInIncomingConnectingMap(direction, x, y, connection) == TRUE)
            return connection;
    }
    return NULL;
}

static bool8 IsPosInIncomingConnectingMap(enum Connection direction, int x, int y, const struct MapConnection *connection)
{
    struct MapHeader const *mapHeader;
    mapHeader = GetMapHeaderFromConnection(connection);
    switch (direction)
    {
    case CONNECTION_SOUTH:
    case CONNECTION_NORTH:
        return IsCoordInIncomingConnectingMap(x, gMapHeader.mapLayout->width, mapHeader->mapLayout->width, connection->offset);
    case CONNECTION_WEST:
    case CONNECTION_EAST:
        return IsCoordInIncomingConnectingMap(y, gMapHeader.mapLayout->height, mapHeader->mapLayout->height, connection->offset);
    default:
        return FALSE;
    }
}

static bool8 IsCoordInIncomingConnectingMap(int coord, int srcMax, int destMax, int offset)
{
    int offset2;
    offset2 = offset;

    if (offset2 < 0)
        offset2 = 0;

    if (destMax + offset < srcMax)
        srcMax = destMax + offset;

    if (offset2 <= coord && coord < srcMax)
        return TRUE;

    return FALSE;
}

static int IsCoordInConnectingMap(int coord, int max)
{
    if (coord >= 0 && coord < max)
        return TRUE;

    return FALSE;
}

static int IsPosInConnectingMap(const struct MapConnection *connection, int x, int y)
{
    struct MapHeader const *mapHeader;
    mapHeader = GetMapHeaderFromConnection(connection);
    switch (connection->direction)
    {
    case CONNECTION_SOUTH:
    case CONNECTION_NORTH:
        return IsCoordInConnectingMap(x - connection->offset, mapHeader->mapLayout->width);
    case CONNECTION_WEST:
    case CONNECTION_EAST:
        return IsCoordInConnectingMap(y - connection->offset, mapHeader->mapLayout->height);
    }
    return FALSE;
}

const struct MapConnection *GetMapConnectionAtPos(s16 x, s16 y)
{
    int count;
    const struct MapConnection *connection;
    int i;
    enum Connection direction;
    if (!gMapHeader.connections)
    {
        return NULL;
    }
    else
    {
        count = gMapHeader.connections->count;
        connection = gMapHeader.connections->connections;
        for (i = 0; i < count; i++, connection++)
        {
            direction = connection->direction;
            if ((direction == CONNECTION_DIVE || direction == CONNECTION_EMERGE)
             || (direction == CONNECTION_NORTH && y > MAP_OFFSET - 1)
             || (direction == CONNECTION_SOUTH && y < gMapHeader.mapLayout->height + MAP_OFFSET)
             || (direction == CONNECTION_WEST && x > MAP_OFFSET - 1)
             || (direction == CONNECTION_EAST && x < gMapHeader.mapLayout->width + MAP_OFFSET))
            {
                continue;
            }
            if (IsPosInConnectingMap(connection, x - MAP_OFFSET, y - MAP_OFFSET) == TRUE)
            {
                return connection;
            }
        }
    }
    return NULL;
}

void SetCameraFocusCoords(u16 x, u16 y)
{
    gSaveBlock1Ptr->pos.x = x - MAP_OFFSET;
    gSaveBlock1Ptr->pos.y = y - MAP_OFFSET;
}

void GetCameraFocusCoords(u16 *x, u16 *y)
{
    *x = gSaveBlock1Ptr->pos.x + MAP_OFFSET;
    *y = gSaveBlock1Ptr->pos.y + MAP_OFFSET;
}

static void UNUSED SetCameraCoords(u16 x, u16 y)
{
    gSaveBlock1Ptr->pos.x = x;
    gSaveBlock1Ptr->pos.y = y;
}

void GetCameraCoords(u16 *x, u16 *y)
{
    *x = gSaveBlock1Ptr->pos.x;
    *y = gSaveBlock1Ptr->pos.y;
}

void MapGridSetMetatileImpassabilityAt(int x, int y, bool32 impassable)
{
    if (AreCoordsWithinMapGridBounds(x, y))
    {
        if (impassable)
            gBackupMapLayout.map[x + gBackupMapLayout.width * y] |= MAPGRID_COLLISION_MASK;
        else
            gBackupMapLayout.map[x + gBackupMapLayout.width * y] &= ~MAPGRID_COLLISION_MASK;
    }
}

static bool8 SkipCopyingMetatileFromSavedMap(u16 *mapBlock, u16 mapWidth, u8 yMode)
{
    if (yMode == 0xFF)
        return FALSE;

    if (yMode == 0)
        mapBlock -= mapWidth;
    else
        mapBlock += mapWidth;

    if (IsLargeBreakableDecoration(UNPACK_METATILE(*mapBlock), yMode) == TRUE)
        return TRUE;
    return FALSE;
}

static void CopyTilesetToVram(struct Tileset const *tileset, u16 numTiles, u16 offset)
{
    if (tileset)
    {
        if (!tileset->isCompressed)
            LoadBgTiles(2, tileset->tiles, numTiles * 32, offset);
        else
            DecompressAndCopyTileDataToVram(2, tileset->tiles, numTiles * 32, offset, 0);
    }
}

static void CopyTilesetToVramUsingHeap(struct Tileset const *tileset, u16 numTiles, u16 offset)
{
    if (tileset)
    {
        if (!tileset->isCompressed)
            LoadBgTiles(2, tileset->tiles, numTiles * 32, offset);
        else
            DecompressAndLoadBgGfxUsingHeap(2, tileset->tiles, numTiles * 32, offset, 0);
    }
}

// Below two are dummied functions from FRLG, used to tint the overworld palettes for the Quest Log
static void ApplyGlobalTintToPaletteEntries(u16 offset, u16 size)
{

}

static void UNUSED ApplyGlobalTintToPaletteSlot(u8 slot, u8 count)
{

}

static void LoadTilesetPalette(struct Tileset const *tileset, u16 destOffset, u16 size, bool8 skipFaded, u32 numPalsInPrimary)
{
    if (tileset)
    {
        if (tileset->isSecondary == FALSE)
        {
            if (skipFaded)
                CpuFastCopy(tileset->palettes, &gPlttBufferUnfaded[destOffset], size); // always word-aligned
            else
                LoadPaletteFast(tileset->palettes, destOffset, size);
            gPlttBufferFaded[destOffset] = gPlttBufferUnfaded[destOffset] = RGB_BLACK;
            ApplyGlobalTintToPaletteEntries(destOffset + 1, (size - 2) >> 1);
        }
        else if (tileset->isSecondary == TRUE)
        {
            // All 'gTilesetPalettes_' arrays should have ALIGNED(4) in them,
            // but we use SmartCopy here just in case they don't
            if (skipFaded)
                CpuCopy16(tileset->palettes[numPalsInPrimary], &gPlttBufferUnfaded[destOffset], size);
            else
                LoadPaletteFast(tileset->palettes[numPalsInPrimary], destOffset, size);
        }
        else
        {
            LoadPalette((const u16 *)tileset->palettes, destOffset, size);
            ApplyGlobalTintToPaletteEntries(destOffset, size >> 1);
        }
    }
}

void CopyPrimaryTilesetToVram(struct MapLayout const *mapLayout)
{
    CopyTilesetToVram(mapLayout->primaryTileset, GetNumTilesInPrimary(mapLayout), 0);
}

void CopySecondaryTilesetToVram(struct MapLayout const *mapLayout)
{
    CopyTilesetToVram(mapLayout->secondaryTileset, NUM_TILES_TOTAL - GetNumTilesInPrimary(mapLayout), GetNumTilesInPrimary(mapLayout));
}

void CopySecondaryTilesetToVramUsingHeap(struct MapLayout const *mapLayout)
{
    CopyTilesetToVramUsingHeap(mapLayout->secondaryTileset, NUM_TILES_TOTAL - GetNumTilesInPrimary(mapLayout), GetNumTilesInPrimary(mapLayout));
}

static void LoadPrimaryTilesetPalette(struct MapLayout const *mapLayout)
{
    LoadTilesetPalette(mapLayout->primaryTileset, 0, GetNumPalsInPrimary(mapLayout) * PLTT_SIZE_4BPP, FALSE, GetNumPalsInPrimary(mapLayout));
}

void LoadSecondaryTilesetPalette(struct MapLayout const *mapLayout, bool8 skipFaded)
{
    LoadTilesetPalette(mapLayout->secondaryTileset, GetNumPalsInPrimary(mapLayout) * 16, (NUM_PALS_TOTAL - GetNumPalsInPrimary(mapLayout)) * PLTT_SIZE_4BPP, skipFaded, GetNumPalsInPrimary(mapLayout));
}

void CopyMapTilesetsToVram(struct MapLayout const *mapLayout)
{
    if (mapLayout)
    {
        CopyTilesetToVramUsingHeap(mapLayout->primaryTileset, GetNumTilesInPrimary(mapLayout), 0);
        CopyTilesetToVramUsingHeap(mapLayout->secondaryTileset, NUM_TILES_TOTAL - GetNumTilesInPrimary(mapLayout), GetNumTilesInPrimary(mapLayout));
    }
}

void LoadMapTilesetPalettes(struct MapLayout const *mapLayout)
{
    if (mapLayout)
    {
        LoadPrimaryTilesetPalette(mapLayout);
        LoadSecondaryTilesetPalette(mapLayout, FALSE);
    }
}
