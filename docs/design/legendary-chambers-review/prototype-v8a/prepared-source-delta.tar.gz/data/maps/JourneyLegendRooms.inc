JourneyLegendRoom0144_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0145_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0146_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0249_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0250_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0382_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0383_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0384_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0377_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0378_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0379_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0486_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0894_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0895_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0251_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0488_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0491_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0643_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0644_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0646_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0380_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0381_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0480_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0481_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0482_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0489_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0490_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0483_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0484_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0487_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0493_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0641_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0642_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0645_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0905_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0789_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0790_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0791_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0792_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0800_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0793_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0243_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0244_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0245_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0638_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0639_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0640_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0647_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0716_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0717_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0718_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0150_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0151_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0785_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0786_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0787_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0788_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0888_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0889_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0890_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0896_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0897_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0898_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom1014_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom1015_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom1016_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom1017_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom1025_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0796_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0794_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0795_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0797_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0798_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0799_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0803_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0804_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0805_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0806_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0772_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0773_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0808_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0809_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0891_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0892_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom1001_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom1002_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom1003_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom1004_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom1007_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom1008_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom1024_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0385_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0386_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0485_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0494_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0648_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0649_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0719_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0720_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0721_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0801_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0802_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0807_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0893_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0

JourneyLegendRoom0492_MapScripts::
	map_script MAP_SCRIPT_ON_TRANSITION, JourneySanctuary_Sync
	.byte 0
