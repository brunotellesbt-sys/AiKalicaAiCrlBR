#include "global.h"
#include "journey_world_dex.h"
#include "journey_habitats.h"
#include "bg.h"
#include "decompress.h"
#include "event_data.h"
#include "gpu_regs.h"
#include "graphics.h"
#include "international_string_util.h"
#include "main.h"
#include "malloc.h"
#include "menu.h"
#include "overworld.h"
#include "palette.h"
#include "pokedex.h"
#include "pokedex_area_screen.h"
#include "regions.h"
#include "region_map.h"
#include "roamer.h"
#include "rtc.h"
#include "sound.h"
#include "string_util.h"
#include "text.h"
#include "text_window.h"
#include "trig.h"
#include "pokedex_area_region_map.h"
#include "wild_encounter.h"
#include "window.h"
#include "constants/region_map_sections.h"
#include "constants/rgb.h"
#include "constants/songs.h"
#include "config/pokedex_plus_hgss.h"

// There are two types of indicators for the area screen to show where a Pokémon can occur:
// - Area glows, which highlight any of the maps in MAP_GROUP_TOWNS_AND_ROUTES that have the species.
//   These are a tilemap with colored rectangular areas that blends in and out. The positions of the
//   rectangles is determined by the positions of the matching MAPSEC values on the region map layout.
// - Area markers, which highlight any of the maps in MAP_GROUP_DUNGEONS or MAP_GROUP_SPECIAL_AREA that
//   have the species. These are circular sprites that flash twice. The positions of the sprites is
//   determined by the data for the corresponding MAPSEC in gRegionMapEntries.

// Only maps in the following map groups have their encounters considered for the area screen
#define MAP_GROUP_TOWNS_AND_ROUTES MAP_GROUP(MAP_PETALBURG_CITY)
#define MAP_GROUP_TOWNS_AND_ROUTES_FRLG MAP_GROUP(MAP_PALLET_TOWN)
#define MAP_GROUP_DUNGEONS MAP_GROUP(MAP_METEOR_FALLS_1F_1R)
#define MAP_GROUP_DUNGEONS_FRLG MAP_GROUP(MAP_VIRIDIAN_FOREST)
#define MAP_GROUP_SPECIAL_AREA MAP_GROUP(MAP_SAFARI_ZONE_NORTHWEST)
#define MAP_GROUP_SPECIAL_AREA_FRLG MAP_GROUP(MAP_NAVEL_ROCK_EXTERIOR_FRLG)

#define AREA_SCREEN_WIDTH 32
#define AREA_SCREEN_HEIGHT 20

#define GLOW_FULL      0xFFFF
#define GLOW_EDGE_R    (1 << 0)
#define GLOW_EDGE_L    (1 << 1)
#define GLOW_EDGE_B    (1 << 2)
#define GLOW_EDGE_T    (1 << 3)
#define GLOW_CORNER_TL (1 << 4)
#define GLOW_CORNER_BL (1 << 5)
#define GLOW_CORNER_TR (1 << 6)
#define GLOW_CORNER_BR (1 << 7)

#define GLOW_PALETTE 10

#define TAG_AREA_MARKER 2
#define TAG_AREA_UNKNOWN 3

#define MAX_AREA_HIGHLIGHTS 64 // Maximum number of rectangular route highlights
#define MAX_AREA_MARKERS 32 // Maximum number of circular spot highlights

#define LABEL_WINDOW_BG 1
#define NUM_LABEL_WINDOWS 2

enum PokedexAreaLabels
{
    DEX_AREA_LABEL_TIME_OF_DAY,
    DEX_AREA_LABEL_AREA_UNKNOWN
};

struct OverworldArea
{
    u8 mapGroup;
    u8 mapNum;
    mapsec_u16_t regionMapSectionId;
};

struct
{
    /*0x000*/ void (*callback)(void); // unused
    /*0x004*/ MainCallback prev; // unused
    /*0x008*/ MainCallback next; // unused
    /*0x00C*/ u16 state; // unused
    /*0x00E*/ enum Species species;
    /*0x010*/ struct OverworldArea overworldAreasWithMons[MAX_AREA_HIGHLIGHTS];
    /*0x110*/ u16 numOverworldAreas;
    /*0x112*/ u16 numSpecialAreas;
    /*0x114*/ u16 drawAreaGlowState;
    /*0x116*/ u16 areaGlowTilemap[AREA_SCREEN_WIDTH * AREA_SCREEN_HEIGHT];
    /*0x616*/ u16 markerTimer;
    /*0x618*/ u16 glowTimer;
    /*0x61A*/ u16 areaShadeBldArgLo;
    /*0x61C*/ u16 areaShadeBldArgHi;
    /*0x61E*/ bool8 showingMarkers;
    /*0x61F*/ u8 markerFlashCounter;
    /*0x620*/ mapsec_u16_t specialAreaRegionMapSectionIds[MAX_AREA_MARKERS];
    /*0x660*/ struct Sprite *areaMarkerSprites[MAX_AREA_MARKERS];
    /*0x6E0*/ u16 numAreaMarkerSprites;
    /*0x6E2*/ u16 alteringCaveCounter;
    /*0x6E4*/ u16 alteringCaveId;
    /*0x6E8*/ u8 *screenSwitchState;
    /*0x6EC*/ struct RegionMap regionMap;
    /*0xF70*/ u8 charBuffer[64];
    /*0xFB0*/ struct Sprite *areaUnknownSprites[3];
    /*0xFBC*/ u8 areaUnknownGraphicsBuffer[0x600];
    /*0xFC0*/ u8 areaScreenLabelIds[NUM_LABEL_WINDOWS];
    /*0xFC8*/ u8 areaState;
} static EWRAM_DATA *sPokedexAreaScreen = NULL;

EWRAM_DATA u8 gAreaTimeOfDay = 0;

static void FindMapsWithMon(enum Species);
static void BuildAreaGlowTilemap(void);
static void SetAreaHasMon(u16, u16);
static void SetSpecialMapHasMon(u16, u16);
static mapsec_u16_t GetRegionMapSectionId(u8, u8);
static bool8 MapHasSpecies(const struct WildEncounterTypes *, enum Species);
static bool8 MonListHasSpecies(const struct WildPokemonInfo *, enum Species, u16);
static void DoAreaGlow(void);
static void Task_ShowPokedexAreaScreen(u8 taskId);
static void Task_UpdatePokedexAreaScreen(u8 taskId);
static void CreateAreaMarkerSprites(void);
static void LoadAreaUnknownGraphics(void);
static void CreateAreaUnknownSprites(void);
static void Task_HandlePokedexAreaScreenInput(u8);
static void ResetPokedexAreaMapBg(void);
static void DestroyAreaScreenSprites(void);
static void AddTimeOfDayLabels(void);
static void ShowEncounterInfoLabel(void);
static void ShowAreaUnknownLabel(void);
static void PrintAreaLabelText(const u8 *text, enum PokedexAreaLabels labelId, int textXPos);
static void ClearAreaWindowLabel(enum PokedexAreaLabels labelId);

bool32 ShouldShowAreaUnknownLabel(void);

static const u32 sAreaGlow_Pal[] = INCBIN_U32("graphics/pokedex/area_glow.gbapal");
static const u32 sAreaGlow_Gfx[] = INCBIN_U32("graphics/pokedex/area_glow.4bpp.smol");

static const u32 sPokedexPlusHGSS_ScreenSelectBarSubmenu_Tilemap[] = INCBIN_U32("graphics/pokedex/hgss/SelectBar.bin.smolTM");
static void LoadHGSSScreenSelectBarSubmenu(void);

static const u16 sSpeciesHiddenFromAreaScreen[] = { SPECIES_WYNAUT };

static const mapsec_u16_t sMovingRegionMapSections[3] =
{
    MAPSEC_MARINE_CAVE,
    MAPSEC_UNDERWATER_MARINE_CAVE,
    MAPSEC_TERRA_CAVE
};

static const u16 sFeebasData[][3] =
{
    {SPECIES_FEEBAS, MAP_GROUP(MAP_ROUTE119), MAP_NUM(MAP_ROUTE119)},
    {NUM_SPECIES}
};

static const mapsec_u16_t sLandmarkData[][2] =
{
    {MAPSEC_SKY_PILLAR,       FLAG_LANDMARK_SKY_PILLAR},
    {MAPSEC_SEAFLOOR_CAVERN,  FLAG_LANDMARK_SEAFLOOR_CAVERN},
    {MAPSEC_ALTERING_CAVE,    FLAG_LANDMARK_ALTERING_CAVE},
    {MAPSEC_MIRAGE_TOWER,     FLAG_LANDMARK_MIRAGE_TOWER},
    {MAPSEC_DESERT_UNDERPASS, FLAG_LANDMARK_DESERT_UNDERPASS},
    {MAPSEC_ARTISAN_CAVE,     FLAG_LANDMARK_ARTISAN_CAVE},
    {MAPSEC_NONE}
};

#include "data/pokedex_area_glow.h"

static const u8 sAreaMarkerTiles[];
static const struct SpriteSheet sAreaMarkerSpriteSheet =
{
    .data = sAreaMarkerTiles, .size = 0x80, .tag = TAG_AREA_MARKER
};

static const u16 sAreaMarkerPalette[];
static const struct SpritePalette sAreaMarkerSpritePalette =
{
    .data = sAreaMarkerPalette, .tag = TAG_AREA_MARKER
};

static const struct OamData sAreaMarkerOamData =
{
    .shape = SPRITE_SHAPE(16x16),
    .size = SPRITE_SIZE(16x16),
    .priority = 1
};

static const struct SpriteTemplate sAreaMarkerSpriteTemplate =
{
    .tileTag = TAG_AREA_MARKER,
    .paletteTag = TAG_AREA_MARKER,
    .oam = &sAreaMarkerOamData,
};

static const u16 sAreaMarkerPalette[] = INCBIN_U16("graphics/pokedex/area_marker.gbapal");
static const u8 sAreaMarkerTiles[] = INCBIN_U8("graphics/pokedex/area_marker.4bpp");

static const struct SpritePalette sAreaUnknownSpritePalette =
{
    .data = gPokedexAreaScreenAreaUnknown_Pal, .tag = TAG_AREA_UNKNOWN
};

static const struct OamData sAreaUnknownOamData =
{
    .shape = SPRITE_SHAPE(32x32),
    .size = SPRITE_SIZE(32x32),
    .priority = 1
};

static const struct SpriteTemplate sAreaUnknownSpriteTemplate =
{
    .tileTag = TAG_AREA_UNKNOWN,
    .paletteTag = TAG_AREA_UNKNOWN,
    .oam = &sAreaUnknownOamData,
};

static const u8 sFontColor_AreaInfo[3] = {TEXT_COLOR_TRANSPARENT, TEXT_COLOR_WHITE, 5};
static const struct WindowTemplate sTimeOfDayWindowLabelTemplates[] =
{
    [DEX_AREA_LABEL_TIME_OF_DAY] =
    {
        .bg = LABEL_WINDOW_BG,
        .tilemapLeft = 22,
        .tilemapTop = 18,
        .width = 8,
        .height = 2,
        .paletteNum = 0,
        .baseBlock = 0x16C
    },

    [DEX_AREA_LABEL_AREA_UNKNOWN] =
    {
        .bg = LABEL_WINDOW_BG,
        .tilemapLeft = 12,
        .tilemapTop = 18,
        .width = 10,
        .height = 2,
        .paletteNum = 0,
        .baseBlock = 0x240
    }
};

static void ResetDrawAreaGlowState(void)
{
    sPokedexAreaScreen->drawAreaGlowState = 0;
}

static bool8 DrawAreaGlow(void)
{
    switch (sPokedexAreaScreen->drawAreaGlowState)
    {
    case 0:
        FindMapsWithMon(sPokedexAreaScreen->species);
        break;
    case 1:
        BuildAreaGlowTilemap();
        break;
    case 2:
        DecompressAndCopyTileDataToVram(2, sAreaGlow_Gfx, 0, 0, 0);
        LoadBgTilemap(2, sPokedexAreaScreen->areaGlowTilemap, sizeof(sPokedexAreaScreen->areaGlowTilemap), 0);
        break;
    case 3:
        if (!FreeTempTileDataBuffersIfPossible())
        {
            CpuCopy32(sAreaGlow_Pal, &gPlttBufferUnfaded[BG_PLTT_ID(GLOW_PALETTE)], sizeof(sAreaGlow_Pal));
            sPokedexAreaScreen->drawAreaGlowState++;
        }
        return TRUE;
    case 4:
        ChangeBgY(2, -BG_SCREEN_SIZE, BG_COORD_SET);
        break;
    default:
        return FALSE;
    }

    sPokedexAreaScreen->drawAreaGlowState++;
    return TRUE;
}

static void FindMapsWithMon(enum Species species)
{
    enum RegionMapType currentRegionMapType;
    u16 i;
    struct Roamer *roamer;

    sPokedexAreaScreen->alteringCaveCounter = 0;
    sPokedexAreaScreen->alteringCaveId = VarGet(VAR_ALTERING_CAVE_WILD_SET);
    if (sPokedexAreaScreen->alteringCaveId >= NUM_ALTERING_CAVE_TABLES)
        sPokedexAreaScreen->alteringCaveId = 0;

    sPokedexAreaScreen->numOverworldAreas = 0;
    sPokedexAreaScreen->numSpecialAreas = 0;

    // Check if this species should be hidden from the area map.
    // This only applies to Wynaut, to hide the encounters on Mirage Island.
    for (i = 0; i < ARRAY_COUNT(sSpeciesHiddenFromAreaScreen); i++)
    {
        if (FALSE && sSpeciesHiddenFromAreaScreen[i] == species)
            return;
    }

    // Add Pokémon with special encounter circumstances (i.e. not listed
    // in the regular wild encounter table) to the area map.
    // This only applies to Feebas on Route 119, but it was clearly set
    // up to allow handling others.
    for (i = 0; FALSE && sFeebasData[i][0] != NUM_SPECIES; i++)
    {
        if (species == sFeebasData[i][0])
        {
            switch (sFeebasData[i][1])
            {
            case MAP_GROUP_TOWNS_AND_ROUTES:
            case MAP_GROUP_TOWNS_AND_ROUTES_FRLG:
                SetAreaHasMon(sFeebasData[i][1], sFeebasData[i][2]);
                break;
            case MAP_GROUP_DUNGEONS:
            case MAP_GROUP_DUNGEONS_FRLG:
            case MAP_GROUP_SPECIAL_AREA:
            case MAP_GROUP_SPECIAL_AREA_FRLG:
                SetSpecialMapHasMon(sFeebasData[i][1], sFeebasData[i][2]);
                break;
            }
        }
    }

    currentRegionMapType = GetRegionMapType(gMapHeader.regionMapSectionId);
    // Add regular species to the area map
    for (i = 0; gWildMonHeaders[i].mapGroup != MAP_GROUP(MAP_UNDEFINED); i++)
    {
        u32 headerSectionId = Overworld_GetMapHeaderByGroupAndId(gWildMonHeaders[i].mapGroup, gWildMonHeaders[i].mapNum)->regionMapSectionId;

        if (GetRegionMapType(headerSectionId) != currentRegionMapType)
            continue;

        if (JourneyHabitatHasSpecies(gWildMonHeaders[i].mapGroup, gWildMonHeaders[i].mapNum, species))
        {
            switch (gWildMonHeaders[i].mapGroup)
            {
            case MAP_GROUP_TOWNS_AND_ROUTES:
            case MAP_GROUP_TOWNS_AND_ROUTES_FRLG:
                SetAreaHasMon(gWildMonHeaders[i].mapGroup, gWildMonHeaders[i].mapNum);
                break;
            case MAP_GROUP_DUNGEONS:
            case MAP_GROUP_DUNGEONS_FRLG:
            case MAP_GROUP_SPECIAL_AREA:
            case MAP_GROUP_SPECIAL_AREA_FRLG:
                SetSpecialMapHasMon(gWildMonHeaders[i].mapGroup, gWildMonHeaders[i].mapNum);
                break;
            default:
                SetAreaHasMon(gWildMonHeaders[i].mapGroup, gWildMonHeaders[i].mapNum);
                break;
            }
        }
    }

    if (species == SPECIES_ARTICUNO && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0144), MAP_NUM(MAP_JOURNEYLEGENDROOM0144))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0144), MAP_NUM(MAP_JOURNEYLEGENDROOM0144));
    if (species == SPECIES_ZAPDOS && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0145), MAP_NUM(MAP_JOURNEYLEGENDROOM0145))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0145), MAP_NUM(MAP_JOURNEYLEGENDROOM0145));
    if (species == SPECIES_RAIKOU && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0243), MAP_NUM(MAP_JOURNEYLEGENDROOM0243))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0243), MAP_NUM(MAP_JOURNEYLEGENDROOM0243));
    if (species == SPECIES_TORNADUS_INCARNATE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0641), MAP_NUM(MAP_JOURNEYLEGENDROOM0641))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0641), MAP_NUM(MAP_JOURNEYLEGENDROOM0641));
    if (species == SPECIES_THUNDURUS_INCARNATE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0642), MAP_NUM(MAP_JOURNEYLEGENDROOM0642))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0642), MAP_NUM(MAP_JOURNEYLEGENDROOM0642));
    if (species == SPECIES_XURKITREE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0796), MAP_NUM(MAP_JOURNEYLEGENDROOM0796))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0796), MAP_NUM(MAP_JOURNEYLEGENDROOM0796));
    if (species == SPECIES_ZERAORA && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0807), MAP_NUM(MAP_JOURNEYLEGENDROOM0807))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0807), MAP_NUM(MAP_JOURNEYLEGENDROOM0807));
    if (species == SPECIES_REGIELEKI && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0894), MAP_NUM(MAP_JOURNEYLEGENDROOM0894))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0894), MAP_NUM(MAP_JOURNEYLEGENDROOM0894));
    if (species == SPECIES_MEWTWO && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0150), MAP_NUM(MAP_JOURNEYLEGENDROOM0150))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0150), MAP_NUM(MAP_JOURNEYLEGENDROOM0150));
    if (species == SPECIES_DEOXYS_NORMAL && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0386), MAP_NUM(MAP_JOURNEYLEGENDROOM0386))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0386), MAP_NUM(MAP_JOURNEYLEGENDROOM0386));
    if (species == SPECIES_AZELF && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0482), MAP_NUM(MAP_JOURNEYLEGENDROOM0482))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0482), MAP_NUM(MAP_JOURNEYLEGENDROOM0482));
    if (species == SPECIES_MELOETTA_ARIA && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0648), MAP_NUM(MAP_JOURNEYLEGENDROOM0648))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0648), MAP_NUM(MAP_JOURNEYLEGENDROOM0648));
    if (species == SPECIES_TAPU_KOKO && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0785), MAP_NUM(MAP_JOURNEYLEGENDROOM0785))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0785), MAP_NUM(MAP_JOURNEYLEGENDROOM0785));
    if (species == SPECIES_NECROZMA && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0800), MAP_NUM(MAP_JOURNEYLEGENDROOM0800))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0800), MAP_NUM(MAP_JOURNEYLEGENDROOM0800));
    if (species == SPECIES_ZACIAN_HERO && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0888), MAP_NUM(MAP_JOURNEYLEGENDROOM0888))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0888), MAP_NUM(MAP_JOURNEYLEGENDROOM0888));
    if (species == SPECIES_FEZANDIPITI && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM1016), MAP_NUM(MAP_JOURNEYLEGENDROOM1016))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM1016), MAP_NUM(MAP_JOURNEYLEGENDROOM1016));
    if (species == SPECIES_MOLTRES && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0146), MAP_NUM(MAP_JOURNEYLEGENDROOM0146))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0146), MAP_NUM(MAP_JOURNEYLEGENDROOM0146));
    if (species == SPECIES_ENTEI && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0244), MAP_NUM(MAP_JOURNEYLEGENDROOM0244))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0244), MAP_NUM(MAP_JOURNEYLEGENDROOM0244));
    if (species == SPECIES_HO_OH && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0250), MAP_NUM(MAP_JOURNEYLEGENDROOM0250))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0250), MAP_NUM(MAP_JOURNEYLEGENDROOM0250));
    if (species == SPECIES_GROUDON && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0383), MAP_NUM(MAP_JOURNEYLEGENDROOM0383))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0383), MAP_NUM(MAP_JOURNEYLEGENDROOM0383));
    if (species == SPECIES_LANDORUS_INCARNATE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0645), MAP_NUM(MAP_JOURNEYLEGENDROOM0645))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0645), MAP_NUM(MAP_JOURNEYLEGENDROOM0645));
    if (species == SPECIES_BLACEPHALON && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0806), MAP_NUM(MAP_JOURNEYLEGENDROOM0806))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0806), MAP_NUM(MAP_JOURNEYLEGENDROOM0806));
    if (species == SPECIES_TING_LU && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM1003), MAP_NUM(MAP_JOURNEYLEGENDROOM1003))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM1003), MAP_NUM(MAP_JOURNEYLEGENDROOM1003));
    if (species == SPECIES_CHI_YU && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM1004), MAP_NUM(MAP_JOURNEYLEGENDROOM1004))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM1004), MAP_NUM(MAP_JOURNEYLEGENDROOM1004));
    if (species == SPECIES_REGIROCK && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0377), MAP_NUM(MAP_JOURNEYLEGENDROOM0377))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0377), MAP_NUM(MAP_JOURNEYLEGENDROOM0377));
    if (species == SPECIES_REGISTEEL && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0379), MAP_NUM(MAP_JOURNEYLEGENDROOM0379))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0379), MAP_NUM(MAP_JOURNEYLEGENDROOM0379));
    if (species == SPECIES_HEATRAN && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0485), MAP_NUM(MAP_JOURNEYLEGENDROOM0485))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0485), MAP_NUM(MAP_JOURNEYLEGENDROOM0485));
    if (species == SPECIES_DIANCIE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0719), MAP_NUM(MAP_JOURNEYLEGENDROOM0719))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0719), MAP_NUM(MAP_JOURNEYLEGENDROOM0719));
    if (species == SPECIES_SOLGALEO && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0791), MAP_NUM(MAP_JOURNEYLEGENDROOM0791))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0791), MAP_NUM(MAP_JOURNEYLEGENDROOM0791));
    if (species == SPECIES_CELESTEELA && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0797), MAP_NUM(MAP_JOURNEYLEGENDROOM0797))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0797), MAP_NUM(MAP_JOURNEYLEGENDROOM0797));
    if (species == SPECIES_STAKATAKA && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0805), MAP_NUM(MAP_JOURNEYLEGENDROOM0805))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0805), MAP_NUM(MAP_JOURNEYLEGENDROOM0805));
    if (species == SPECIES_MELTAN && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0808), MAP_NUM(MAP_JOURNEYLEGENDROOM0808))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0808), MAP_NUM(MAP_JOURNEYLEGENDROOM0808));
    if (species == SPECIES_MELMETAL && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0809), MAP_NUM(MAP_JOURNEYLEGENDROOM0809))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0809), MAP_NUM(MAP_JOURNEYLEGENDROOM0809));
    if (species == SPECIES_CELEBI && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0251), MAP_NUM(MAP_JOURNEYLEGENDROOM0251))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0251), MAP_NUM(MAP_JOURNEYLEGENDROOM0251));
    if (species == SPECIES_SHAYMIN_LAND && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0492), MAP_NUM(MAP_JOURNEYLEGENDROOM0492))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0492), MAP_NUM(MAP_JOURNEYLEGENDROOM0492));
    if (species == SPECIES_VIRIZION && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0640), MAP_NUM(MAP_JOURNEYLEGENDROOM0640))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0640), MAP_NUM(MAP_JOURNEYLEGENDROOM0640));
    if (species == SPECIES_SILVALLY_NORMAL && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0773), MAP_NUM(MAP_JOURNEYLEGENDROOM0773))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0773), MAP_NUM(MAP_JOURNEYLEGENDROOM0773));
    if (species == SPECIES_TAPU_BULU && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0787), MAP_NUM(MAP_JOURNEYLEGENDROOM0787))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0787), MAP_NUM(MAP_JOURNEYLEGENDROOM0787));
    if (species == SPECIES_KARTANA && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0798), MAP_NUM(MAP_JOURNEYLEGENDROOM0798))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0798), MAP_NUM(MAP_JOURNEYLEGENDROOM0798));
    if (species == SPECIES_CALYREX && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0898), MAP_NUM(MAP_JOURNEYLEGENDROOM0898))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0898), MAP_NUM(MAP_JOURNEYLEGENDROOM0898));
    if (species == SPECIES_OGERPON_TEAL && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM1017), MAP_NUM(MAP_JOURNEYLEGENDROOM1017))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM1017), MAP_NUM(MAP_JOURNEYLEGENDROOM1017));
    if (species == SPECIES_REGIGIGAS && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0486), MAP_NUM(MAP_JOURNEYLEGENDROOM0486))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0486), MAP_NUM(MAP_JOURNEYLEGENDROOM0486));
    if (species == SPECIES_GIRATINA_ALTERED && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0487), MAP_NUM(MAP_JOURNEYLEGENDROOM0487))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0487), MAP_NUM(MAP_JOURNEYLEGENDROOM0487));
    if (species == SPECIES_DARKRAI && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0491), MAP_NUM(MAP_JOURNEYLEGENDROOM0491))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0491), MAP_NUM(MAP_JOURNEYLEGENDROOM0491));
    if (species == SPECIES_YVELTAL && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0717), MAP_NUM(MAP_JOURNEYLEGENDROOM0717))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0717), MAP_NUM(MAP_JOURNEYLEGENDROOM0717));
    if (species == SPECIES_GUZZLORD && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0799), MAP_NUM(MAP_JOURNEYLEGENDROOM0799))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0799), MAP_NUM(MAP_JOURNEYLEGENDROOM0799));
    if (species == SPECIES_MARSHADOW && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0802), MAP_NUM(MAP_JOURNEYLEGENDROOM0802))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0802), MAP_NUM(MAP_JOURNEYLEGENDROOM0802));
    if (species == SPECIES_SPECTRIER && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0897), MAP_NUM(MAP_JOURNEYLEGENDROOM0897))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0897), MAP_NUM(MAP_JOURNEYLEGENDROOM0897));
    if (species == SPECIES_PECHARUNT && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM1025), MAP_NUM(MAP_JOURNEYLEGENDROOM1025))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM1025), MAP_NUM(MAP_JOURNEYLEGENDROOM1025));
    if (species == SPECIES_RAYQUAZA && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0384), MAP_NUM(MAP_JOURNEYLEGENDROOM0384))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0384), MAP_NUM(MAP_JOURNEYLEGENDROOM0384));
    if (species == SPECIES_DIALGA && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0483), MAP_NUM(MAP_JOURNEYLEGENDROOM0483))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0483), MAP_NUM(MAP_JOURNEYLEGENDROOM0483));
    if (species == SPECIES_COBALION && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0638), MAP_NUM(MAP_JOURNEYLEGENDROOM0638))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0638), MAP_NUM(MAP_JOURNEYLEGENDROOM0638));
    if (species == SPECIES_RESHIRAM && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0643), MAP_NUM(MAP_JOURNEYLEGENDROOM0643))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0643), MAP_NUM(MAP_JOURNEYLEGENDROOM0643));
    if (species == SPECIES_ZYGARDE_50 && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0718), MAP_NUM(MAP_JOURNEYLEGENDROOM0718))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0718), MAP_NUM(MAP_JOURNEYLEGENDROOM0718));
    if (species == SPECIES_NAGANADEL && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0804), MAP_NUM(MAP_JOURNEYLEGENDROOM0804))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0804), MAP_NUM(MAP_JOURNEYLEGENDROOM0804));
    if (species == SPECIES_ZAMAZENTA_HERO && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0889), MAP_NUM(MAP_JOURNEYLEGENDROOM0889))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0889), MAP_NUM(MAP_JOURNEYLEGENDROOM0889));
    if (species == SPECIES_KUBFU && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0891), MAP_NUM(MAP_JOURNEYLEGENDROOM0891))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0891), MAP_NUM(MAP_JOURNEYLEGENDROOM0891));
    if (species == SPECIES_KORAIDON && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM1007), MAP_NUM(MAP_JOURNEYLEGENDROOM1007))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM1007), MAP_NUM(MAP_JOURNEYLEGENDROOM1007));
    if (species == SPECIES_MEW && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0151), MAP_NUM(MAP_JOURNEYLEGENDROOM0151))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0151), MAP_NUM(MAP_JOURNEYLEGENDROOM0151));
    if (species == SPECIES_UXIE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0480), MAP_NUM(MAP_JOURNEYLEGENDROOM0480))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0480), MAP_NUM(MAP_JOURNEYLEGENDROOM0480));
    if (species == SPECIES_CRESSELIA && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0488), MAP_NUM(MAP_JOURNEYLEGENDROOM0488))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0488), MAP_NUM(MAP_JOURNEYLEGENDROOM0488));
    if (species == SPECIES_XERNEAS_NEUTRAL && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0716), MAP_NUM(MAP_JOURNEYLEGENDROOM0716))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0716), MAP_NUM(MAP_JOURNEYLEGENDROOM0716));
    if (species == SPECIES_TAPU_LELE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0786), MAP_NUM(MAP_JOURNEYLEGENDROOM0786))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0786), MAP_NUM(MAP_JOURNEYLEGENDROOM0786));
    if (species == SPECIES_MAGEARNA && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0801), MAP_NUM(MAP_JOURNEYLEGENDROOM0801))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0801), MAP_NUM(MAP_JOURNEYLEGENDROOM0801));
    if (species == SPECIES_ENAMORUS_INCARNATE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0905), MAP_NUM(MAP_JOURNEYLEGENDROOM0905))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0905), MAP_NUM(MAP_JOURNEYLEGENDROOM0905));
    if (species == SPECIES_REGICE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0378), MAP_NUM(MAP_JOURNEYLEGENDROOM0378))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0378), MAP_NUM(MAP_JOURNEYLEGENDROOM0378));
    if (species == SPECIES_TERRAKION && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0639), MAP_NUM(MAP_JOURNEYLEGENDROOM0639))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0639), MAP_NUM(MAP_JOURNEYLEGENDROOM0639));
    if (species == SPECIES_KYUREM && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0646), MAP_NUM(MAP_JOURNEYLEGENDROOM0646))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0646), MAP_NUM(MAP_JOURNEYLEGENDROOM0646));
    if (species == SPECIES_NIHILEGO && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0793), MAP_NUM(MAP_JOURNEYLEGENDROOM0793))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0793), MAP_NUM(MAP_JOURNEYLEGENDROOM0793));
    if (species == SPECIES_GLASTRIER && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0896), MAP_NUM(MAP_JOURNEYLEGENDROOM0896))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0896), MAP_NUM(MAP_JOURNEYLEGENDROOM0896));
    if (species == SPECIES_CHIEN_PAO && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM1002), MAP_NUM(MAP_JOURNEYLEGENDROOM1002))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM1002), MAP_NUM(MAP_JOURNEYLEGENDROOM1002));
    if (species == SPECIES_SUICUNE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0245), MAP_NUM(MAP_JOURNEYLEGENDROOM0245))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0245), MAP_NUM(MAP_JOURNEYLEGENDROOM0245));
    if (species == SPECIES_PALKIA && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0484), MAP_NUM(MAP_JOURNEYLEGENDROOM0484))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0484), MAP_NUM(MAP_JOURNEYLEGENDROOM0484));
    if (species == SPECIES_MANAPHY && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0490), MAP_NUM(MAP_JOURNEYLEGENDROOM0490))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0490), MAP_NUM(MAP_JOURNEYLEGENDROOM0490));
    if (species == SPECIES_VOLCANION && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0721), MAP_NUM(MAP_JOURNEYLEGENDROOM0721))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0721), MAP_NUM(MAP_JOURNEYLEGENDROOM0721));
    if (species == SPECIES_TERAPAGOS_NORMAL && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM1024), MAP_NUM(MAP_JOURNEYLEGENDROOM1024))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM1024), MAP_NUM(MAP_JOURNEYLEGENDROOM1024));
    if (species == SPECIES_LUGIA && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0249), MAP_NUM(MAP_JOURNEYLEGENDROOM0249))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0249), MAP_NUM(MAP_JOURNEYLEGENDROOM0249));
    if (species == SPECIES_LATIAS && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0380), MAP_NUM(MAP_JOURNEYLEGENDROOM0380))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0380), MAP_NUM(MAP_JOURNEYLEGENDROOM0380));
    if (species == SPECIES_LATIOS && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0381), MAP_NUM(MAP_JOURNEYLEGENDROOM0381))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0381), MAP_NUM(MAP_JOURNEYLEGENDROOM0381));
    if (species == SPECIES_ZEKROM && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0644), MAP_NUM(MAP_JOURNEYLEGENDROOM0644))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0644), MAP_NUM(MAP_JOURNEYLEGENDROOM0644));
    if (species == SPECIES_COSMOG && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0789), MAP_NUM(MAP_JOURNEYLEGENDROOM0789))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0789), MAP_NUM(MAP_JOURNEYLEGENDROOM0789));
    if (species == SPECIES_ETERNATUS && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0890), MAP_NUM(MAP_JOURNEYLEGENDROOM0890))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0890), MAP_NUM(MAP_JOURNEYLEGENDROOM0890));
    if (species == SPECIES_REGIDRAGO && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0895), MAP_NUM(MAP_JOURNEYLEGENDROOM0895))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0895), MAP_NUM(MAP_JOURNEYLEGENDROOM0895));
    if (species == SPECIES_MIRAIDON && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM1008), MAP_NUM(MAP_JOURNEYLEGENDROOM1008))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM1008), MAP_NUM(MAP_JOURNEYLEGENDROOM1008));
    if (species == SPECIES_KYOGRE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0382), MAP_NUM(MAP_JOURNEYLEGENDROOM0382))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0382), MAP_NUM(MAP_JOURNEYLEGENDROOM0382));
    if (species == SPECIES_PHIONE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0489), MAP_NUM(MAP_JOURNEYLEGENDROOM0489))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0489), MAP_NUM(MAP_JOURNEYLEGENDROOM0489));
    if (species == SPECIES_KELDEO_ORDINARY && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0647), MAP_NUM(MAP_JOURNEYLEGENDROOM0647))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0647), MAP_NUM(MAP_JOURNEYLEGENDROOM0647));
    if (species == SPECIES_TAPU_FINI && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0788), MAP_NUM(MAP_JOURNEYLEGENDROOM0788))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0788), MAP_NUM(MAP_JOURNEYLEGENDROOM0788));
    if (species == SPECIES_URSHIFU_SINGLE_STRIKE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0892), MAP_NUM(MAP_JOURNEYLEGENDROOM0892))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0892), MAP_NUM(MAP_JOURNEYLEGENDROOM0892));
    if (species == SPECIES_ZARUDE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0893), MAP_NUM(MAP_JOURNEYLEGENDROOM0893))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0893), MAP_NUM(MAP_JOURNEYLEGENDROOM0893));
    if (species == SPECIES_WO_CHIEN && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM1001), MAP_NUM(MAP_JOURNEYLEGENDROOM1001))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM1001), MAP_NUM(MAP_JOURNEYLEGENDROOM1001));
    if (species == SPECIES_JIRACHI && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0385), MAP_NUM(MAP_JOURNEYLEGENDROOM0385))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0385), MAP_NUM(MAP_JOURNEYLEGENDROOM0385));
    if (species == SPECIES_MESPRIT && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0481), MAP_NUM(MAP_JOURNEYLEGENDROOM0481))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0481), MAP_NUM(MAP_JOURNEYLEGENDROOM0481));
    if (species == SPECIES_VICTINI && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0494), MAP_NUM(MAP_JOURNEYLEGENDROOM0494))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0494), MAP_NUM(MAP_JOURNEYLEGENDROOM0494));
    if (species == SPECIES_HOOPA_CONFINED && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0720), MAP_NUM(MAP_JOURNEYLEGENDROOM0720))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0720), MAP_NUM(MAP_JOURNEYLEGENDROOM0720));
    if (species == SPECIES_COSMOEM && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0790), MAP_NUM(MAP_JOURNEYLEGENDROOM0790))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0790), MAP_NUM(MAP_JOURNEYLEGENDROOM0790));
    if (species == SPECIES_LUNALA && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0792), MAP_NUM(MAP_JOURNEYLEGENDROOM0792))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0792), MAP_NUM(MAP_JOURNEYLEGENDROOM0792));
    if (species == SPECIES_MUNKIDORI && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM1015), MAP_NUM(MAP_JOURNEYLEGENDROOM1015))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM1015), MAP_NUM(MAP_JOURNEYLEGENDROOM1015));
    if (species == SPECIES_ARCEUS_NORMAL && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0493), MAP_NUM(MAP_JOURNEYLEGENDROOM0493))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0493), MAP_NUM(MAP_JOURNEYLEGENDROOM0493));
    if (species == SPECIES_GENESECT && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0649), MAP_NUM(MAP_JOURNEYLEGENDROOM0649))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0649), MAP_NUM(MAP_JOURNEYLEGENDROOM0649));
    if (species == SPECIES_TYPE_NULL && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0772), MAP_NUM(MAP_JOURNEYLEGENDROOM0772))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0772), MAP_NUM(MAP_JOURNEYLEGENDROOM0772));
    if (species == SPECIES_BUZZWOLE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0794), MAP_NUM(MAP_JOURNEYLEGENDROOM0794))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0794), MAP_NUM(MAP_JOURNEYLEGENDROOM0794));
    if (species == SPECIES_PHEROMOSA && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0795), MAP_NUM(MAP_JOURNEYLEGENDROOM0795))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0795), MAP_NUM(MAP_JOURNEYLEGENDROOM0795));
    if (species == SPECIES_POIPOLE && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM0803), MAP_NUM(MAP_JOURNEYLEGENDROOM0803))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM0803), MAP_NUM(MAP_JOURNEYLEGENDROOM0803));
    if (species == SPECIES_OKIDOGI && GetRegionMapType(Overworld_GetMapHeaderByGroupAndId(MAP_GROUP(MAP_JOURNEYLEGENDROOM1014), MAP_NUM(MAP_JOURNEYLEGENDROOM1014))->regionMapSectionId) == currentRegionMapType)
        SetSpecialMapHasMon(MAP_GROUP(MAP_JOURNEYLEGENDROOM1014), MAP_NUM(MAP_JOURNEYLEGENDROOM1014));

    // Add roamers to the area map
    for (i = 0; i < ROAMER_COUNT; i++)
    {
        roamer = &gSaveBlock1Ptr->roamer[i];
        if (species == roamer->species && roamer->active)
        {
            // This is a roamer's species, show where this roamer is currently
            struct OverworldArea *roamerLocation = &sPokedexAreaScreen->overworldAreasWithMons[sPokedexAreaScreen->numOverworldAreas];
            GetRoamerLocation(i, &roamerLocation->mapGroup, &roamerLocation->mapNum);
            roamerLocation->regionMapSectionId = Overworld_GetMapHeaderByGroupAndId(roamerLocation->mapGroup, roamerLocation->mapNum)->regionMapSectionId;
            sPokedexAreaScreen->numOverworldAreas++;
        }
    }
}

static void SetAreaHasMon(u16 mapGroup, u16 mapNum)
{
    if (sPokedexAreaScreen->numOverworldAreas < MAX_AREA_HIGHLIGHTS)
    {
        sPokedexAreaScreen->overworldAreasWithMons[sPokedexAreaScreen->numOverworldAreas].mapGroup = mapGroup;
        sPokedexAreaScreen->overworldAreasWithMons[sPokedexAreaScreen->numOverworldAreas].mapNum = mapNum;
        sPokedexAreaScreen->overworldAreasWithMons[sPokedexAreaScreen->numOverworldAreas].regionMapSectionId = CorrectSpecialMapSecId(Overworld_GetMapHeaderByGroupAndId(mapGroup, mapNum)->regionMapSectionId);
        sPokedexAreaScreen->numOverworldAreas++;
    }
}

static void SetSpecialMapHasMon(u16 mapGroup, u16 mapNum)
{
    int i;

    if (sPokedexAreaScreen->numSpecialAreas < MAX_AREA_MARKERS)
    {
        mapsec_u16_t regionMapSectionId = GetRegionMapSectionId(mapGroup, mapNum);
        if (regionMapSectionId < MAPSEC_NONE)
        {
            // Don't highlight the area if it's a moving area (Marine/Terra Cave)
            for (i = 0; i < ARRAY_COUNT(sMovingRegionMapSections); i++)
            {
                if (regionMapSectionId == sMovingRegionMapSections[i])
                    return;
            }

            // Don't highlight the area if it's an undiscovered landmark (e.g. Sky Pillar)
            for (i = 0; sLandmarkData[i][0] != MAPSEC_NONE; i++)
            {
                if (regionMapSectionId == sLandmarkData[i][0] && !FlagGet(sLandmarkData[i][1]))
                    return;
            }

            // Check if this special area is already being tracked
            for (i = 0; i < sPokedexAreaScreen->numSpecialAreas; i++)
            {
                if (sPokedexAreaScreen->specialAreaRegionMapSectionIds[i] == regionMapSectionId)
                    break;
            }

            if (i == sPokedexAreaScreen->numSpecialAreas)
            {
                // New special area
                sPokedexAreaScreen->specialAreaRegionMapSectionIds[i] = regionMapSectionId;
                sPokedexAreaScreen->numSpecialAreas++;
            }
        }
    }
}

static mapsec_u16_t GetRegionMapSectionId(u8 mapGroup, u8 mapNum)
{
    return Overworld_GetMapHeaderByGroupAndId(mapGroup, mapNum)->regionMapSectionId;
}

static bool8 MapHasSpecies(const struct WildEncounterTypes *info, enum Species species)
{
    u32 headerId = GetCurrentMapWildMonHeaderId();
    u8 currentMapGroup = gWildMonHeaders[headerId].mapGroup;
    u8 currentMapNum = gWildMonHeaders[headerId].mapNum;
    // If this is a header for Altering Cave, skip it if it's not the current Altering Cave encounter set
    if (GetRegionMapSectionId(currentMapGroup, currentMapNum) == MAPSEC_ALTERING_CAVE)
    {
        sPokedexAreaScreen->alteringCaveCounter++;
        if (sPokedexAreaScreen->alteringCaveCounter != sPokedexAreaScreen->alteringCaveId + 1)
            return FALSE;
    }

    if (MonListHasSpecies(info->landMonsInfo, species, LAND_WILD_COUNT))
        return TRUE;
    if (MonListHasSpecies(info->waterMonsInfo, species, WATER_WILD_COUNT))
        return TRUE;
// When searching the fishing encounters, this incorrectly uses the size of the land encounters.
// As a result it's reading out of bounds of the fishing encounters tables.
#ifdef BUGFIX
    if (MonListHasSpecies(info->fishingMonsInfo, species, FISH_WILD_COUNT))
#else
    if (MonListHasSpecies(info->fishingMonsInfo, species, LAND_WILD_COUNT))
#endif
        return TRUE;
    if (MonListHasSpecies(info->rockSmashMonsInfo, species, ROCK_WILD_COUNT))
        return TRUE;
    return FALSE;
}

static bool8 MonListHasSpecies(const struct WildPokemonInfo *info, enum Species species, u16 size)
{
    u16 i;
    if (info != NULL)
    {
        for (i = 0; i < size; i++)
        {
            if (info->wildPokemon[i].species == species)
                return TRUE;
        }
    }
    return FALSE;
}

static void BuildAreaGlowTilemap(void)
{
    u16 i, y, x, j;

    // Reset tilemap
    for (i = 0; i < ARRAY_COUNT(sPokedexAreaScreen->areaGlowTilemap); i++)
        sPokedexAreaScreen->areaGlowTilemap[i] = 0;

    // For each area with this species, scan the region map layout and find any locations that have a matching mapsec.
    // Add a "full glow" indicator for these matching spaces.
    for (i = 0; i < sPokedexAreaScreen->numOverworldAreas; i++)
    {
        j = 0;
        for (y = 0; y < AREA_SCREEN_HEIGHT; y++)
        {
            for (x = 0; x < AREA_SCREEN_WIDTH; x++)
            {
                if (GetRegionMapSecIdAt(x, y) == sPokedexAreaScreen->overworldAreasWithMons[i].regionMapSectionId)
                    sPokedexAreaScreen->areaGlowTilemap[j] = GLOW_FULL;
                j++;
            }
        }
    }

    // Scan the tilemap. For every "full glow" indicator added above, fill in its edges and corners.
    j = 0;
    for (y = 0; y < AREA_SCREEN_HEIGHT; y++)
    {
        for (x = 0; x < AREA_SCREEN_WIDTH; x++)
        {
            if (sPokedexAreaScreen->areaGlowTilemap[j] == GLOW_FULL)
            {
                // The "tile != GLOW_FULL" check is pointless in all of these conditionals,
                // since there's no harm in OR'ing 0xFFFF with anything else.

                // Edges
                if (x != 0 && sPokedexAreaScreen->areaGlowTilemap[j - 1] != GLOW_FULL)
                    sPokedexAreaScreen->areaGlowTilemap[j - 1] |= GLOW_EDGE_L;
                if (x != AREA_SCREEN_WIDTH - 1 && sPokedexAreaScreen->areaGlowTilemap[j + 1] != GLOW_FULL)
                    sPokedexAreaScreen->areaGlowTilemap[j + 1] |= GLOW_EDGE_R;
                if (y != 0 && sPokedexAreaScreen->areaGlowTilemap[j - AREA_SCREEN_WIDTH] != GLOW_FULL)
                    sPokedexAreaScreen->areaGlowTilemap[j - AREA_SCREEN_WIDTH] |= GLOW_EDGE_T;
                if (y != AREA_SCREEN_HEIGHT - 1 && sPokedexAreaScreen->areaGlowTilemap[j + AREA_SCREEN_WIDTH] != GLOW_FULL)
                    sPokedexAreaScreen->areaGlowTilemap[j + AREA_SCREEN_WIDTH] |= GLOW_EDGE_B;

                // Corners
                if (x != 0 && y != 0 && sPokedexAreaScreen->areaGlowTilemap[j - AREA_SCREEN_WIDTH - 1] != GLOW_FULL)
                    sPokedexAreaScreen->areaGlowTilemap[j - AREA_SCREEN_WIDTH - 1] |= GLOW_CORNER_TL;
                if (x != AREA_SCREEN_WIDTH - 1 && y != 0 && sPokedexAreaScreen->areaGlowTilemap[j - AREA_SCREEN_WIDTH + 1] != GLOW_FULL)
                    sPokedexAreaScreen->areaGlowTilemap[j - AREA_SCREEN_WIDTH + 1] |= GLOW_CORNER_TR;
                if (x != 0 && y != AREA_SCREEN_HEIGHT - 1 && sPokedexAreaScreen->areaGlowTilemap[j + AREA_SCREEN_WIDTH - 1] != GLOW_FULL)
                    sPokedexAreaScreen->areaGlowTilemap[j + AREA_SCREEN_WIDTH - 1] |= GLOW_CORNER_BL;
                if (x != AREA_SCREEN_WIDTH - 1 && y != AREA_SCREEN_HEIGHT - 1 && sPokedexAreaScreen->areaGlowTilemap[j + AREA_SCREEN_WIDTH + 1] != GLOW_FULL)
                    sPokedexAreaScreen->areaGlowTilemap[j + AREA_SCREEN_WIDTH + 1] |= GLOW_CORNER_BR;
            }

            j++;
        }
    }

    // Scan the tilemap again. Replace the "full tile" indicators with the actual tile id,
    // and remove corner flags when they're overlapped by an edge.
    for (i = 0; i < ARRAY_COUNT(sPokedexAreaScreen->areaGlowTilemap); i++)
    {
        if (sPokedexAreaScreen->areaGlowTilemap[i] == GLOW_FULL)
        {
            sPokedexAreaScreen->areaGlowTilemap[i] = GLOW_TILE_FULL;
            sPokedexAreaScreen->areaGlowTilemap[i] |= (GLOW_PALETTE << 12);
        }
        else if (sPokedexAreaScreen->areaGlowTilemap[i])
        {
            // Get rid of overlapping flags.
            // This is pointless, as sAreaGlowTilemapMapping can handle overlaps.
            if (sPokedexAreaScreen->areaGlowTilemap[i] & GLOW_EDGE_L)
                sPokedexAreaScreen->areaGlowTilemap[i] &= ~(GLOW_CORNER_TL | GLOW_CORNER_BL);
            if (sPokedexAreaScreen->areaGlowTilemap[i] & GLOW_EDGE_R)
                sPokedexAreaScreen->areaGlowTilemap[i] &= ~(GLOW_CORNER_TR | GLOW_CORNER_BR);
            if (sPokedexAreaScreen->areaGlowTilemap[i] & GLOW_EDGE_T)
                sPokedexAreaScreen->areaGlowTilemap[i] &= ~(GLOW_CORNER_TR | GLOW_CORNER_TL);
            if (sPokedexAreaScreen->areaGlowTilemap[i] & GLOW_EDGE_B)
                sPokedexAreaScreen->areaGlowTilemap[i] &= ~(GLOW_CORNER_BR | GLOW_CORNER_BL);

            // Assign tile id
            sPokedexAreaScreen->areaGlowTilemap[i] = sAreaGlowTilemapMapping[sPokedexAreaScreen->areaGlowTilemap[i]];
            sPokedexAreaScreen->areaGlowTilemap[i] |= (GLOW_PALETTE << 12);
        }
    }
}

static void StartAreaGlow(void)
{
    if (sPokedexAreaScreen->numSpecialAreas && sPokedexAreaScreen->numOverworldAreas == 0)
        sPokedexAreaScreen->showingMarkers = TRUE;
    else
        sPokedexAreaScreen->showingMarkers = FALSE;

    sPokedexAreaScreen->markerTimer = 0;
    sPokedexAreaScreen->glowTimer = 0;
    sPokedexAreaScreen->areaShadeBldArgLo = 0;
    sPokedexAreaScreen->areaShadeBldArgHi = 64;
    sPokedexAreaScreen->markerFlashCounter = 1;
    SetGpuReg(REG_OFFSET_BLDCNT, BLDCNT_TGT1_BG2 | BLDCNT_EFFECT_BLEND | BLDCNT_TGT2_ALL);
    SetGpuReg(REG_OFFSET_BLDALPHA, BLDALPHA_BLEND(0, 16));
    DoAreaGlow();
}

static void DoAreaGlow(void)
{
    u16 x, y;
    u16 i;

    if (!sPokedexAreaScreen->showingMarkers)
    {
        // Showing area glow
        if (sPokedexAreaScreen->markerTimer == 0)
        {
            sPokedexAreaScreen->glowTimer++;
            if (sPokedexAreaScreen->glowTimer & 1)
                sPokedexAreaScreen->areaShadeBldArgLo = (sPokedexAreaScreen->areaShadeBldArgLo + 4) & 0x7f;
            else
                sPokedexAreaScreen->areaShadeBldArgHi = (sPokedexAreaScreen->areaShadeBldArgHi + 4) & 0x7f;

            x = gSineTable[sPokedexAreaScreen->areaShadeBldArgLo] >> 4;
            y = gSineTable[sPokedexAreaScreen->areaShadeBldArgHi] >> 4;
            SetGpuReg(REG_OFFSET_BLDALPHA, BLDALPHA_BLEND(x, y));
            sPokedexAreaScreen->markerTimer = 0;
            if (sPokedexAreaScreen->glowTimer == 64)
            {
                // Done glowing, reset and try to switch to the special area markers
                sPokedexAreaScreen->glowTimer = 0;
                if (sPokedexAreaScreen->numSpecialAreas != 0)
                    sPokedexAreaScreen->showingMarkers = TRUE;
            }
        }
        else
            sPokedexAreaScreen->markerTimer--;
    }
    else
    {
        // Showing special area markers
        sPokedexAreaScreen->markerTimer++;
        if (sPokedexAreaScreen->markerTimer > 12)
        {
            sPokedexAreaScreen->markerTimer = 0;

            // Flash the marker
            // With a max of 4, the marker will disappear twice
            sPokedexAreaScreen->markerFlashCounter++;
            for (i = 0; i < sPokedexAreaScreen->numSpecialAreas; i++)
                sPokedexAreaScreen->areaMarkerSprites[i]->invisible = sPokedexAreaScreen->markerFlashCounter & 1;

            if (sPokedexAreaScreen->markerFlashCounter > 4)
            {
                // Done flashing, reset and try to switch to the area glow
                sPokedexAreaScreen->markerFlashCounter = 1;
                if (sPokedexAreaScreen->numOverworldAreas != 0)
                    sPokedexAreaScreen->showingMarkers = FALSE;
            }
        }
    }
}

static const u8 *GetTimeOfDayTextWithButton(enum TimeOfDay timeOfDay)
{
    static const u8 gText_Morning[] = _("{DPAD_UPDOWN} MORNING");
    static const u8 gText_Day[] = _("{DPAD_UPDOWN} DAY");
    static const u8 gText_Evening[] = _("{DPAD_UPDOWN} EVENING");
    static const u8 gText_Night[] = _("{DPAD_UPDOWN} NIGHT");

    switch (gAreaTimeOfDay)
    {
    case TIME_MORNING:
        return gText_Morning;
    case TIME_EVENING:
        return gText_Evening;
    case TIME_NIGHT:
        return gText_Night;
    case TIME_DAY:
    default:
        return gText_Day;
    }
}

static void AddTimeOfDayLabels(void)
{
    u32 i;

    // clear the background before adding any more windows
    RemoveAllWindowsOnBg(LABEL_WINDOW_BG);

    for (i = 0; i < NUM_LABEL_WINDOWS; i ++)
    {
        sPokedexAreaScreen->areaScreenLabelIds[i] = AddWindow(&sTimeOfDayWindowLabelTemplates[i]);
        FillWindowPixelBuffer(sPokedexAreaScreen->areaScreenLabelIds[i], PIXEL_FILL(0));
    }
}

static void ShowEncounterInfoLabel(void)
{
    const u8 *gText_TimeOfDay = GetTimeOfDayTextWithButton(gAreaTimeOfDay);
    int stringXPos = GetStringCenterAlignXOffset(FONT_NORMAL, gText_TimeOfDay, 64);

    PrintAreaLabelText(gText_TimeOfDay, DEX_AREA_LABEL_TIME_OF_DAY, stringXPos);
}

static void ShowAreaUnknownLabel(void)
{
    static const u8 gText_AreaUnknown[] = _("AREA UNKNOWN");
    int stringXPos = GetStringCenterAlignXOffset(FONT_NORMAL, gText_AreaUnknown, 80);

    PrintAreaLabelText(gText_AreaUnknown, DEX_AREA_LABEL_AREA_UNKNOWN, stringXPos);
}

static void ClearAreaWindowLabel(enum PokedexAreaLabels labelId)
{
    FillWindowPixelBuffer(sPokedexAreaScreen->areaScreenLabelIds[labelId], PIXEL_FILL(0));
    ClearWindowTilemap(sPokedexAreaScreen->areaScreenLabelIds[labelId]);
    ScheduleBgCopyTilemapToVram(0);
}

static void PrintAreaLabelText(const u8 *text, enum PokedexAreaLabels labelId, int textXPos)
{
    ClearAreaWindowLabel(labelId);

    PutWindowTilemap(sPokedexAreaScreen->areaScreenLabelIds[labelId]);
    FillWindowPixelBuffer(sPokedexAreaScreen->areaScreenLabelIds[labelId], PIXEL_FILL(7));

    AddTextPrinterParameterized4(sPokedexAreaScreen->areaScreenLabelIds[labelId], FONT_NORMAL, textXPos, 0, 0, 0, sFontColor_AreaInfo, TEXT_SKIP_DRAW, text);
    CopyWindowToVram(sPokedexAreaScreen->areaScreenLabelIds[labelId], COPYWIN_FULL);
}

bool32 ShouldShowAreaUnknownLabel(void)
{
    return !sPokedexAreaScreen->numOverworldAreas && !sPokedexAreaScreen->numSpecialAreas;
}

#define tState data[0]

void DisplayPokedexAreaScreen(enum Species species, u8 *screenSwitchState, enum TimeOfDay timeOfDay, enum PokedexAreaScreenState areaState)
{
    JourneyWorldDexOpen(species, screenSwitchState);
    return;
    u8 taskId;

    sPokedexAreaScreen = AllocZeroed(sizeof(*sPokedexAreaScreen));
    sPokedexAreaScreen->species = species;
    sPokedexAreaScreen->screenSwitchState = screenSwitchState;
    sPokedexAreaScreen->areaState = areaState;
    gAreaTimeOfDay = timeOfDay;
    screenSwitchState[0] = 0;

    if (sPokedexAreaScreen->areaState == DEX_UPDATE_AREA_SCREEN)
        taskId = CreateTask(Task_UpdatePokedexAreaScreen, 0);
    else
        taskId = CreateTask(Task_ShowPokedexAreaScreen, 0);

    gTasks[taskId].tState = 0;
}

static void Task_ShowPokedexAreaScreen(u8 taskId)
{
    switch (gTasks[taskId].tState)
    {
    case 0:
        ResetSpriteData();
        FreeAllSpritePalettes();
        HideBg(3);
        HideBg(2);
        HideBg(0);
        break;
    case 1:
        SetBgAttribute(3, BG_ATTR_CHARBASEINDEX, 3);
        LoadPokedexAreaMapGfx();
        StringFill(sPokedexAreaScreen->charBuffer, CHAR_SPACE, 16);
        break;
    case 2:
        if (TryShowPokedexAreaMap() == TRUE)
            return;
        PokedexAreaMapChangeBgY(-8);
        break;
    case 3:
        ResetDrawAreaGlowState();
        break;
    case 4:
        if (DrawAreaGlow())
            return;
        break;
    case 5:
        ShowRegionMapForPokedexAreaScreen(&sPokedexAreaScreen->regionMap);
        CreateRegionMapPlayerIcon(1, 1);
        PokedexAreaScreen_UpdateRegionMapVariablesAndVideoRegs(0, -8);
        break;
    case 6:
        CreateAreaMarkerSprites();
        break;
    case 7:
        if (!OW_TIME_OF_DAY_ENCOUNTERS)
            LoadAreaUnknownGraphics();
        break;
    case 8:
        if (!OW_TIME_OF_DAY_ENCOUNTERS)
            CreateAreaUnknownSprites();
        break;
    case 9:
        BeginNormalPaletteFade(PALETTES_ALL & ~(0x14), 0, 16, 0, RGB_BLACK);
        break;
    case 10:
        SetGpuReg(REG_OFFSET_BLDCNT, BLDCNT_TGT1_BG0 | BLDCNT_EFFECT_BLEND | BLDCNT_TGT2_BG0 | BLDCNT_TGT2_ALL);
        StartAreaGlow();
        if (OW_TIME_OF_DAY_ENCOUNTERS)
        {
            AddTimeOfDayLabels();
            ShowEncounterInfoLabel();
            if (ShouldShowAreaUnknownLabel())
                ShowAreaUnknownLabel();
            DoScheduledBgTilemapCopiesToVram();
        }
        if (POKEDEX_PLUS_HGSS)
            LoadHGSSScreenSelectBarSubmenu();
        ShowBg(2);
        ShowBg(3); // TryShowPokedexAreaMap will have done this already
        SetGpuRegBits(REG_OFFSET_DISPCNT, DISPCNT_OBJ_ON);
        break;
    case 11:
        gTasks[taskId].func = Task_HandlePokedexAreaScreenInput;
        gTasks[taskId].tState = 0;
        return;
    }

    gTasks[taskId].tState++;
}

static void Task_UpdatePokedexAreaScreen(u8 taskId)
{
    switch (gTasks[taskId].tState)
    {
    case 0:
        ClearAreaWindowLabel(DEX_AREA_LABEL_TIME_OF_DAY);
        ClearAreaWindowLabel(DEX_AREA_LABEL_AREA_UNKNOWN);
        ResetSpriteData();
        FreeAllSpritePalettes();
        ResetDrawAreaGlowState();
        HideBg(2);
        HideBg(0);
        break;
    case 1:
        SetBgAttribute(3, BG_ATTR_CHARBASEINDEX, 3);
        LoadPokedexAreaMapGfx();
        PokedexAreaMapChangeBgY(-8);
        StringFill(sPokedexAreaScreen->charBuffer, CHAR_SPACE, 16);
        break;
    case 2:
        if (TryShowPokedexAreaMap() == TRUE)
            return;
        break;
    case 3:
        if (DrawAreaGlow())
            return;
        break;
    case 4:
        ShowRegionMapForPokedexAreaScreen(&sPokedexAreaScreen->regionMap);
        CreateRegionMapPlayerIcon(1, 1);
        PokedexAreaScreen_UpdateRegionMapVariablesAndVideoRegs(0, -8);
        CreateAreaMarkerSprites();
        break;
    case 5:
        SetGpuReg(REG_OFFSET_BLDCNT, BLDCNT_TGT1_BG0 | BLDCNT_EFFECT_BLEND | BLDCNT_TGT2_BG0 | BLDCNT_TGT2_ALL);
        StartAreaGlow();
        AddTimeOfDayLabels();
        ShowEncounterInfoLabel();
        if (ShouldShowAreaUnknownLabel())
            ShowAreaUnknownLabel();
        ShowBg(2);
        SetGpuRegBits(REG_OFFSET_DISPCNT, DISPCNT_OBJ_ON);
        break;
    case 6:
        gTasks[taskId].func = Task_HandlePokedexAreaScreenInput;
        gTasks[taskId].tState = 0;
        return;
    }

    gTasks[taskId].tState++;
}

static void Task_HandlePokedexAreaScreenInput(u8 taskId)
{
    DoAreaGlow();
    switch (gTasks[taskId].tState)
    {
    default:
        gTasks[taskId].tState = 0;
        // fall through
    case 0:
        if (gPaletteFade.active)
            return;
        break;
    case 1:
        if (JOY_NEW(B_BUTTON))
        {
            gTasks[taskId].data[1] = 1;
            PlaySE(SE_DEX_PAGE);
        }
        else if (JOY_NEW(DPAD_LEFT) || (JOY_NEW(L_BUTTON) && gSaveBlock2Ptr->optionsButtonMode == OPTIONS_BUTTON_MODE_LR))
        {
            gTasks[taskId].data[1] = 1;
            PlaySE(SE_DEX_PAGE);
        }
        else if (JOY_NEW(DPAD_RIGHT) || (JOY_NEW(R_BUTTON) && gSaveBlock2Ptr->optionsButtonMode == OPTIONS_BUTTON_MODE_LR))
        {
            if (!GetSetPokedexFlag(SpeciesToNationalPokedexNum(sPokedexAreaScreen->species), FLAG_GET_CAUGHT))
            {
                PlaySE(SE_FAILURE);
                return;
            }
            gTasks[taskId].data[1] = 2;
            PlaySE(SE_DEX_PAGE);
        }
        else if (JOY_NEW(DPAD_UP) && OW_TIME_OF_DAY_ENCOUNTERS == TRUE)
        {
            gTasks[taskId].data[1] = 3;
            gAreaTimeOfDay = TryDecrementTimeOfDay(gAreaTimeOfDay);
            sPokedexAreaScreen->areaState = DEX_UPDATE_AREA_SCREEN;
            PlaySE(SE_DEX_PAGE);
        }
        else if (JOY_NEW(DPAD_DOWN) && OW_TIME_OF_DAY_ENCOUNTERS == TRUE)
        {
            gTasks[taskId].data[1] = 3;
            gAreaTimeOfDay = TryIncrementTimeOfDay(gAreaTimeOfDay);
            sPokedexAreaScreen->areaState = DEX_UPDATE_AREA_SCREEN;
            PlaySE(SE_DEX_PAGE);
        }
        else
        {
            // screen needs to fade if its doing anything except updating the area screen
            sPokedexAreaScreen->areaState = DEX_SHOW_AREA_SCREEN;
            return;
        }
        break;
    case 2:
        if (sPokedexAreaScreen->areaState != DEX_UPDATE_AREA_SCREEN)
            BeginNormalPaletteFade(PALETTES_ALL & ~(0x14), 0, 0, 16, RGB_BLACK);
        break;
    case 3:
        if (gPaletteFade.active)
            return;
        DestroyAreaScreenSprites();
        if (OW_TIME_OF_DAY_ENCOUNTERS)
        {
            ClearAreaWindowLabel(DEX_AREA_LABEL_TIME_OF_DAY);
            ClearAreaWindowLabel(DEX_AREA_LABEL_AREA_UNKNOWN);
            RemoveAllWindowsOnBg(LABEL_WINDOW_BG);
        }

        sPokedexAreaScreen->screenSwitchState[0] = gTasks[taskId].data[1];
        ResetPokedexAreaMapBg();
        DestroyTask(taskId);
        FREE_AND_SET_NULL(sPokedexAreaScreen);
        return;
    }

    gTasks[taskId].tState++;
}

static void ResetPokedexAreaMapBg(void)
{
    SetBgAttribute(3, BG_ATTR_CHARBASEINDEX, 0);
    SetBgAttribute(3, BG_ATTR_PALETTEMODE, 0);
}

// Creates the circular sprites to highlight special areas (like caves) where a Pokémon can be found
static void CreateAreaMarkerSprites(void)
{
    u8 spriteId;
    s16 x;
    s16 y;
    s16 i;
    mapsec_u16_t mapSecId;
    s16 numSprites;

    LoadSpriteSheet(&sAreaMarkerSpriteSheet);
    LoadSpritePalette(&sAreaMarkerSpritePalette);
    numSprites = 0;
    for (i = 0; i < sPokedexAreaScreen->numSpecialAreas; i++)
    {
        mapSecId = sPokedexAreaScreen->specialAreaRegionMapSectionIds[i];
        x = 8 * (gRegionMapEntries[mapSecId].x + 1) + 4;
        y = 8 * (gRegionMapEntries[mapSecId].y) + 28;
        x += 4 * (gRegionMapEntries[mapSecId].width - 1);
        y += 4 * (gRegionMapEntries[mapSecId].height - 1);
        spriteId = CreateSprite(&sAreaMarkerSpriteTemplate, x, y, 0);
        if (spriteId != MAX_SPRITES)
        {
            gSprites[spriteId].invisible = TRUE;
            sPokedexAreaScreen->areaMarkerSprites[numSprites++] = &gSprites[spriteId];
        }
    }

    sPokedexAreaScreen->numAreaMarkerSprites = numSprites;
}

static void DestroyAreaScreenSprites(void)
{
    u16 i;

    // Destroy area marker sprites
    FreeSpriteTilesByTag(TAG_AREA_MARKER);
    FreeSpritePaletteByTag(TAG_AREA_MARKER);
    for (i = 0; i < sPokedexAreaScreen->numAreaMarkerSprites; i++)
        DestroySprite(sPokedexAreaScreen->areaMarkerSprites[i]);

    if (!OW_TIME_OF_DAY_ENCOUNTERS)
    {
        // Destroy "Area Unknown" sprites
        FreeSpriteTilesByTag(TAG_AREA_UNKNOWN);
        FreeSpritePaletteByTag(TAG_AREA_UNKNOWN);
        for (i = 0; i < ARRAY_COUNT(sPokedexAreaScreen->areaUnknownSprites); i++)
        {
            if (sPokedexAreaScreen->areaUnknownSprites[i])
                DestroySprite(sPokedexAreaScreen->areaUnknownSprites[i]);
        }
    }
}

static void LoadAreaUnknownGraphics(void)
{
    struct SpriteSheet spriteSheet = {
        .data = sPokedexAreaScreen->areaUnknownGraphicsBuffer,
        .size = sizeof(sPokedexAreaScreen->areaUnknownGraphicsBuffer),
        .tag = TAG_AREA_UNKNOWN,
    };
    DecompressDataWithHeaderWram(gPokedexAreaScreenAreaUnknown_Gfx, sPokedexAreaScreen->areaUnknownGraphicsBuffer);
    LoadSpriteSheet(&spriteSheet);
    LoadSpritePalette(&sAreaUnknownSpritePalette);
}

static void CreateAreaUnknownSprites(void)
{
    u16 i;

    if (sPokedexAreaScreen->numOverworldAreas || sPokedexAreaScreen->numSpecialAreas)
    {
        // The current species is present on the map, don't create any "Area Unknown" sprites
        for (i = 0; i < ARRAY_COUNT(sPokedexAreaScreen->areaUnknownSprites); i++)
            sPokedexAreaScreen->areaUnknownSprites[i] = NULL;
    }
    else
    {
        // The current species is absent on the map, try to create "Area Unknown" sprites
        for (i = 0; i < ARRAY_COUNT(sPokedexAreaScreen->areaUnknownSprites); i++)
        {
            u8 spriteId = CreateSprite(&sAreaUnknownSpriteTemplate, i * 32 + 160, 140, 0);
            if (spriteId != MAX_SPRITES)
            {
                gSprites[spriteId].oam.tileNum += i * 16;
                sPokedexAreaScreen->areaUnknownSprites[i] = &gSprites[spriteId];
            }
            else
            {
                // Failed to create sprite
                sPokedexAreaScreen->areaUnknownSprites[i] = NULL;
            }
        }
    }
}

static void LoadHGSSScreenSelectBarSubmenu(void)
{
    CopyToBgTilemapBuffer(1, sPokedexPlusHGSS_ScreenSelectBarSubmenu_Tilemap, 0, 0);
    CopyBgTilemapBufferToVram(1);
}
