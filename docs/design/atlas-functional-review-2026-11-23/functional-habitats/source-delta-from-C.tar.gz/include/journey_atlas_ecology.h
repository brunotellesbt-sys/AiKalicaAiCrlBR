#ifndef GUARD_JOURNEY_ATLAS_ECOLOGY_H
#define GUARD_JOURNEY_ATLAS_ECOLOGY_H
u16 JourneyAtlasEcologyOwner(u16 map);
bool32 JourneyAtlasLandEncounter(u16 map, u16 behavior, u8 elevation);
#endif
