Journey_GymGuide::
	lock
	faceplayer
	special JourneyExplainGymGate
Journey_GymGuide_Dispatch::
	goto_if_eq VAR_RESULT, 1, Journey_GymGuide_Event1
	goto_if_eq VAR_RESULT, 2, Journey_GymGuide_Event2
	goto_if_eq VAR_RESULT, 3, Journey_GymGuide_Event3
	goto_if_eq VAR_RESULT, 4, Journey_GymGuide_Event4
	goto_if_eq VAR_RESULT, 5, Journey_GymGuide_Event5
	goto_if_eq VAR_RESULT, 6, Journey_GymGuide_Event6
	goto_if_eq VAR_RESULT, 7, Journey_GymGuide_Event7
	goto_if_eq VAR_RESULT, 8, Journey_GymGuide_Event8
	goto_if_eq VAR_RESULT, 9, Journey_GymGuide_Event9
	goto_if_eq VAR_RESULT, 10, Journey_GymGuide_Event10
	goto_if_eq VAR_RESULT, 11, Journey_GymGuide_Event11
	goto_if_eq VAR_RESULT, 12, Journey_GymGuide_Event12
	goto_if_eq VAR_RESULT, 13, Journey_GymGuide_Event13
	goto_if_eq VAR_RESULT, 14, Journey_GymGuide_Event14
	goto_if_eq VAR_RESULT, 15, Journey_GymGuide_Event15
	goto_if_eq VAR_RESULT, 16, Journey_GymGuide_Event16
	goto_if_eq VAR_RESULT, 17, Journey_GymGuide_Event17
	goto_if_eq VAR_RESULT, 18, Journey_GymGuide_Event18
	goto_if_eq VAR_RESULT, 19, Journey_GymGuide_Event19
	goto_if_eq VAR_RESULT, 20, Journey_GymGuide_Event20
	goto_if_eq VAR_RESULT, 21, Journey_GymGuide_Event21
	goto_if_eq VAR_RESULT, 23, Journey_GymGuide_Event23
	goto_if_eq VAR_RESULT, 22, Journey_GymGuide_Event22
	release
	end

Journey_GymGuide_Event1::
	msgbox Journey_GymGuide_Text1, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text1::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM ROCKET!\p"
	.string "Take ROUTE 7 to CELADON.\n"
	.string "Go below the GAME CORNER\l"
	.string "and help in the hideout!$"

Journey_GymGuide_Event2::
	msgbox Journey_GymGuide_Text2, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text2::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM ROCKET!\p"
	.string "Take ROUTE 7 or 8.\n"
	.string "In SAFFRON, go help at\l"
	.string "SILPH CO., on floor 11!$"

Journey_GymGuide_Event3::
	msgbox Journey_GymGuide_Text3, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text3::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM MAGMA!\p"
	.string "Take the cable car on\n"
	.string "ROUTE 112 to MT. CHIMNEY.\l"
	.string "Please help at the summit!\p"
	.string "First visit METEOR FALLS,\n"
	.string "on ROUTE 114 or 115.\p"
	.string "MAGMA is after COZMO's\n"
	.string "meteorite there!$"

Journey_GymGuide_Event4::
	msgbox Journey_GymGuide_Text4, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text4::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM MAGMA!\p"
	.string "Take ROUTE 112 and head\n"
	.string "to JAGGED PASS.\l"
	.string "Help inside MAGMA HIDEOUT!\p"
	.string "If the entrance is closed,\n"
	.string "visit MT. PYRE on ROUTE 122.\p"
	.string "The elders there can give you\n"
	.string "the MAGMA EMBLEM to open it!$"

Journey_GymGuide_Event5::
	msgbox Journey_GymGuide_Text5, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text5::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM MAGMA!\p"
	.string "Cross ROUTE 124 to MOSSDEEP.\n"
	.string "Help at the SPACE CENTER,\l"
	.string "on the second floor!$"

Journey_GymGuide_Event6::
	msgbox Journey_GymGuide_Text6, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text6::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM AQUA!\p"
	.string "Use DIVE on ROUTE 128.\n"
	.string "Help deep inside the\l"
	.string "SEAFLOOR CAVERN!$"

Journey_GymGuide_Event7::
	msgbox Journey_GymGuide_Text7, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text7::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM MAGMA!\p"
	.string "Take ROUTE 2 or 3 to PEWTER.\n"
	.string "Defeat their three invaders!$"

Journey_GymGuide_Event8::
	msgbox Journey_GymGuide_Text8, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text8::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM AQUA!\p"
	.string "Take ROUTE 6 to VERMILION.\n"
	.string "Defeat their three invaders!$"

Journey_GymGuide_Event9::
	msgbox Journey_GymGuide_Text9, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text9::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM MAGMA!\p"
	.string "Take ROUTE 10 to ROCK\n"
	.string "TUNNEL.\p"
	.string "Clear both floors of MAGMA!$"

Journey_GymGuide_Event10::
	msgbox Journey_GymGuide_Text10, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text10::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM AQUA!\p"
	.string "Surf south from CINNABAR.\n"
	.string "Clear the western river and\p"
	.string "RUSTBORO-DEWFORD sea route!$"

Journey_GymGuide_Event11::
	msgbox Journey_GymGuide_Text11, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text11::
	.string "The GYM LEADER is busy\n"
	.string "helping fight MAGMA and\p"
	.string "AQUA!\n"
	.string "Clear the invaders on\p"
	.string "KANTO ROUTES 3, 6, 8 and 15!$"

Journey_GymGuide_Event12::
	msgbox Journey_GymGuide_Text12, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text12::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM ROCKET!\p"
	.string "Go to MAUVILLE GAME CORNER.\n"
	.string "Use the rear floor passage.\p"
	.string "Clear both basement floors!$"

Journey_GymGuide_Event13::
	msgbox Journey_GymGuide_Text13, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text13::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM AQUA!\p"
	.string "We need GIOVANNI to help.\n"
	.string "Finish SILPH CO. in SAFFRON\p"
	.string "after six KANTO badges!$"

@ Shared key-item reward. Badge banks and Snorlax story flags stay independent.
Journey_FirstBadgeReward::
	call JourneyBadgeStory_Notify
	goto_if_set FLAG_GOT_POKE_FLUTE, Journey_FirstBadgeReward_Return
	special JourneyFirstBadgeRewardPermission
	goto_if_eq VAR_RESULT, FALSE, Journey_FirstBadgeReward_Return
	checkitem ITEM_POKE_FLUTE
	goto_if_eq VAR_RESULT, TRUE, Journey_FirstBadgeReward_Claimed
	checkitemspace ITEM_POKE_FLUTE
	goto_if_eq VAR_RESULT, FALSE, Journey_FirstBadgeReward_BagFull
	msgbox Journey_FirstBadgeReward_Text, MSGBOX_DEFAULT
	giveitem ITEM_POKE_FLUTE
	goto_if_eq VAR_RESULT, FALSE, Journey_FirstBadgeReward_BagFull
Journey_FirstBadgeReward_Claimed::
	setflag FLAG_GOT_POKE_FLUTE
Journey_FirstBadgeReward_Return::
	return

Journey_FirstBadgeReward_BagFull::
	msgbox Journey_FirstBadgeReward_BagFullText, MSGBOX_DEFAULT
	return

Journey_FirstBadgeReward_Text::
	.string "Your first badge! Take this\n"
	.string "POKé FLUTE to celebrate.\p"
	.string "Its melody wakes sleeping\n"
	.string "POKéMON, including SNORLAX!$"

Journey_FirstBadgeReward_BagFullText::
	.string "Make room for the POKé FLUTE.\n"
	.string "Then talk to a GYM LEADER!$"

Journey_FujiFirstBadgeText::
	.string "Win your first GYM badge.\n"
	.string "A LEADER will give you a flute!$"

Journey_WaterHMFamilyGift::
	goto_if_gt VAR_JOURNEY_FAMILY_HOME, 1, Journey_WaterHMFamilyGift_Return
	goto_if_set FLAG_JOURNEY_WATER_HMS_GIVEN, Journey_WaterHMFamilyGift_Return
	msgbox Journey_WaterHMFamilyGift_Text, MSGBOX_DEFAULT
Journey_WaterHMFamilyGift_SURF::
	checkitem ITEM_HM_SURF
	goto_if_eq VAR_RESULT, TRUE, Journey_WaterHMFamilyGift_DIVE
	checkitemspace ITEM_HM_SURF
	goto_if_eq VAR_RESULT, FALSE, Journey_WaterHMFamilyGift_BagFull
	giveitem ITEM_HM_SURF
	goto_if_eq VAR_RESULT, FALSE, Journey_WaterHMFamilyGift_BagFull
Journey_WaterHMFamilyGift_DIVE::
	checkitem ITEM_HM_DIVE
	goto_if_eq VAR_RESULT, TRUE, Journey_WaterHMFamilyGift_WATERFALL
	checkitemspace ITEM_HM_DIVE
	goto_if_eq VAR_RESULT, FALSE, Journey_WaterHMFamilyGift_BagFull
	giveitem ITEM_HM_DIVE
	goto_if_eq VAR_RESULT, FALSE, Journey_WaterHMFamilyGift_BagFull
Journey_WaterHMFamilyGift_WATERFALL::
	checkitem ITEM_HM_WATERFALL
	goto_if_eq VAR_RESULT, TRUE, Journey_WaterHMFamilyGift_Complete
	checkitemspace ITEM_HM_WATERFALL
	goto_if_eq VAR_RESULT, FALSE, Journey_WaterHMFamilyGift_BagFull
	giveitem ITEM_HM_WATERFALL
	goto_if_eq VAR_RESULT, FALSE, Journey_WaterHMFamilyGift_BagFull
Journey_WaterHMFamilyGift_Complete::
	setflag FLAG_JOURNEY_WATER_HMS_GIVEN
Journey_WaterHMFamilyGift_Return::
	return
Journey_WaterHMFamilyGift_BagFull::
	msgbox Journey_WaterHMFamilyGift_BagFullText, MSGBOX_DEFAULT
	return
Journey_WaterHMFamilyGift_Text::
	.string "Take SURF, DIVE and\n"
	.string "WATERFALL for your trip!\p"
	.string "Teach them to your POKéMON.\n"
	.string "Travel safely on the water!$"
Journey_WaterHMFamilyGift_BagFullText::
	.string "Make room in your TM pocket.\n"
	.string "Then talk to me again!$"

Journey_FerryPort0::
	setvar VAR_0x8008, 0
	goto Journey_Ferry

Journey_FerryPort1::
	setvar VAR_0x8008, 1
	goto Journey_Ferry

Journey_FerryPort2::
	setvar VAR_0x8008, 2
	goto Journey_Ferry

Journey_FerryPort3::
	setvar VAR_0x8008, 3
	goto Journey_Ferry

Journey_FerryPort4::
	setvar VAR_0x8008, 4
	goto Journey_Ferry

Journey_FerryPort5::
	setvar VAR_0x8008, 5
	goto Journey_Ferry

Journey_FerryPort6::
	setvar VAR_0x8008, 6
	goto Journey_Ferry

Journey_FerryPort7::
	setvar VAR_0x8008, 7
	goto Journey_Ferry

Journey_FerryPort8::
	setvar VAR_0x8008, 8
	goto Journey_Ferry

Journey_Ferry::
	lock
	faceplayer
	checkitem ITEM_JOURNEY_FERRY_TICKET
	goto_if_eq VAR_RESULT, TRUE, Journey_Ferry_Menu
	msgbox Journey_Ferry_TicketText, MSGBOX_DEFAULT
	checkitemspace ITEM_JOURNEY_FERRY_TICKET
	goto_if_eq VAR_RESULT, FALSE, Journey_Ferry_Full
	giveitem ITEM_JOURNEY_FERRY_TICKET
	goto_if_eq VAR_RESULT, FALSE, Journey_Ferry_Full
Journey_Ferry_Menu::
	goto LavenderNetwork_Menu
Journey_Ferry_Islands::
	multichoice 0, 0, MULTI_JOURNEY_FERRY_ISLANDS, FALSE
	switch VAR_RESULT
	case 0, Journey_Ferry_Destination2
	case 1, Journey_Ferry_Destination3
	case 2, Journey_Ferry_Destination4
	case 3, Journey_Ferry_Destination5
	case 4, Journey_Ferry_Destination6
	case 5, Journey_Ferry_Destination7
	case 6, Journey_Ferry_Destination8
	goto Journey_Ferry_Menu
Journey_Ferry_Destination0::
	goto_if_eq VAR_0x8008, 0, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	warp MAP_JOURNEYROUTE12SHIPYARD, 24, 39
	waitstate
	release
	end
Journey_Ferry_Destination1::
	goto_if_eq VAR_0x8008, 1, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	warp MAP_SLATEPORT_CITY_HARBOR, 16, 14
	waitstate
	release
	end
Journey_Ferry_Destination2::
	goto_if_eq VAR_0x8008, 2, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	warp MAP_ONE_ISLAND_TREASURE_BEACH, 20, 6
	waitstate
	release
	end
Journey_Ferry_Destination3::
	goto_if_eq VAR_0x8008, 3, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	warp MAP_TWO_ISLAND, 10, 14
	waitstate
	release
	end
Journey_Ferry_Destination4::
	goto_if_eq VAR_0x8008, 4, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	warp MAP_THREE_ISLAND_PORT, 13, 17
	waitstate
	release
	end
Journey_Ferry_Destination5::
	goto_if_eq VAR_0x8008, 5, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	warp MAP_FOUR_ISLAND, 10, 34
	waitstate
	release
	end
Journey_Ferry_Destination6::
	goto_if_eq VAR_0x8008, 6, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	warp MAP_FIVE_ISLAND, 11, 15
	waitstate
	release
	end
Journey_Ferry_Destination7::
	goto_if_eq VAR_0x8008, 7, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	warp MAP_SIX_ISLAND, 3, 29
	waitstate
	release
	end
Journey_Ferry_Destination8::
	goto_if_eq VAR_0x8008, 8, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	warp MAP_SEVEN_ISLAND_SEVAULT_CANYON_ENTRANCE, 14, 1
	waitstate
	release
	end
Journey_Ferry_Full::
	msgbox Journey_Ferry_FullText, MSGBOX_DEFAULT
	goto Journey_Ferry_Cancel
Journey_Ferry_AlreadyHere::
	msgbox Journey_Ferry_AlreadyHereText, MSGBOX_DEFAULT
Journey_Ferry_Cancel::
	release
	end
Journey_Ferry_TicketText::
	.string "Welcome to the WORLD FERRY!\p"
	.string "Take this free WORLD TICKET.\n"
	.string "Keep it for all your trips!$"
Journey_Ferry_WhereText::
	.string "We sail to KANTO, HOENN\n"
	.string "and all seven SEVII ISLANDS.\p"
	.string "Where would you like to go?$"
Journey_Ferry_BoardText::
	.string "Your ticket is valid.\n"
	.string "All aboard!$"
Journey_Ferry_FullText::
	.string "Make room for the WORLD TICKET\n"
	.string "in your KEY ITEMS pocket.$"
Journey_Ferry_AlreadyHereText::
	.string "You are already at this port.$"

Journey_GymGuide_Event14::
	msgbox Journey_GymGuide_Text14, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text14::
	.string "The GYM LEADER is helping\n"
	.string "with the climate crisis!\p"
	.string "TEAM AQUA and TEAM MAGMA\n"
	.string "awakened the ancient POKEMON.\p"
	.string "Meet WALLACE in the CAVE OF\n"
	.string "ORIGIN in SOOTOPOLIS.\p"
	.string "Wake RAYQUAZA at SKY PILLAR,\n"
	.string "north of ROUTE 131.\p"
	.string "Return to SOOTOPOLIS so it\n"
	.string "can stop the clash!$"

Journey_PuzzleInscription:
	.string "You read the ancient inscription.\p"
	.string "The stone door begins to open!$"

Journey_GymGuide_Event15::
	msgbox Journey_GymGuide_Text15, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text15:
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM AQUA!\p"
	.string "Take ROUTE 119 to the\n"
	.string "WEATHER INSTITUTE.\p"
	.string "Help the scientists and\n"
	.string "defeat SHELLY on floor 2!$"

Journey_GymGuide_Event16::
	msgbox Journey_GymGuide_Text16, MSGBOX_DEFAULT
	release
	end

Journey_GymGuide_Text16:
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM AQUA!\p"
	.string "Head to LILYCOVE and SURF\n"
	.string "to the AQUA HIDEOUT.\p"
	.string "Defeat MATT on floor B2!\n"
	.string "If its entrance is guarded,\p"
	.string "visit CAPT. STERN at the\n"
	.string "harbor in SLATEPORT first.$"

Journey_GymGuide_Event17::
	msgbox Journey_GymGuide_Text17, MSGBOX_DEFAULT
	releaseall
	end

Journey_GymGuide_Text17::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM ROCKET!\p"
	.string "Go to MT. MOON on ROUTE 4.\n"
	.string "Clear the basement ROCKETS.\p"
	.string "Help secure the fossils, too!$"

Journey_GymGuide_Event18::
	msgbox Journey_GymGuide_Text18, MSGBOX_DEFAULT
	releaseall
	end

Journey_GymGuide_Text18::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM ROCKET!\p"
	.string "Visit CERULEAN and ROUTE 24.\n"
	.string "Recover the stolen TM and\p"
	.string "stop the bridge recruiter!$"

Journey_GymGuide_Event19::
	msgbox Journey_GymGuide_Text19, MSGBOX_DEFAULT
	releaseall
	end

Journey_GymGuide_Text19::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM ROCKET!\p"
	.string "Go to LAVENDER via ROUTE 8.\n"
	.string "Calm the ghost in the TOWER.\p"
	.string "Clear floor 7 and save FUJI!$"

Journey_GymGuide_Event20::
	msgbox Journey_GymGuide_Text20, MSGBOX_DEFAULT
	releaseall
	end

Journey_GymGuide_Text20::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM AQUA!\p"
	.string "Go to PETALBURG WOODS,\n"
	.string "on ROUTE 104.\p"
	.string "Help the DEVON researcher!$"

Journey_GymGuide_Event21::
	msgbox Journey_GymGuide_Text21, MSGBOX_DEFAULT
	releaseall
	end

Journey_GymGuide_Text21::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM AQUA!\p"
	.string "Visit RUSTBORO, then take\n"
	.string "ROUTE 116 to RUSTURF TUNNEL.\p"
	.string "Rescue PEEKO and the package!$"

Journey_GymGuide_Event22::
	msgbox Journey_GymGuide_Text22, MSGBOX_DEFAULT
	releaseall
	end

Journey_GymGuide_Text22::
	.string "The GYM LEADER is busy\n"
	.string "helping fight TEAM AQUA!\p"
	.string "Go to SLATEPORT SHIPYARD,\n"
	.string "then the OCEANIC MUSEUM.\p"
	.string "Deliver the DEVON PARTS\n"
	.string "and help STERN on floor 2!$"

Journey_GymGuide_Event23::
	msgbox Journey_GymGuide_Text23, MSGBOX_DEFAULT
	releaseall
	end

Journey_GymGuide_Text23::
	.string "The GYM LEADER is busy\n"
	.string "helping DEVON researchers.\p"
	.string "Visit DEVON CORP in RUSTBORO.\n"
	.string "Take the LETTER to STEVEN\p"
	.string "in GRANITE CAVE, ROUTE 106.$"


LavenderNetwork_Menu::
	msgbox LavenderNetwork_Where, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_REGIONS, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_KANTO
	case 1, LavenderNetwork_HOENN
	case 2, LavenderNetwork_SEVII
	goto Journey_Ferry_Cancel

LavenderNetwork_HOENN::
	switch VAR_0x8008
	case 0, LavenderNetwork_HoennRegions0
	case 1, LavenderNetwork_HoennRegions1
	case 2, LavenderNetwork_HoennRegions2
	case 3, LavenderNetwork_HoennRegions3
	case 4, LavenderNetwork_HoennRegions4
	case 5, LavenderNetwork_HoennRegions5
	case 6, LavenderNetwork_HoennRegions6
	case 7, LavenderNetwork_HoennRegions7
	case 8, LavenderNetwork_HoennRegions8
	case 9, LavenderNetwork_HoennRegions9
	case 10, LavenderNetwork_HoennRegions10
	case 11, LavenderNetwork_HoennRegions11
	case 12, LavenderNetwork_HoennRegions12
	case 13, LavenderNetwork_HoennRegions13
	case 14, LavenderNetwork_HoennRegions14
	case 15, LavenderNetwork_HoennRegions15
	case 16, LavenderNetwork_HoennRegions16
	case 17, LavenderNetwork_HoennRegions17
	case 18, LavenderNetwork_HoennRegions0
	case 19, LavenderNetwork_HoennRegions0
	case 20, LavenderNetwork_HoennRegions0
	case 21, LavenderNetwork_HoennRegions0
	goto Journey_Ferry_Cancel

LavenderNetwork_HoennRegions0::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions1::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions2::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions3::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions4::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions5::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions6::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions7::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions8::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions9::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions10::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions11::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions12::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions13::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions14::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions15::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS15, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions16::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_HoennRegions17::
	multichoice 0, 0, MULTI_LAVENDER_HOENNREGIONS0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_HOENN_WEST
	case 1, LavenderNetwork_HOENN_EAST
	case 2, LavenderNetwork_Destination15
	goto LavenderNetwork_Menu

LavenderNetwork_KANTO::
	switch VAR_0x8008
	case 0, LavenderNetwork_KANTO_0
	case 1, LavenderNetwork_KANTO_1
	case 2, LavenderNetwork_KANTO_2
	case 3, LavenderNetwork_KANTO_3
	case 4, LavenderNetwork_KANTO_4
	case 5, LavenderNetwork_KANTO_5
	case 6, LavenderNetwork_KANTO_6
	case 7, LavenderNetwork_KANTO_7
	case 8, LavenderNetwork_KANTO_8
	case 9, LavenderNetwork_KANTO_9
	case 10, LavenderNetwork_KANTO_10
	case 11, LavenderNetwork_KANTO_11
	case 12, LavenderNetwork_KANTO_12
	case 13, LavenderNetwork_KANTO_13
	case 14, LavenderNetwork_KANTO_14
	case 15, LavenderNetwork_KANTO_15
	case 16, LavenderNetwork_KANTO_16
	case 17, LavenderNetwork_KANTO_17
	case 18, LavenderNetwork_KANTO_18
	case 19, LavenderNetwork_KANTO_19
	case 20, LavenderNetwork_KANTO_20
	case 21, LavenderNetwork_KANTO_21
	goto Journey_Ferry_Cancel

LavenderNetwork_KANTO_0::
	multichoice 0, 0, MULTI_COMPACT_KANTO_0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination14
	case 1, LavenderNetwork_Destination18
	case 2, LavenderNetwork_Destination19
	case 3, LavenderNetwork_Destination20
	case 4, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_1::
	multichoice 0, 0, MULTI_COMPACT_KANTO_1, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_2::
	multichoice 0, 0, MULTI_COMPACT_KANTO_2, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_3::
	multichoice 0, 0, MULTI_COMPACT_KANTO_3, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_4::
	multichoice 0, 0, MULTI_COMPACT_KANTO_4, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_5::
	multichoice 0, 0, MULTI_COMPACT_KANTO_5, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_6::
	multichoice 0, 0, MULTI_COMPACT_KANTO_6, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_7::
	multichoice 0, 0, MULTI_COMPACT_KANTO_7, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_8::
	multichoice 0, 0, MULTI_COMPACT_KANTO_8, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_9::
	multichoice 0, 0, MULTI_COMPACT_KANTO_9, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_10::
	multichoice 0, 0, MULTI_COMPACT_KANTO_10, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_11::
	multichoice 0, 0, MULTI_COMPACT_KANTO_11, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_12::
	multichoice 0, 0, MULTI_COMPACT_KANTO_12, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_13::
	multichoice 0, 0, MULTI_COMPACT_KANTO_13, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_14::
	multichoice 0, 0, MULTI_COMPACT_KANTO_14, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination18
	case 2, LavenderNetwork_Destination19
	case 3, LavenderNetwork_Destination20
	case 4, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_15::
	multichoice 0, 0, MULTI_COMPACT_KANTO_15, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_16::
	multichoice 0, 0, MULTI_COMPACT_KANTO_16, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_KANTO_17::
	multichoice 0, 0, MULTI_COMPACT_KANTO_17, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	case 5, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu


LavenderNetwork_HOENN_WEST::
	switch VAR_0x8008
	case 0, LavenderNetwork_HOENN_WEST_0
	case 1, LavenderNetwork_HOENN_WEST_1
	case 2, LavenderNetwork_HOENN_WEST_2
	case 3, LavenderNetwork_HOENN_WEST_3
	case 4, LavenderNetwork_HOENN_WEST_4
	case 5, LavenderNetwork_HOENN_WEST_5
	case 6, LavenderNetwork_HOENN_WEST_6
	case 7, LavenderNetwork_HOENN_WEST_7
	case 8, LavenderNetwork_HOENN_WEST_8
	case 9, LavenderNetwork_HOENN_WEST_9
	case 10, LavenderNetwork_HOENN_WEST_10
	case 11, LavenderNetwork_HOENN_WEST_11
	case 12, LavenderNetwork_HOENN_WEST_12
	case 13, LavenderNetwork_HOENN_WEST_13
	case 14, LavenderNetwork_HOENN_WEST_14
	case 15, LavenderNetwork_HOENN_WEST_15
	case 16, LavenderNetwork_HOENN_WEST_16
	case 17, LavenderNetwork_HOENN_WEST_17
	case 18, LavenderNetwork_HOENN_WEST_0
	case 19, LavenderNetwork_HOENN_WEST_0
	case 20, LavenderNetwork_HOENN_WEST_0
	case 21, LavenderNetwork_HOENN_WEST_0
	goto Journey_Ferry_Cancel

LavenderNetwork_HOENN_WEST_0::
	multichoice 0, 0, MULTI_COMPACT_WEST_0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	case 2, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_1::
	multichoice 0, 0, MULTI_COMPACT_WEST_1, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination9
	case 1, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_2::
	multichoice 0, 0, MULTI_COMPACT_WEST_2, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	case 2, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_3::
	multichoice 0, 0, MULTI_COMPACT_WEST_3, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	case 2, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_4::
	multichoice 0, 0, MULTI_COMPACT_WEST_4, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	case 2, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_5::
	multichoice 0, 0, MULTI_COMPACT_WEST_5, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	case 2, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_6::
	multichoice 0, 0, MULTI_COMPACT_WEST_6, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	case 2, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_7::
	multichoice 0, 0, MULTI_COMPACT_WEST_7, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	case 2, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_8::
	multichoice 0, 0, MULTI_COMPACT_WEST_8, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	case 2, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_9::
	multichoice 0, 0, MULTI_COMPACT_WEST_9, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_10::
	multichoice 0, 0, MULTI_COMPACT_WEST_10, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	case 2, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_11::
	multichoice 0, 0, MULTI_COMPACT_WEST_11, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	case 2, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_12::
	multichoice 0, 0, MULTI_COMPACT_WEST_12, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_13::
	multichoice 0, 0, MULTI_COMPACT_WEST_13, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	case 2, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_14::
	multichoice 0, 0, MULTI_COMPACT_WEST_14, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	case 2, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_15::
	multichoice 0, 0, MULTI_COMPACT_WEST_15, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	case 2, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_16::
	multichoice 0, 0, MULTI_COMPACT_WEST_16, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	case 2, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_WEST_17::
	multichoice 0, 0, MULTI_COMPACT_WEST_17, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination1
	case 1, LavenderNetwork_Destination9
	case 2, LavenderNetwork_Destination12
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST::
	switch VAR_0x8008
	case 0, LavenderNetwork_HOENN_EAST_0
	case 1, LavenderNetwork_HOENN_EAST_1
	case 2, LavenderNetwork_HOENN_EAST_2
	case 3, LavenderNetwork_HOENN_EAST_3
	case 4, LavenderNetwork_HOENN_EAST_4
	case 5, LavenderNetwork_HOENN_EAST_5
	case 6, LavenderNetwork_HOENN_EAST_6
	case 7, LavenderNetwork_HOENN_EAST_7
	case 8, LavenderNetwork_HOENN_EAST_8
	case 9, LavenderNetwork_HOENN_EAST_9
	case 10, LavenderNetwork_HOENN_EAST_10
	case 11, LavenderNetwork_HOENN_EAST_11
	case 12, LavenderNetwork_HOENN_EAST_12
	case 13, LavenderNetwork_HOENN_EAST_13
	case 14, LavenderNetwork_HOENN_EAST_14
	case 15, LavenderNetwork_HOENN_EAST_15
	case 16, LavenderNetwork_HOENN_EAST_16
	case 17, LavenderNetwork_HOENN_EAST_17
	case 18, LavenderNetwork_HOENN_EAST_0
	case 19, LavenderNetwork_HOENN_EAST_0
	case 20, LavenderNetwork_HOENN_EAST_0
	case 21, LavenderNetwork_HOENN_EAST_0
	goto Journey_Ferry_Cancel

LavenderNetwork_HOENN_EAST_0::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination16
	case 3, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_1::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination16
	case 3, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_2::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination16
	case 3, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_3::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination16
	case 3, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_4::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination16
	case 3, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_5::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination16
	case 3, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_6::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination16
	case 3, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_7::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination16
	case 3, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_8::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination16
	case 3, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_9::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination16
	case 3, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_10::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST10, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination11
	case 1, LavenderNetwork_Destination16
	case 2, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_11::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST11, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination16
	case 2, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_12::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination16
	case 3, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_13::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination16
	case 3, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_14::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination16
	case 3, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_15::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination16
	case 3, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_16::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST16, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination17
	goto LavenderNetwork_Menu

LavenderNetwork_HOENN_EAST_17::
	multichoice 0, 0, MULTI_LAVENDER_HOENN_EAST17, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination10
	case 1, LavenderNetwork_Destination11
	case 2, LavenderNetwork_Destination16
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII::
	switch VAR_0x8008
	case 0, LavenderNetwork_SEVII_0
	case 1, LavenderNetwork_SEVII_1
	case 2, LavenderNetwork_SEVII_2
	case 3, LavenderNetwork_SEVII_3
	case 4, LavenderNetwork_SEVII_4
	case 5, LavenderNetwork_SEVII_5
	case 6, LavenderNetwork_SEVII_6
	case 7, LavenderNetwork_SEVII_7
	case 8, LavenderNetwork_SEVII_8
	case 9, LavenderNetwork_SEVII_9
	case 10, LavenderNetwork_SEVII_10
	case 11, LavenderNetwork_SEVII_11
	case 12, LavenderNetwork_SEVII_12
	case 13, LavenderNetwork_SEVII_13
	case 14, LavenderNetwork_SEVII_14
	case 15, LavenderNetwork_SEVII_15
	case 16, LavenderNetwork_SEVII_16
	case 17, LavenderNetwork_SEVII_17
	case 18, LavenderNetwork_SEVII_0
	case 19, LavenderNetwork_SEVII_0
	case 20, LavenderNetwork_SEVII_0
	case 21, LavenderNetwork_SEVII_0
	goto Journey_Ferry_Cancel

LavenderNetwork_SEVII_0::
	multichoice 0, 0, MULTI_LAVENDER_SEVII0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination4
	case 3, LavenderNetwork_Destination5
	case 4, LavenderNetwork_Destination6
	case 5, LavenderNetwork_Destination7
	case 6, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_1::
	multichoice 0, 0, MULTI_LAVENDER_SEVII0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination4
	case 3, LavenderNetwork_Destination5
	case 4, LavenderNetwork_Destination6
	case 5, LavenderNetwork_Destination7
	case 6, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_2::
	multichoice 0, 0, MULTI_LAVENDER_SEVII2, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination3
	case 1, LavenderNetwork_Destination4
	case 2, LavenderNetwork_Destination5
	case 3, LavenderNetwork_Destination6
	case 4, LavenderNetwork_Destination7
	case 5, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_3::
	multichoice 0, 0, MULTI_LAVENDER_SEVII3, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination4
	case 2, LavenderNetwork_Destination5
	case 3, LavenderNetwork_Destination6
	case 4, LavenderNetwork_Destination7
	case 5, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_4::
	multichoice 0, 0, MULTI_LAVENDER_SEVII4, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination5
	case 3, LavenderNetwork_Destination6
	case 4, LavenderNetwork_Destination7
	case 5, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_5::
	multichoice 0, 0, MULTI_LAVENDER_SEVII5, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination4
	case 3, LavenderNetwork_Destination6
	case 4, LavenderNetwork_Destination7
	case 5, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_6::
	multichoice 0, 0, MULTI_LAVENDER_SEVII6, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination4
	case 3, LavenderNetwork_Destination5
	case 4, LavenderNetwork_Destination7
	case 5, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_7::
	multichoice 0, 0, MULTI_LAVENDER_SEVII7, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination4
	case 3, LavenderNetwork_Destination5
	case 4, LavenderNetwork_Destination6
	case 5, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_8::
	multichoice 0, 0, MULTI_LAVENDER_SEVII8, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination4
	case 3, LavenderNetwork_Destination5
	case 4, LavenderNetwork_Destination6
	case 5, LavenderNetwork_Destination7
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_9::
	multichoice 0, 0, MULTI_LAVENDER_SEVII0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination4
	case 3, LavenderNetwork_Destination5
	case 4, LavenderNetwork_Destination6
	case 5, LavenderNetwork_Destination7
	case 6, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_10::
	multichoice 0, 0, MULTI_LAVENDER_SEVII0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination4
	case 3, LavenderNetwork_Destination5
	case 4, LavenderNetwork_Destination6
	case 5, LavenderNetwork_Destination7
	case 6, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_11::
	multichoice 0, 0, MULTI_LAVENDER_SEVII0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination4
	case 3, LavenderNetwork_Destination5
	case 4, LavenderNetwork_Destination6
	case 5, LavenderNetwork_Destination7
	case 6, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_12::
	multichoice 0, 0, MULTI_LAVENDER_SEVII0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination4
	case 3, LavenderNetwork_Destination5
	case 4, LavenderNetwork_Destination6
	case 5, LavenderNetwork_Destination7
	case 6, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_13::
	multichoice 0, 0, MULTI_LAVENDER_SEVII0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination4
	case 3, LavenderNetwork_Destination5
	case 4, LavenderNetwork_Destination6
	case 5, LavenderNetwork_Destination7
	case 6, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_14::
	multichoice 0, 0, MULTI_LAVENDER_SEVII0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination4
	case 3, LavenderNetwork_Destination5
	case 4, LavenderNetwork_Destination6
	case 5, LavenderNetwork_Destination7
	case 6, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_15::
	multichoice 0, 0, MULTI_LAVENDER_SEVII0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination4
	case 3, LavenderNetwork_Destination5
	case 4, LavenderNetwork_Destination6
	case 5, LavenderNetwork_Destination7
	case 6, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_16::
	multichoice 0, 0, MULTI_LAVENDER_SEVII0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination4
	case 3, LavenderNetwork_Destination5
	case 4, LavenderNetwork_Destination6
	case 5, LavenderNetwork_Destination7
	case 6, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_SEVII_17::
	multichoice 0, 0, MULTI_LAVENDER_SEVII0, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination2
	case 1, LavenderNetwork_Destination3
	case 2, LavenderNetwork_Destination4
	case 3, LavenderNetwork_Destination5
	case 4, LavenderNetwork_Destination6
	case 5, LavenderNetwork_Destination7
	case 6, LavenderNetwork_Destination8
	goto LavenderNetwork_Menu

LavenderNetwork_Destination0::
	goto_if_eq VAR_0x8008, 0, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_LAVENDER_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_LAVENDER_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 0
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

LavenderNetwork_Destination1::
	goto_if_eq VAR_0x8008, 1, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_SLATEPORT_CITY_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_SLATEPORT_CITY_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 14
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

LavenderNetwork_Destination2::
	goto_if_eq VAR_0x8008, 2, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_SEVII_ONE_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_SEVII_ONE_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

LavenderNetwork_Destination3::
	goto_if_eq VAR_0x8008, 3, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_SEVII_TWO_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_SEVII_TWO_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

LavenderNetwork_Destination4::
	goto_if_eq VAR_0x8008, 4, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_SEVII_THREE_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_SEVII_THREE_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

LavenderNetwork_Destination5::
	goto_if_eq VAR_0x8008, 5, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_SEVII_FOUR_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_SEVII_FOUR_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

LavenderNetwork_Destination6::
	goto_if_eq VAR_0x8008, 6, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_SEVII_FIVE_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_SEVII_FIVE_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

LavenderNetwork_Destination7::
	goto_if_eq VAR_0x8008, 7, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_SEVII_SIX_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_SEVII_SIX_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

LavenderNetwork_Destination8::
	goto_if_eq VAR_0x8008, 8, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_SEVII_SEVEN_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_SEVII_SEVEN_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

Journey_FerryPort9::
	setvar VAR_0x8008, 9
	goto Journey_Ferry

LavenderNetwork_Destination9::
	goto_if_eq VAR_0x8008, 9, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_DEWFORD_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_DEWFORD_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

Journey_FerryPort10::
	setvar VAR_0x8008, 10
	goto Journey_Ferry

LavenderNetwork_Destination10::
	goto_if_eq VAR_0x8008, 10, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_LILYCOVE_CITY_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_LILYCOVE_CITY_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 4
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

Journey_FerryPort11::
	setvar VAR_0x8008, 11
	goto Journey_Ferry

LavenderNetwork_Destination11::
	goto_if_eq VAR_0x8008, 11, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_PACIFIDLOG_TOWN)
	setvar VAR_0x8005, MAP_NUM(MAP_PACIFIDLOG_TOWN)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 10
	setvar VAR_0x800A, 27
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

Journey_FerryPort12::
	setvar VAR_0x8008, 12
	goto Journey_Ferry

LavenderNetwork_Destination12::
	goto_if_eq VAR_0x8008, 12, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_PETALBURG_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_PETALBURG_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

Journey_FerryPort13::
	setvar VAR_0x8008, 13
	goto Journey_Ferry

LavenderNetwork_Destination13::
	goto_if_eq VAR_0x8008, 13, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_ROUTE109)
	setvar VAR_0x8005, MAP_NUM(MAP_ROUTE109)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 23
	setvar VAR_0x800A, 22
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

Journey_FerryPort14::
	setvar VAR_0x8008, 14
	goto Journey_Ferry

LavenderNetwork_Destination14::
	goto_if_eq VAR_0x8008, 14, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_VERMILION_CITY)
	setvar VAR_0x8005, MAP_NUM(MAP_VERMILION_CITY)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 0
	setvar VAR_0x8009, 23
	setvar VAR_0x800A, 33
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

Journey_FerryPort15::
	setvar VAR_0x8008, 15
	goto Journey_Ferry

LavenderNetwork_Destination15::
	goto_if_eq VAR_0x8008, 15, Journey_Ferry_AlreadyHere
	checkitem ITEM_SS_TICKET
	goto_if_eq VAR_RESULT, FALSE, LavenderNetwork_FrontierLocked
	goto_if_unset FLAG_SYS_GAME_CLEAR, LavenderNetwork_FrontierLocked
	goto_if_unset FLAG_MET_SCOTT_ON_SS_TIDAL, LavenderNetwork_FrontierLocked
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_BATTLE_FRONTIER_OUTSIDE_WEST)
	setvar VAR_0x8005, MAP_NUM(MAP_BATTLE_FRONTIER_OUTSIDE_WEST)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 20
	setvar VAR_0x800A, 71
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

Journey_FerryPort16::
	setvar VAR_0x8008, 16
	goto Journey_Ferry

LavenderNetwork_Destination16::
	goto_if_eq VAR_0x8008, 16, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_MOSSDEEP_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_MOSSDEEP_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

Journey_FerryPort17::
	setvar VAR_0x8008, 17
	goto Journey_Ferry

LavenderNetwork_Destination17::
	goto_if_eq VAR_0x8008, 17, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_SOOTOPOLIS_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_SOOTOPOLIS_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 1
	setvar VAR_0x8009, 8
	setvar VAR_0x800A, 12
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

LavenderNetwork_Service1_0::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Service1_0_World
	case 1, LavenderNetwork_Service1_0_Local
	release
	end
LavenderNetwork_Service1_0_World::
	release
	goto Journey_FerryPort1
LavenderNetwork_Service1_0_Local::
	release
	goto SlateportCity_Harbor_EventScript_FerryAttendant

LavenderNetwork_Service2_1::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Service2_1_World
	case 1, LavenderNetwork_Service2_1_Local
	release
	end
LavenderNetwork_Service2_1_World::
	release
	goto Journey_FerryPort2
LavenderNetwork_Service2_1_Local::
	release
	goto OneIsland_Harbor_EventScript_Sailor

LavenderNetwork_Service3_2::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Service3_2_World
	case 1, LavenderNetwork_Service3_2_Local
	release
	end
LavenderNetwork_Service3_2_World::
	release
	goto Journey_FerryPort3
LavenderNetwork_Service3_2_Local::
	release
	goto TwoIsland_Harbor_EventScript_Sailor

LavenderNetwork_Service4_3::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Service4_3_World
	case 1, LavenderNetwork_Service4_3_Local
	release
	end
LavenderNetwork_Service4_3_World::
	release
	goto Journey_FerryPort4
LavenderNetwork_Service4_3_Local::
	release
	goto ThreeIsland_Harbor_EventScript_Sailor

LavenderNetwork_Service5_4::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Service5_4_World
	case 1, LavenderNetwork_Service5_4_Local
	release
	end
LavenderNetwork_Service5_4_World::
	release
	goto Journey_FerryPort5
LavenderNetwork_Service5_4_Local::
	release
	goto FourIsland_Harbor_EventScript_Sailor

LavenderNetwork_Service6_5::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Service6_5_World
	case 1, LavenderNetwork_Service6_5_Local
	release
	end
LavenderNetwork_Service6_5_World::
	release
	goto Journey_FerryPort6
LavenderNetwork_Service6_5_Local::
	release
	goto FiveIsland_Harbor_EventScript_Sailor

LavenderNetwork_Service7_6::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Service7_6_World
	case 1, LavenderNetwork_Service7_6_Local
	release
	end
LavenderNetwork_Service7_6_World::
	release
	goto Journey_FerryPort7
LavenderNetwork_Service7_6_Local::
	release
	goto SixIsland_Harbor_EventScript_Sailor

LavenderNetwork_Service8_7::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Service8_7_World
	case 1, LavenderNetwork_Service8_7_Local
	release
	end
LavenderNetwork_Service8_7_World::
	release
	goto Journey_FerryPort8
LavenderNetwork_Service8_7_Local::
	release
	goto SevenIsland_Harbor_EventScript_Sailor

LavenderNetwork_Service9_8::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Service9_8_World
	case 1, LavenderNetwork_Service9_8_Local
	release
	end
LavenderNetwork_Service9_8_World::
	release
	goto Journey_FerryPort9
LavenderNetwork_Service9_8_Local::
	release
	goto DewfordTown_EventScript_Briney

LavenderNetwork_Service10_9::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Service10_9_World
	case 1, LavenderNetwork_Service10_9_Local
	release
	end
LavenderNetwork_Service10_9_World::
	release
	goto Journey_FerryPort10
LavenderNetwork_Service10_9_Local::
	release
	goto LilycoveCity_Harbor_EventScript_Sailor

LavenderNetwork_Service10_10::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Service10_10_World
	case 1, LavenderNetwork_Service10_10_Local
	release
	end
LavenderNetwork_Service10_10_World::
	release
	goto Journey_FerryPort10
LavenderNetwork_Service10_10_Local::
	release
	goto LilycoveCity_Harbor_EventScript_FerryAttendant

LavenderNetwork_Service14_11::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Service14_11_World
	case 1, LavenderNetwork_Service14_11_Local
	release
	end
LavenderNetwork_Service14_11_World::
	release
	goto Journey_FerryPort14
LavenderNetwork_Service14_11_Local::
	release
	goto VermilionCity_EventScript_FerrySailor

LavenderNetwork_Service15_12::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Service15_12_World
	case 1, LavenderNetwork_Service15_12_Local
	release
	end
LavenderNetwork_Service15_12_World::
	release
	goto Journey_FerryPort15
LavenderNetwork_Service15_12_Local::
	release
	goto BattleFrontier_OutsideWest_EventScript_FerryAttendant

LavenderNetwork_Route104_MrBrineysHouse::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Route104_MrBrineysHouse_World
	case 1, LavenderNetwork_Route104_MrBrineysHouse_Local
	release
	end
LavenderNetwork_Route104_MrBrineysHouse_World::
	release
	goto Journey_FerryPort12
LavenderNetwork_Route104_MrBrineysHouse_Local::
	release
	goto Route104_MrBrineysHouse_EventScript_Briney

LavenderNetwork_Route109::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Route109_World
	case 1, LavenderNetwork_Route109_Local
	release
	end
LavenderNetwork_Route109_World::
	release
	goto Journey_FerryPort13
LavenderNetwork_Route109_Local::
	release
	goto Route109_EventScript_MrBriney

LavenderNetwork_Where::
	.string "Which region would you like to visit?$"
LavenderNetwork_ServiceText::
	.string "World ports or the local service?$"
LavenderNetwork_FrontierLocked::
	msgbox LavenderNetwork_FrontierText, MSGBOX_DEFAULT
	goto LavenderNetwork_Menu
LavenderNetwork_FrontierText::
	.string "Use the local S.S. TIDAL service\n"
	.string "for your first FRONTIER visit.\p"
	.string "Become HOENN CHAMPION and bring\n"
	.string "your S.S. TICKET to board.$"

Journey_FerryPort19::
	setvar VAR_0x8008, 19
	goto Journey_Ferry

LavenderNetwork_Destination19::
	goto_if_eq VAR_0x8008, 19, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_CINNABAR_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_CINNABAR_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 0
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

Journey_FerryPort18::
	setvar VAR_0x8008, 18
	goto Journey_Ferry

LavenderNetwork_Destination18::
	goto_if_eq VAR_0x8008, 18, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_PALLET_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_PALLET_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 0
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

Journey_FerryPort20::
	setvar VAR_0x8008, 20
	goto Journey_Ferry

LavenderNetwork_Destination20::
	goto_if_eq VAR_0x8008, 20, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_FUCHSIA_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_FUCHSIA_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 0
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

Journey_FerryPort21::
	setvar VAR_0x8008, 21
	goto Journey_Ferry

LavenderNetwork_Destination21::
	goto_if_eq VAR_0x8008, 21, Journey_Ferry_AlreadyHere
	msgbox Journey_Ferry_BoardText, MSGBOX_DEFAULT
	closemessage
	setvar VAR_0x8004, MAP_GROUP(MAP_JOURNEY_CERULEAN_HARBOR)
	setvar VAR_0x8005, MAP_NUM(MAP_JOURNEY_CERULEAN_HARBOR)
	setvar VAR_0x8006, 65535
	setvar VAR_0x8007, 0
	setvar VAR_0x8009, 16
	setvar VAR_0x800A, 13
	fadescreen FADE_TO_BLACK
	special DoSeagallopFerryScene
	waitstate
	end

LavenderNetwork_KANTO_18::
	multichoice 0, 0, MULTI_COMPACT_KANTO_18, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination19
	case 3, LavenderNetwork_Destination20
	case 4, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu

LavenderNetwork_KANTO_19::
	multichoice 0, 0, MULTI_COMPACT_KANTO_19, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination20
	case 4, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu

LavenderNetwork_KANTO_20::
	multichoice 0, 0, MULTI_COMPACT_KANTO_20, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination21
	goto LavenderNetwork_Menu

LavenderNetwork_KANTO_21::
	multichoice 0, 0, MULTI_COMPACT_KANTO_21, FALSE
	switch VAR_RESULT
	case 0, LavenderNetwork_Destination0
	case 1, LavenderNetwork_Destination14
	case 2, LavenderNetwork_Destination18
	case 3, LavenderNetwork_Destination19
	case 4, LavenderNetwork_Destination20
	goto LavenderNetwork_Menu

JourneyCompactPort_Boat::
	msgbox JourneyCompactPort_BoatText, MSGBOX_NPC
	end
JourneyCompactPort_BoatText::
	.string "A boat moored safely at the pier.$"

JourneyHarbor_Worker::
	msgbox JourneyHarbor_WorkerText, MSGBOX_NPC
	end
JourneyHarbor_WorkerText::
	.string "Speak to the captain near the\nentrance to arrange your voyage.$"

ThreeHarbors_PetalburgCaptain::
	lock
	faceplayer
	msgbox LavenderNetwork_ServiceText, MSGBOX_DEFAULT
	closemessage
	multichoice 0, 0, MULTI_LAVENDER_SERVICES, FALSE
	switch VAR_RESULT
	case 0, ThreeHarbors_PetalburgWorld
	case 1, ThreeHarbors_PetalburgLocal
	release
	end
ThreeHarbors_PetalburgWorld::
	release
	goto Journey_FerryPort12
ThreeHarbors_PetalburgLocal::
	warp MAP_ROUTE104_MR_BRINEYS_HOUSE, 255, 5, 7
	waitstate
	release
	end
