#ifndef GUARD_JOURNEY_ATLAS_ECOLOGY_H
#define GUARD_JOURNEY_ATLAS_ECOLOGY_H
u16 JourneyAtlasEcologyOwner(u16 map);
#endif
