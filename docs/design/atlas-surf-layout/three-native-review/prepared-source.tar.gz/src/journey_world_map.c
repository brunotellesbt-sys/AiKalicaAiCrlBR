#include "global.h"
#include "data/journey_atlas_runtime.h"
#include "data/journey_atlas_dives.h"
#include "field_player_avatar.h"
#include "fieldmap.h"
#include "bg.h"
#include "event_data.h"
#include "gpu_regs.h"
#include "main.h"
#include "malloc.h"
#include "menu.h"
#include "overworld.h"
#include "palette.h"
#include "sprite.h"
#include "text.h"
#include "text_window.h"
#include "window.h"
#include "sound.h"
#include "field_effect.h"
#include "party_menu.h"
#include "item_menu.h"
#include "constants/maps.h"
#include "constants/rgb.h"
#include "constants/songs.h"
#include "journey_world_map.h"

extern bool8 gFlightCallFromBag;
void ClearForcedFlightRegion(void);

struct JourneyWorldPoint { u16 map; u16 section; u8 x, y; const u8 *name; };
#include "data/journey_world_map.h"
#include "data/journey_world_position.h"
#include "journey_atlas_zoom.inc"

static EWRAM_DATA struct {
    MainCallback callback;
    u16 tilemap[1024];
    u16 player, selected;
    u8 x, y, state, fly, playerX, playerY;
    u8 zoom,viewX,viewY;
    u8 *zoomTiles;
} *sJourneyWorldMap;

static const struct BgTemplate sWorldBgs[] = {
    {.bg=0, .charBaseIndex=0, .mapBaseIndex=31, .priority=0},
    {.bg=1, .charBaseIndex=2, .mapBaseIndex=30, .priority=1}
};
static const struct WindowTemplate sWorldWindows[] = {
    {.bg=0,.tilemapLeft=1,.tilemapTop=0,.width=28,.height=3,.paletteNum=15,.baseBlock=1},
    {.bg=0,.tilemapLeft=1,.tilemapTop=17,.width=28,.height=3,.paletteNum=15,.baseBlock=85},
    {.bg=0,.tilemapLeft=1,.tilemapTop=3,.width=28,.height=14,.paletteNum=15,.baseBlock=170},
    DUMMY_WIN_TEMPLATE
};
static const u16 sWorldUiPalette[] = { RGB(0,0,0), RGB(3,5,9), RGB(31,31,31), RGB(10,12,15), RGB(31,4,4), RGB(0,31,31) };

const u8 *JourneyCurrentMapName(void)
{
    u16 i, map = (gSaveBlock1Ptr->location.mapGroup << 8) | gSaveBlock1Ptr->location.mapNum;
    for (i = 0; i < ARRAY_COUNT(sWorldPoints); i++)
        if (sWorldPoints[i].map == map) return sWorldPoints[i].name;
    return NULL;
}

u16 JourneyWorldMapPlayerPoint(void)
{
    u16 i, map=(gSaveBlock1Ptr->location.mapGroup<<8)|gSaveBlock1Ptr->location.mapNum;
    for(i=0;i<ARRAY_COUNT(sWorldPoints);i++) if(sWorldPoints[i].map==map) return i;
    // Interiors, underwater areas and native caves retain their regional section.
    for(i=0;i<ARRAY_COUNT(sWorldPoints);i++) if(sWorldPoints[i].section==gMapHeader.regionMapSectionId) return i;
    return 0;
}

// Shared edge anchors make adjoining maps agree at the connection itself.
// Distances use local tile coordinates, so short moves never select a distant
// route centre merely because the map ID changed.
u16 JourneyWorldMapPosition(void)
{
    u16 atlasPosition;
    u16 map = (gSaveBlock1Ptr->location.mapGroup << 8) | gSaveBlock1Ptr->location.mapNum;
    u16 i, point;
    s16 x, y;
    PlayerGetDestCoords(&x, &y);
    x -= MAP_OFFSET; y -= MAP_OFFSET;
    if (JourneyAtlasPosition(gSaveBlock1Ptr->location.mapGroup,
        gSaveBlock1Ptr->location.mapNum, x, y, &atlasPosition))
        return atlasPosition;
    if (JourneyAtlasDepthPosition(gSaveBlock1Ptr->location.mapGroup,
        gSaveBlock1Ptr->location.mapNum, x, y, &atlasPosition))
        return atlasPosition;
    for (i = 0; i < ARRAY_COUNT(sWorldTileGrids); i++)
    {
        const struct JourneyWorldTileGrid *grid = &sWorldTileGrids[i];
        if (grid->map != map) continue;
        if (x < 0) x = 0;
        if (y < 0) y = 0;
        if (x >= grid->width) x = grid->width - 1;
        if (y >= grid->height) y = grid->height - 1;
        return sWorldNavigationPixels[grid->first + y * grid->width + x];
    }
    point = JourneyWorldMapPlayerPoint();
    return sWorldPoints[point].x | (sWorldPoints[point].y << 8);
}

static void JourneyAtlasDrawPlayerMarker(s16 x, s16 y)
{
    s16 left = x - 1, top = y - 1, right = x + 2, bottom = y + 2;
    if (left < 0) left = 0;
    if (top < 0) top = 0;
    if (right > 224) right = 224;
    if (bottom > 112) bottom = 112;
    if (left < right && top < bottom)
        FillWindowPixelRect(2, PIXEL_FILL(5), left, top, right - left, bottom - top);
}

static void WorldDraw(void)
{
    u16 i, best=0;
    u32 distance=65535, d;
    s16 dx,dy;

    for(i=0;i<ARRAY_COUNT(sWorldPoints);i++) {
        if(sJourneyWorldMap->fly && !JourneyWorldFlyAllowed(sWorldPoints[i].map,sWorldPoints[i].section))continue;
        dx=sJourneyWorldMap->x-sWorldPoints[i].x;dy=sJourneyWorldMap->y-sWorldPoints[i].y;d=dx*dx+dy*dy;
        if(d<distance){distance=d;best=i;}
    }
    if (sJourneyWorldMap->x == sJourneyWorldMap->playerX && sJourneyWorldMap->y == sJourneyWorldMap->playerY)
    {
        best = sJourneyWorldMap->player;
        distance = 0;
    }
    sJourneyWorldMap->selected=best;
    JourneyAtlasDraw(1,sJourneyWorldMap->tilemap,0,sJourneyWorldMap->zoom,sJourneyWorldMap->x,sJourneyWorldMap->y,sJourneyWorldMap->zoomTiles,&sJourneyWorldMap->viewX,&sJourneyWorldMap->viewY);
    s16 playerX=sJourneyWorldMap->zoom?2*((s16)sJourneyWorldMap->playerX-sJourneyWorldMap->viewX):sJourneyWorldMap->playerX;
    s16 playerY=sJourneyWorldMap->zoom?2*((s16)sJourneyWorldMap->playerY-sJourneyWorldMap->viewY):sJourneyWorldMap->playerY;
    s16 cursorX=sJourneyWorldMap->zoom?2*((s16)sJourneyWorldMap->x-sJourneyWorldMap->viewX):sJourneyWorldMap->x;
    s16 cursorY=sJourneyWorldMap->zoom?2*((s16)sJourneyWorldMap->y-sJourneyWorldMap->viewY):sJourneyWorldMap->y;
    FillWindowPixelBuffer(2,PIXEL_FILL(0));

    FillWindowPixelRect(2,PIXEL_FILL(4),cursorX-3,cursorY-3,7,7);
    FillWindowPixelRect(2,PIXEL_FILL(0),cursorX-2,cursorY-2,5,5);
    FillWindowPixelRect(2,PIXEL_FILL(2),cursorX,cursorY,1,1);
    JourneyAtlasDrawPlayerMarker(playerX,playerY);
    FillWindowPixelBuffer(1,PIXEL_FILL(1));
    AddTextPrinterParameterized(1,FONT_SMALL,distance<100?sWorldPoints[best].name:COMPOUND_STRING("OPEN SEA"),0,0,0,NULL);
    AddTextPrinterParameterized(1,FONT_SMALL,sJourneyWorldMap->fly?COMPOUND_STRING("A: FLY  R: ZOOM  B: BACK"):COMPOUND_STRING("R: ZOOM  SELECT: YOU  B: BACK"),0,12,0,NULL);
    CopyWindowToVram(1,COPYWIN_FULL);CopyWindowToVram(2,COPYWIN_FULL);
}

static void WorldVBlank(void) { LoadOam();ProcessSpriteCopyRequests();TransferPlttBuffer(); }

void CB2_JourneyWorldMap(void)
{
    if(sJourneyWorldMap->state==0) {
        SetGpuReg(REG_OFFSET_DISPCNT,0);ResetBgsAndClearDma3BusyFlags(0);
        ResetSpriteData();FreeAllSpritePalettes();ResetPaletteFade();
        InitBgsFromTemplates(0,sWorldBgs,ARRAY_COUNT(sWorldBgs));
        ChangeBgX(0,0,BG_COORD_SET);ChangeBgY(0,0,BG_COORD_SET);
        ChangeBgX(1,0,BG_COORD_SET);ChangeBgY(1,0,BG_COORD_SET);
        SetBgTilemapBuffer(1,sJourneyWorldMap->tilemap);
        CpuCopy16(sWorldTilemap,sJourneyWorldMap->tilemap,sizeof(sWorldTilemap));
        LoadBgTiles(1,sWorldTiles,sizeof(sWorldTiles),0);CopyBgTilemapBufferToVram(1);
        LoadPalette(sWorldPalette,0,sizeof(sWorldPalette));LoadPalette(sWorldUiPalette,BG_PLTT_ID(15),sizeof(sWorldUiPalette));
        InitWindows(sWorldWindows);DeactivateAllTextPrinters();
        FillWindowPixelBuffer(0,PIXEL_FILL(1));
        AddTextPrinterParameterized(0,FONT_SMALL,COMPOUND_STRING("WORLD MAP: KANTO / HOENN / SEVII"),0,0,0,NULL);
        AddTextPrinterParameterized(0,FONT_SMALL,COMPOUND_STRING("CYAN: YOU   RED: CURSOR"),0,12,0,NULL);
        PutWindowTilemap(0);PutWindowTilemap(1);PutWindowTilemap(2);CopyWindowToVram(0,COPYWIN_FULL);
        WorldDraw();ShowBg(0);ShowBg(1);SetVBlankCallback(WorldVBlank);
        BeginNormalPaletteFade(PALETTES_ALL,0,16,0,RGB_BLACK);sJourneyWorldMap->state=1;
    } else if(sJourneyWorldMap->state==1 && !gPaletteFade.active) {
        if(JOY_NEW(B_BUTTON)) { BeginNormalPaletteFade(PALETTES_ALL,0,0,16,RGB_BLACK);sJourneyWorldMap->state=2; }
        else if(JOY_NEW(R_BUTTON) || (!sJourneyWorldMap->fly && JOY_NEW(A_BUTTON))) {
            if(sJourneyWorldMap->zoomTiles==NULL)sJourneyWorldMap->zoomTiles=AllocZeroed(393*32);
            if(sJourneyWorldMap->zoomTiles!=NULL){sJourneyWorldMap->zoom^=1;WorldDraw();}
            else PlaySE(SE_FAILURE);
        }
        else if(sJourneyWorldMap->fly && JOY_NEW(A_BUTTON)) {
            const struct JourneyWorldPoint *p=&sWorldPoints[sJourneyWorldMap->selected];
            s16 dx=sJourneyWorldMap->x-p->x,dy=sJourneyWorldMap->y-p->y;
            if(dx*dx+dy*dy<=16 && JourneyWorldFlyAllowed(p->map,p->section)) {
                BeginNormalPaletteFade(PALETTES_ALL,0,0,16,RGB_BLACK);sJourneyWorldMap->state=3;
            }
        }
        else {
            u8 x=sJourneyWorldMap->x,y=sJourneyWorldMap->y;
            if(JOY_REPEAT(DPAD_LEFT) && x>5)x-=3;
            if(JOY_REPEAT(DPAD_RIGHT) && x<217)x+=3;
            if(JOY_REPEAT(DPAD_UP) && y>5)y-=3;
            if(JOY_REPEAT(DPAD_DOWN) && y<107)y+=3;
            if(JOY_NEW(SELECT_BUTTON)){x=sJourneyWorldMap->playerX;y=sJourneyWorldMap->playerY;}
            if(x!=sJourneyWorldMap->x || y!=sJourneyWorldMap->y){sJourneyWorldMap->x=x;sJourneyWorldMap->y=y;WorldDraw();}
        }
    } else if((sJourneyWorldMap->state==2 || sJourneyWorldMap->state==3) && !gPaletteFade.active) {
        MainCallback callback=sJourneyWorldMap->callback;
        bool8 fly=sJourneyWorldMap->state==3;
        bool8 wasFly=sJourneyWorldMap->fly;
        u16 map=sWorldPoints[sJourneyWorldMap->selected].map,section=sWorldPoints[sJourneyWorldMap->selected].section;
        SetVBlankCallback(NULL);FreeAllWindowBuffers();UnsetBgTilemapBuffer(1);
        TRY_FREE_AND_SET_NULL(sJourneyWorldMap->zoomTiles);
        FREE_AND_SET_NULL(sJourneyWorldMap);
        if(fly) {
            JourneyWorldFlyDestination(map,section);
            if(gFlightCallFromBag)gSkipShowMonAnim=TRUE;
            gFlightCallFromBag=FALSE;ClearForcedFlightRegion();ReturnToFieldFromFlyMapSelect();
        } else {
            if(wasFly){ClearForcedFlightRegion();gFlightCallFromBag=FALSE;}
            SetMainCallback2(callback);
        }
        return;
    }
    UpdatePaletteFade();
}

void JourneyWorldMapOpen(MainCallback callback)
{
    u16 position = JourneyWorldMapPosition();
    SetVBlankCallback(NULL);
    sJourneyWorldMap=AllocZeroed(sizeof(*sJourneyWorldMap));
    if(sJourneyWorldMap==NULL){SetMainCallback2(callback);return;}
    sJourneyWorldMap->callback=callback;sJourneyWorldMap->player=JourneyWorldMapPlayerPoint();
    sJourneyWorldMap->x=sJourneyWorldMap->playerX=position & 255;sJourneyWorldMap->y=sJourneyWorldMap->playerY=position >> 8;
    SetMainCallback2(CB2_JourneyWorldMap);
}

void JourneyWorldMapOpenFly(void)
{
    JourneyWorldMapOpen(gFlightCallFromBag?CB2_ReturnToBagMenuPocket:CB2_ReturnToPartyMenuFromFlyMap);
    if(sJourneyWorldMap!=NULL)sJourneyWorldMap->fly=TRUE;
}
