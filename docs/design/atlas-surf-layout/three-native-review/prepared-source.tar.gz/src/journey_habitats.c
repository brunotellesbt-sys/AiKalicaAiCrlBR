#include "global.h"
#include "journey_atlas_ecology.h"
#include "journey_version.h"
#include "journey_habitats.h"
#include "constants/maps.h"
#include "constants/species.h"
#include "journey_habitat_data.h"
#include "journey_generation4_habitats.h"
#include "data/journey_event_habitats.h"
#include "pokemon.h"
bool32 JourneyHabitatHasSpecies(u32 group, u32 map, u32 species)
{
    u16 ecologyMap;
    u32 i, j;
    u32 dex=SpeciesToNationalPokedexNum(species);
    for(i=0;i<ARRAY_COUNT(sJourneyEventDex);i++)if(dex==sJourneyEventDex[i])
    {
        if(!JourneySpeciesAllowed(species))return FALSE;
        for(j=0;j<ARRAY_COUNT(sJourneyEventHabitats);j++)
            if(dex==sJourneyEventHabitats[j].dex && group==MAP_GROUP(sJourneyEventHabitats[j].map) && map==MAP_NUM(sJourneyEventHabitats[j].map))return TRUE;
        return FALSE;
    }
    ecologyMap = JourneyAtlasEcologyOwner((group << 8) | map);
    group = MAP_GROUP(ecologyMap);
    map = MAP_NUM(ecologyMap);

    if(gJourneyBuildRules.maxNational==493)
    {
        for(i=0;i<ARRAY_COUNT(sJourneyGeneration4Habitats);i++)
            if(group==MAP_GROUP(sJourneyGeneration4Habitats[i].map) && map==MAP_NUM(sJourneyGeneration4Habitats[i].map))
                for(j=0;j<sJourneyGeneration4Habitats[i].count;j++)if(species==sJourneyGeneration4Habitats[i].species[j])return TRUE;
        return FALSE;
    }

    for (i = 0; i < ARRAY_COUNT(sJourneyHabitats); i++)
        if (group == MAP_GROUP(sJourneyHabitats[i].map) && map == MAP_NUM(sJourneyHabitats[i].map))
            for (j = 0; j < sJourneyHabitats[i].count; j++)
                if (species == sJourneyHabitats[i].species[j]) return TRUE;
    return FALSE;
}
