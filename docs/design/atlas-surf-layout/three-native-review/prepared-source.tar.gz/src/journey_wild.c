#include "global.h"
#include "journey_atlas_ecology.h"
#include "journey_version.h"
#include "pokemon.h"
#include "random.h"
#include "event_data.h"
#include "journey_gym_scaling.h"
#include "journey_wild.h"
#include "constants/species.h"
#include "constants/vars.h"
#include "constants/maps.h"

struct JourneyWildStages { u16 root; u8 count[3]; u16 stages[3][8]; };
struct JourneyWildPool { u16 map; u8 area, count; u16 species[24]; };
#include "journey_wild_data.h"
#include "journey_generation4_pools.h"

u32 JourneyWildMean(void)
{
    u32 total = 0, count = 0, i;
    for (i = 0; i < PARTY_SIZE; i++)
        if (GetMonData(&gPlayerParty[i], MON_DATA_SPECIES) != SPECIES_NONE
         && !GetMonData(&gPlayerParty[i], MON_DATA_IS_EGG))
        {
            total += GetMonData(&gPlayerParty[i], MON_DATA_LEVEL);
            count++;
        }
    return count ? total / count : 5;
}

u32 JourneyWildLevel(void)
{
    u32 mean = JourneyWildMean();
    u32 low = mean > 5 ? mean - 5 : 1;
    u32 high = mean < 98 ? mean + 2 : 100;
    return low + Random() % (high - low + 1);
}

u32 JourneyWildNormalizeLevel(u32 level)
{
    u32 mean = JourneyWildMean();
    if (level >= (mean > 5 ? mean - 5 : 1) && level <= (mean < 98 ? mean + 2 : 100))
        return level;
    return JourneyWildLevel();
}

u32 JourneyWildPhase(void)
{
    u32 kanto = JourneyGymBadgeCount(TRUE), hoenn = JourneyGymBadgeCount(FALSE);
    u32 progress = (kanto + hoenn) / 2;
    return progress < 3 ? 0 : progress < 6 ? 1 : 2;
}

bool32 JourneyAquaticSpecies(u32 species)
{
    if(gSpeciesInfo[species].types[0]==TYPE_WATER || gSpeciesInfo[species].types[1]==TYPE_WATER)return TRUE;
    switch(species){
    case SPECIES_AZURILL:
    case SPECIES_QWILFISH_HISUI:
    case SPECIES_OVERQWIL:
    case SPECIES_DRAGALGE:
    case SPECIES_DHELMISE:
    case SPECIES_CLOBBOPUS:
    case SPECIES_GRAPPLOCT:
    case SPECIES_EISCUE_ICE:
    case SPECIES_EISCUE_NOICE:
        return TRUE;
    default:return FALSE;}
}
u32 JourneyWildSpecies(u32 original,u32 area)
{
    u16 ecologyMap = JourneyAtlasEcologyOwner((gSaveBlock1Ptr->location.mapGroup << 8) | gSaveBlock1Ptr->location.mapNum);
    const struct JourneyWildPool *pools=gJourneyBuildRules.maxNational==493?sJourneyGeneration4Pools:sJourneyWildPools;
    u32 length=gJourneyBuildRules.maxNational==493?ARRAY_COUNT(sJourneyGeneration4Pools):ARRAY_COUNT(sJourneyWildPools);
    static const u16 eventDex[]={137,138,139,140,141,142,201,233,345,346,347,348,351,408,409,410,411,442,474,479,564,565,566,567,696,697,698,699,880,881,882,883,999,1000};
    u32 selected=original,phase=JourneyWildPhase(),stage;
    bool32 water=area==1 || area==3;
    for(u32 k=0;k<length;k++)
    {
        const struct JourneyWildPool *p=&pools[k];
        if(MAP_GROUP(p->map)!=MAP_GROUP(ecologyMap) || MAP_NUM(p->map)!=MAP_NUM(ecologyMap) || p->area!=area)continue;
        if(!p->count)return SPECIES_NONE;
        static const u8 rates[]={20,20,10,10,10,10,5,5,4,4,1,1};
        if(p->count==ARRAY_COUNT(rates))
        {
            u32 roll=Random()%100;
            for(u32 j=0;j<p->count;j++)
            {
                if(roll<rates[j]){selected=p->species[j];break;}
                roll-=rates[j];
            }
        }
        else selected=p->species[Random()%p->count];
        break;
    }
    if(selected==SPECIES_NONE || selected>=ARRAY_COUNT(sJourneyWildStages))return SPECIES_NONE;
    for(u32 event=0;event<ARRAY_COUNT(eventDex);event++)
        if(SpeciesToNationalPokedexNum(selected)==eventDex[event])return SPECIES_NONE;
    const struct JourneyWildStages *family=&sJourneyWildStages[selected];
    stage=phase==0?0:phase==1?Random()%2:1+Random()%2;
    for(u32 attempt=0;attempt<3;attempt++)
    {
        u16 eligible[8];u32 count=0;
        for(u32 i=0;i<family->count[stage];i++)
        {
            u16 species=family->stages[stage][i];
            if(JourneySpeciesAllowed(species) && (!water || JourneyAquaticSpecies(species)))eligible[count++]=species;
        }
        if(count)return eligible[Random()%count];
        stage=stage?stage-1:0;
    }
    return SPECIES_NONE;
}

u32 JourneyFishingOdds(u32 base)
{
    u16 ecologyMap = JourneyAtlasEcologyOwner((gSaveBlock1Ptr->location.mapGroup << 8) | gSaveBlock1Ptr->location.mapNum);
    u32 i;
    for (i = 0; i < ARRAY_COUNT(sJourneyFishingHabitats); i++)
        if (MAP_GROUP(sJourneyFishingHabitats[i].map) == MAP_GROUP(ecologyMap)
         && MAP_NUM(sJourneyFishingHabitats[i].map) == MAP_NUM(ecologyMap))
            return max(1, base * sJourneyFishingHabitats[i].percent / 100);
    return base;
}

bool32 JourneyWildPoolAvailable(u32 area)
{
    u16 ecologyMap = JourneyAtlasEcologyOwner((gSaveBlock1Ptr->location.mapGroup << 8) | gSaveBlock1Ptr->location.mapNum);
    const struct JourneyWildPool *pools=gJourneyBuildRules.maxNational==493?sJourneyGeneration4Pools:sJourneyWildPools;
    u32 length=gJourneyBuildRules.maxNational==493?ARRAY_COUNT(sJourneyGeneration4Pools):ARRAY_COUNT(sJourneyWildPools);
    for(u32 i=0;i<length;i++)
        if(MAP_GROUP(pools[i].map)==MAP_GROUP(ecologyMap) && MAP_NUM(pools[i].map)==MAP_NUM(ecologyMap) && pools[i].area==area)return pools[i].count>0;
    return FALSE;
}
