JourneyAtlasSea000_MapScripts::
	.byte 0
JourneyAtlasScene000_MapScripts::
	.byte 0
JourneyAtlasCoast07_MapScripts::
	.byte 0
JourneyAtlasScene001_MapScripts::
	.byte 0
JourneyAtlasCoast22_MapScripts::
	.byte 0
JourneyAtlasSea005_MapScripts::
	.byte 0
JourneyAtlasSea006_MapScripts::
	.byte 0
JourneyAtlasSea007_MapScripts::
	.byte 0
JourneyAtlasSea008_MapScripts::
	.byte 0
JourneyAtlasSea009_MapScripts::
	.byte 0
JourneyAtlasSea010_MapScripts::
	.byte 0
JourneyAtlasSea011_MapScripts::
	.byte 0
JourneyAtlasSea012_MapScripts::
	.byte 0
JourneyAtlasCoast12_MapScripts::
	.byte 0
JourneyAtlasSea014_MapScripts::
	.byte 0
JourneyAtlasSea015_MapScripts::
	.byte 0
JourneyAtlasSea016_MapScripts::
	.byte 0
JourneyAtlasSea017_MapScripts::
	.byte 0
JourneyAtlasSea018_MapScripts::
	.byte 0
JourneyAtlasSea019_MapScripts::
	.byte 0
JourneyAtlasScene003_MapScripts::
	.byte 0
JourneyAtlasCoast08_MapScripts::
	.byte 0
JourneyAtlasSea022_MapScripts::
	.byte 0
JourneyAtlasScene004_MapScripts::
	.byte 0
JourneyAtlasCoast33_MapScripts::
	.byte 0
JourneyAtlasSea025_MapScripts::
	.byte 0
JourneyAtlasSea026_MapScripts::
	.byte 0
JourneyAtlasSea027_MapScripts::
	.byte 0
JourneyAtlasSea028_MapScripts::
	.byte 0
JourneyAtlasScene002_MapScripts::
	.byte 0
JourneyAtlasSea030_MapScripts::
	.byte 0
JourneyAtlasSea031_MapScripts::
	.byte 0
JourneyAtlasSea032_MapScripts::
	.byte 0
JourneyAtlasSea033_MapScripts::
	.byte 0
JourneyAtlasSea034_MapScripts::
	.byte 0
JourneyAtlasSea035_MapScripts::
	.byte 0
JourneyAtlasCave02_MapScripts::
	.byte 0
JourneyAtlasSea037_MapScripts::
	.byte 0
JourneyAtlasScene005_MapScripts::
	.byte 0
JourneyAtlasCave04_MapScripts::
	.byte 0
JourneyAtlasSea040_MapScripts::
	.byte 0
JourneyAtlasSea041_MapScripts::
	.byte 0
JourneyAtlasSea042_MapScripts::
	.byte 0
JourneyAtlasSea043_MapScripts::
	.byte 0
JourneyAtlasCoast13_MapScripts::
	.byte 0
JourneyAtlasSea045_MapScripts::
	.byte 0
JourneyAtlasSea046_MapScripts::
	.byte 0
JourneyAtlasSea047_MapScripts::
	.byte 0
JourneyAtlasSea048_MapScripts::
	.byte 0
JourneyAtlasSea049_MapScripts::
	.byte 0
JourneyAtlasCoast23_MapScripts::
	.byte 0
JourneyAtlasSea051_MapScripts::
	.byte 0
JourneyAtlasScene006_MapScripts::
	.byte 0
JourneyAtlasSea053_MapScripts::
	.byte 0
JourneyAtlasScene007_MapScripts::
	.byte 0
JourneyAtlasScene008_MapScripts::
	.byte 0
JourneyAtlasScene009_MapScripts::
	.byte 0
JourneyAtlasScene010_MapScripts::
	.byte 0
JourneyAtlasScene011_MapScripts::
	.byte 0
JourneyAtlasScene012_MapScripts::
	.byte 0
JourneyAtlasScene013_MapScripts::
	.byte 0
JourneyAtlasScene014_MapScripts::
	.byte 0
JourneyAtlasSea062_MapScripts::
	.byte 0
JourneyAtlasCave11_MapScripts::
	.byte 0
JourneyAtlasCave09_MapScripts::
	.byte 0
JourneyAtlasSea065_MapScripts::
	.byte 0
JourneyAtlasSea066_MapScripts::
	.byte 0
JourneyAtlasSea067_MapScripts::
	.byte 0
JourneyAtlasSea068_MapScripts::
	.byte 0
JourneyAtlasCave10_MapScripts::
	.byte 0
JourneyAtlasSea070_MapScripts::
	.byte 0
JourneyAtlasSea071_MapScripts::
	.byte 0
JourneyAtlasSea072_MapScripts::
	.byte 0
JourneyAtlasSea073_MapScripts::
	.byte 0
JourneyAtlasSea074_MapScripts::
	.byte 0
JourneyAtlasSea075_MapScripts::
	.byte 0
JourneyAtlasSea076_MapScripts::
	.byte 0
JourneyAtlasSea077_MapScripts::
	.byte 0
JourneyAtlasCoast32_MapScripts::
	.byte 0
JourneyAtlasSea079_MapScripts::
	.byte 0
JourneyAtlasSea080_MapScripts::
	.byte 0
JourneyAtlasSea081_MapScripts::
	.byte 0
JourneyAtlasSea082_MapScripts::
	.byte 0
JourneyAtlasSea083_MapScripts::
	.byte 0
JourneyAtlasCoast26_MapScripts::
	.byte 0
JourneyAtlasSea085_MapScripts::
	.byte 0
JourneyAtlasCoast25_MapScripts::
	.byte 0
JourneyAtlasSea087_MapScripts::
	.byte 0
JourneyAtlasSea088_MapScripts::
	.byte 0
JourneyAtlasScene015_MapScripts::
	.byte 0
JourneyAtlasCave08_MapScripts::
	.byte 0
JourneyAtlasSea091_MapScripts::
	.byte 0
JourneyAtlasSea092_MapScripts::
	.byte 0
JourneyAtlasScene016_MapScripts::
	.byte 0
JourneyAtlasSea094_MapScripts::
	.byte 0
JourneyAtlasSea095_MapScripts::
	.byte 0
JourneyAtlasSea096_MapScripts::
	.byte 0
JourneyAtlasSea097_MapScripts::
	.byte 0
JourneyAtlasSea098_MapScripts::
	.byte 0
JourneyAtlasSea099_MapScripts::
	.byte 0
JourneyAtlasSea100_MapScripts::
	.byte 0
JourneyAtlasSea101_MapScripts::
	.byte 0
JourneyAtlasSea102_MapScripts::
	.byte 0
JourneyAtlasSea103_MapScripts::
	.byte 0
JourneyAtlasSea104_MapScripts::
	.byte 0
JourneyAtlasSea105_MapScripts::
	.byte 0
JourneyAtlasSea106_MapScripts::
	.byte 0
JourneyAtlasSea107_MapScripts::
	.byte 0
JourneyAtlasScene017_MapScripts::
	.byte 0
JourneyAtlasScene018_MapScripts::
	.byte 0
JourneyAtlasSea110_MapScripts::
	.byte 0
JourneyAtlasScene019_MapScripts::
	.byte 0
JourneyAtlasSea112_MapScripts::
	.byte 0
JourneyAtlasSea113_MapScripts::
	.byte 0
JourneyAtlasScene020_MapScripts::
	.byte 0
JourneyAtlasSea115_MapScripts::
	.byte 0
JourneyAtlasSea116_MapScripts::
	.byte 0
JourneyAtlasSea117_MapScripts::
	.byte 0
JourneyAtlasSea118_MapScripts::
	.byte 0
JourneyAtlasSea119_MapScripts::
	.byte 0
JourneyAtlasSea120_MapScripts::
	.byte 0
JourneyAtlasSea121_MapScripts::
	.byte 0
JourneyAtlasSea122_MapScripts::
	.byte 0
JourneyAtlasSea123_MapScripts::
	.byte 0
JourneyAtlasSea124_MapScripts::
	.byte 0
JourneyAtlasSea125_MapScripts::
	.byte 0
JourneyAtlasSea126_MapScripts::
	.byte 0
JourneyAtlasScene021_MapScripts::
	.byte 0
JourneyAtlasScene022_MapScripts::
	.byte 0
JourneyAtlasSea129_MapScripts::
	.byte 0
JourneyAtlasSea130_MapScripts::
	.byte 0
JourneyAtlasScene023_MapScripts::
	.byte 0
JourneyAtlasSea132_MapScripts::
	.byte 0
JourneyAtlasSea133_MapScripts::
	.byte 0
JourneyAtlasSea134_MapScripts::
	.byte 0
JourneyAtlasSea135_MapScripts::
	.byte 0
JourneyAtlasCoast27_MapScripts::
	.byte 0
JourneyAtlasSea137_MapScripts::
	.byte 0
JourneyAtlasSea138_MapScripts::
	.byte 0
JourneyAtlasSea139_MapScripts::
	.byte 0
JourneyAtlasSea140_MapScripts::
	.byte 0
JourneyAtlasScene024_MapScripts::
	.byte 0
JourneyAtlasSea142_MapScripts::
	.byte 0
JourneyAtlasSea143_MapScripts::
	.byte 0
JourneyAtlasSea144_MapScripts::
	.byte 0
JourneyAtlasSea145_MapScripts::
	.byte 0
JourneyAtlasSea146_MapScripts::
	.byte 0
JourneyAtlasSea147_MapScripts::
	.byte 0
JourneyAtlasSea148_MapScripts::
	.byte 0
JourneyAtlasSea149_MapScripts::
	.byte 0
JourneyAtlasSea150_MapScripts::
	.byte 0
JourneyAtlasScene025_MapScripts::
	.byte 0
JourneyAtlasSea152_MapScripts::
	.byte 0
JourneyAtlasSea153_MapScripts::
	.byte 0
JourneyAtlasSea154_MapScripts::
	.byte 0
JourneyAtlasSea155_MapScripts::
	.byte 0
JourneyAtlasSea156_MapScripts::
	.byte 0
JourneyAtlasSea157_MapScripts::
	.byte 0
JourneyAtlasScene026_MapScripts::
	.byte 0
JourneyAtlasScene027_MapScripts::
	.byte 0
JourneyAtlasSea160_MapScripts::
	.byte 0
JourneyAtlasSea161_MapScripts::
	.byte 0
JourneyAtlasSea162_MapScripts::
	.byte 0
JourneyAtlasSea163_MapScripts::
	.byte 0
JourneyAtlasSea164_MapScripts::
	.byte 0
JourneyAtlasSea165_MapScripts::
	.byte 0
JourneyAtlasSea166_MapScripts::
	.byte 0
JourneyAtlasSea167_MapScripts::
	.byte 0
JourneyAtlasSea168_MapScripts::
	.byte 0
JourneyAtlasCoast02_MapScripts::
	.byte 0
JourneyAtlasSea170_MapScripts::
	.byte 0
JourneyAtlasScene028_MapScripts::
	.byte 0
JourneyAtlasScene029_MapScripts::
	.byte 0
JourneyAtlasScene030_MapScripts::
	.byte 0
JourneyAtlasScene031_MapScripts::
	.byte 0
JourneyAtlasScene032_MapScripts::
	.byte 0
JourneyAtlasSea176_MapScripts::
	.byte 0
JourneyAtlasScene033_MapScripts::
	.byte 0
JourneyAtlasSea178_MapScripts::
	.byte 0
JourneyAtlasSea179_MapScripts::
	.byte 0
JourneyAtlasScene034_MapScripts::
	.byte 0
JourneyAtlasScene035_MapScripts::
	.byte 0
JourneyAtlasCave05_MapScripts::
	.byte 0
JourneyAtlasSea183_MapScripts::
	.byte 0
JourneyAtlasSea184_MapScripts::
	.byte 0
JourneyAtlasSea185_MapScripts::
	.byte 0
JourneyAtlasSea186_MapScripts::
	.byte 0
JourneyAtlasSea187_MapScripts::
	.byte 0
JourneyAtlasSea188_MapScripts::
	.byte 0
JourneyAtlasSea189_MapScripts::
	.byte 0
JourneyAtlasSea190_MapScripts::
	.byte 0
JourneyAtlasSea191_MapScripts::
	.byte 0
JourneyAtlasSea192_MapScripts::
	.byte 0
JourneyAtlasSea193_MapScripts::
	.byte 0
JourneyAtlasSea194_MapScripts::
	.byte 0
JourneyAtlasSea195_MapScripts::
	.byte 0
JourneyAtlasSea196_MapScripts::
	.byte 0
JourneyAtlasSea197_MapScripts::
	.byte 0
JourneyAtlasSea198_MapScripts::
	.byte 0
JourneyAtlasSea199_MapScripts::
	.byte 0
JourneyAtlasSea200_MapScripts::
	.byte 0
JourneyAtlasSea201_MapScripts::
	.byte 0
JourneyAtlasSea202_MapScripts::
	.byte 0
JourneyAtlasSea203_MapScripts::
	.byte 0
JourneyAtlasSea204_MapScripts::
	.byte 0
JourneyAtlasSea205_MapScripts::
	.byte 0
JourneyAtlasScene036_MapScripts::
	.byte 0
JourneyAtlasSea207_MapScripts::
	.byte 0
JourneyAtlasSea208_MapScripts::
	.byte 0
JourneyAtlasDiveMares_MapScripts::
	.byte 0
JourneyAtlasSea210_MapScripts::
	.byte 0
JourneyAtlasSea211_MapScripts::
	.byte 0
JourneyAtlasSea212_MapScripts::
	.byte 0
JourneyAtlasSea213_MapScripts::
	.byte 0
JourneyAtlasSea214_MapScripts::
	.byte 0
JourneyAtlasCoast06_MapScripts::
	.byte 0
JourneyAtlasSea216_MapScripts::
	.byte 0
JourneyAtlasSea217_MapScripts::
	.byte 0
JourneyAtlasSea218_MapScripts::
	.byte 0
JourneyAtlasSea219_MapScripts::
	.byte 0
JourneyAtlasSea220_MapScripts::
	.byte 0
JourneyAtlasScene037_MapScripts::
	.byte 0
JourneyAtlasSea222_MapScripts::
	.byte 0
JourneyAtlasSea223_MapScripts::
	.byte 0
JourneyAtlasSea224_MapScripts::
	.byte 0
JourneyAtlasSea225_MapScripts::
	.byte 0
JourneyAtlasSea226_MapScripts::
	.byte 0
JourneyAtlasScene038_MapScripts::
	.byte 0
JourneyAtlasSea228_MapScripts::
	.byte 0
JourneyAtlasSea229_MapScripts::
	.byte 0
JourneyAtlasCave12_MapScripts::
	.byte 0
JourneyAtlasCoast11_MapScripts::
	.byte 0
JourneyAtlasCave13_MapScripts::
	.byte 0
JourneyAtlasSea233_MapScripts::
	.byte 0
JourneyAtlasSea234_MapScripts::
	.byte 0
JourneyAtlasSea235_MapScripts::
	.byte 0
JourneyAtlasSea236_MapScripts::
	.byte 0
JourneyAtlasSea237_MapScripts::
	.byte 0
JourneyAtlasSea238_MapScripts::
	.byte 0
JourneyAtlasSea239_MapScripts::
	.byte 0
JourneyAtlasSea240_MapScripts::
	.byte 0
JourneyAtlasSea241_MapScripts::
	.byte 0
JourneyAtlasSea242_MapScripts::
	.byte 0
JourneyAtlasSea243_MapScripts::
	.byte 0
JourneyAtlasSea244_MapScripts::
	.byte 0
JourneyAtlasSea245_MapScripts::
	.byte 0
JourneyAtlasScene039_MapScripts::
	.byte 0
JourneyAtlasSea247_MapScripts::
	.byte 0
JourneyAtlasScene040_MapScripts::
	.byte 0
JourneyAtlasScene041_MapScripts::
	.byte 0
JourneyAtlasSea250_MapScripts::
	.byte 0
JourneyAtlasSea251_MapScripts::
	.byte 0
JourneyAtlasScene042_MapScripts::
	.byte 0
JourneyAtlasSea253_MapScripts::
	.byte 0
JourneyAtlasSea254_MapScripts::
	.byte 0
JourneyAtlasSea255_MapScripts::
	.byte 0
JourneyAtlasCave17_MapScripts::
	.byte 0
JourneyAtlasSea257_MapScripts::
	.byte 0
JourneyAtlasSea258_MapScripts::
	.byte 0
JourneyAtlasScene043_MapScripts::
	.byte 0
JourneyAtlasSea260_MapScripts::
	.byte 0
JourneyAtlasSea261_MapScripts::
	.byte 0
JourneyAtlasSea262_MapScripts::
	.byte 0
JourneyAtlasSea263_MapScripts::
	.byte 0
JourneyAtlasSea264_MapScripts::
	.byte 0
JourneyAtlasCoast15_MapScripts::
	.byte 0
JourneyAtlasSea266_MapScripts::
	.byte 0
JourneyAtlasSea267_MapScripts::
	.byte 0
JourneyAtlasSea268_MapScripts::
	.byte 0
JourneyAtlasSea269_MapScripts::
	.byte 0
JourneyAtlasScene044_MapScripts::
	.byte 0
JourneyAtlasSea271_MapScripts::
	.byte 0
JourneyAtlasCave14_MapScripts::
	.byte 0
JourneyAtlasCoast16_MapScripts::
	.byte 0
JourneyAtlasSea274_MapScripts::
	.byte 0
JourneyAtlasSea275_MapScripts::
	.byte 0
JourneyAtlasSea276_MapScripts::
	.byte 0
JourneyAtlasCoast17_MapScripts::
	.byte 0
JourneyAtlasSea278_MapScripts::
	.byte 0
JourneyAtlasSea279_MapScripts::
	.byte 0
JourneyAtlasSea280_MapScripts::
	.byte 0
JourneyAtlasScene045_MapScripts::
	.byte 0
JourneyAtlasSea282_MapScripts::
	.byte 0
JourneyAtlasSea283_MapScripts::
	.byte 0
JourneyAtlasSea284_MapScripts::
	.byte 0
JourneyAtlasSea285_MapScripts::
	.byte 0
JourneyAtlasCoast05_MapScripts::
	.byte 0
JourneyAtlasSea287_MapScripts::
	.byte 0
JourneyAtlasScene046_MapScripts::
	.byte 0
JourneyAtlasSea289_MapScripts::
	.byte 0
JourneyAtlasScene047_MapScripts::
	.byte 0
JourneyAtlasSea291_MapScripts::
	.byte 0
JourneyAtlasSea292_MapScripts::
	.byte 0
JourneyAtlasSea293_MapScripts::
	.byte 0
JourneyAtlasSea294_MapScripts::
	.byte 0
JourneyAtlasSea295_MapScripts::
	.byte 0
JourneyAtlasSea296_MapScripts::
	.byte 0
JourneyAtlasSea297_MapScripts::
	.byte 0
JourneyAtlasSea298_MapScripts::
	.byte 0
JourneyAtlasSea299_MapScripts::
	.byte 0
JourneyAtlasSea300_MapScripts::
	.byte 0
JourneyAtlasSea301_MapScripts::
	.byte 0
JourneyAtlasSea302_MapScripts::
	.byte 0
JourneyAtlasSea303_MapScripts::
	.byte 0
JourneyAtlasSea304_MapScripts::
	.byte 0
JourneyAtlasScene048_MapScripts::
	.byte 0
JourneyAtlasSea306_MapScripts::
	.byte 0
JourneyAtlasCoast09_MapScripts::
	.byte 0
JourneyAtlasSea308_MapScripts::
	.byte 0
JourneyAtlasSea309_MapScripts::
	.byte 0
JourneyAtlasScene049_MapScripts::
	.byte 0
JourneyAtlasScene050_MapScripts::
	.byte 0
JourneyAtlasSea312_MapScripts::
	.byte 0
JourneyAtlasSea313_MapScripts::
	.byte 0
JourneyAtlasScene051_MapScripts::
	.byte 0
JourneyAtlasScene052_MapScripts::
	.byte 0
JourneyAtlasScene053_MapScripts::
	.byte 0
JourneyAtlasScene054_MapScripts::
	.byte 0
JourneyAtlasScene055_MapScripts::
	.byte 0
JourneyAtlasCoast10_MapScripts::
	.byte 0
JourneyAtlasSea320_MapScripts::
	.byte 0
JourneyAtlasScene056_MapScripts::
	.byte 0
JourneyAtlasSea322_MapScripts::
	.byte 0
JourneyAtlasSea323_MapScripts::
	.byte 0
JourneyAtlasSea324_MapScripts::
	.byte 0
JourneyAtlasSea325_MapScripts::
	.byte 0
JourneyAtlasSea326_MapScripts::
	.byte 0
JourneyAtlasSea327_MapScripts::
	.byte 0
JourneyAtlasSea328_MapScripts::
	.byte 0
JourneyAtlasSea329_MapScripts::
	.byte 0
JourneyAtlasCave00_MapScripts::
	.byte 0
JourneyAtlasSea331_MapScripts::
	.byte 0
JourneyAtlasSea332_MapScripts::
	.byte 0
JourneyAtlasScene057_MapScripts::
	.byte 0
JourneyAtlasSea334_MapScripts::
	.byte 0
JourneyAtlasScene058_MapScripts::
	.byte 0
JourneyAtlasScene059_MapScripts::
	.byte 0
JourneyAtlasScene060_MapScripts::
	.byte 0
JourneyAtlasScene061_MapScripts::
	.byte 0
JourneyAtlasScene062_MapScripts::
	.byte 0
JourneyAtlasSea340_MapScripts::
	.byte 0
JourneyAtlasScene063_MapScripts::
	.byte 0
JourneyAtlasSea342_MapScripts::
	.byte 0
JourneyAtlasSea343_MapScripts::
	.byte 0
JourneyAtlasSea344_MapScripts::
	.byte 0
JourneyAtlasSea345_MapScripts::
	.byte 0
JourneyAtlasSea346_MapScripts::
	.byte 0
JourneyAtlasSea347_MapScripts::
	.byte 0
JourneyAtlasSea348_MapScripts::
	.byte 0
JourneyAtlasSea349_MapScripts::
	.byte 0
JourneyAtlasSea350_MapScripts::
	.byte 0
JourneyAtlasSea351_MapScripts::
	.byte 0
JourneyAtlasSea352_MapScripts::
	.byte 0
JourneyAtlasSea353_MapScripts::
	.byte 0
JourneyAtlasSea354_MapScripts::
	.byte 0
JourneyAtlasSea355_MapScripts::
	.byte 0
JourneyAtlasSea356_MapScripts::
	.byte 0
JourneyAtlasSea357_MapScripts::
	.byte 0
JourneyAtlasSea358_MapScripts::
	.byte 0
JourneyAtlasSea359_MapScripts::
	.byte 0
JourneyAtlasSea360_MapScripts::
	.byte 0
JourneyAtlasSea361_MapScripts::
	.byte 0
JourneyAtlasSea362_MapScripts::
	.byte 0
JourneyAtlasSea363_MapScripts::
	.byte 0
JourneyAtlasSea364_MapScripts::
	.byte 0
JourneyAtlasDiveOrigens_MapScripts::
	.byte 0
JourneyAtlasSea366_MapScripts::
	.byte 0
JourneyAtlasSea367_MapScripts::
	.byte 0
JourneyAtlasScene064_MapScripts::
	.byte 0
JourneyAtlasScene065_MapScripts::
	.byte 0
JourneyAtlasSea370_MapScripts::
	.byte 0
JourneyAtlasSea371_MapScripts::
	.byte 0
JourneyAtlasSea372_MapScripts::
	.byte 0
JourneyAtlasSea373_MapScripts::
	.byte 0
JourneyAtlasSea374_MapScripts::
	.byte 0
JourneyAtlasSea375_MapScripts::
	.byte 0
JourneyAtlasSea376_MapScripts::
	.byte 0
JourneyAtlasDiveDimensoes_MapScripts::
	.byte 0
JourneyAtlasSea378_MapScripts::
	.byte 0
JourneyAtlasCoast19_MapScripts::
	.byte 0
JourneyAtlasSea380_MapScripts::
	.byte 0
JourneyAtlasSea381_MapScripts::
	.byte 0
JourneyAtlasSea382_MapScripts::
	.byte 0
JourneyAtlasSea383_MapScripts::
	.byte 0
JourneyAtlasSea384_MapScripts::
	.byte 0
JourneyAtlasSea385_MapScripts::
	.byte 0
JourneyAtlasScene066_MapScripts::
	.byte 0
JourneyAtlasCave16_MapScripts::
	.byte 0
JourneyAtlasSea388_MapScripts::
	.byte 0
JourneyAtlasScene067_MapScripts::
	.byte 0
JourneyAtlasCave15_MapScripts::
	.byte 0
JourneyAtlasSea391_MapScripts::
	.byte 0
JourneyAtlasSea392_MapScripts::
	.byte 0
JourneyAtlasSea393_MapScripts::
	.byte 0
JourneyAtlasSea394_MapScripts::
	.byte 0
JourneyAtlasSea395_MapScripts::
	.byte 0
JourneyAtlasSea396_MapScripts::
	.byte 0
JourneyAtlasCoast18_MapScripts::
	.byte 0
JourneyAtlasScene068_MapScripts::
	.byte 0
JourneyAtlasSea399_MapScripts::
	.byte 0
JourneyAtlasSea400_MapScripts::
	.byte 0
JourneyAtlasSea401_MapScripts::
	.byte 0
JourneyAtlasScene069_MapScripts::
	.byte 0
JourneyAtlasScene070_MapScripts::
	.byte 0
JourneyAtlasCoast04_MapScripts::
	.byte 0
JourneyAtlasSea405_MapScripts::
	.byte 0
JourneyAtlasSea406_MapScripts::
	.byte 0
JourneyAtlasSea407_MapScripts::
	.byte 0
JourneyAtlasSea408_MapScripts::
	.byte 0
JourneyAtlasSea409_MapScripts::
	.byte 0
JourneyAtlasScene071_MapScripts::
	.byte 0
JourneyAtlasScene072_MapScripts::
	.byte 0
JourneyAtlasSea412_MapScripts::
	.byte 0
JourneyAtlasCoast20_MapScripts::
	.byte 0
JourneyAtlasSea414_MapScripts::
	.byte 0
JourneyAtlasScene073_MapScripts::
	.byte 0
JourneyAtlasSea416_MapScripts::
	.byte 0
JourneyAtlasSea417_MapScripts::
	.byte 0
JourneyAtlasSea418_MapScripts::
	.byte 0
JourneyAtlasSea419_MapScripts::
	.byte 0
JourneyAtlasSea420_MapScripts::
	.byte 0
JourneyAtlasSea421_MapScripts::
	.byte 0
JourneyAtlasSea422_MapScripts::
	.byte 0
JourneyAtlasCoast30_MapScripts::
	.byte 0
JourneyAtlasSea424_MapScripts::
	.byte 0
JourneyAtlasSea425_MapScripts::
	.byte 0
JourneyAtlasDiveProfundezas_MapScripts::
	.byte 0
JourneyAtlasScene074_MapScripts::
	.byte 0
JourneyAtlasScene075_MapScripts::
	.byte 0
JourneyAtlasSea429_MapScripts::
	.byte 0
JourneyAtlasSea430_MapScripts::
	.byte 0
JourneyAtlasSea431_MapScripts::
	.byte 0
JourneyAtlasSea432_MapScripts::
	.byte 0
JourneyAtlasSea433_MapScripts::
	.byte 0
JourneyAtlasSea434_MapScripts::
	.byte 0
JourneyAtlasSea435_MapScripts::
	.byte 0
JourneyAtlasSea436_MapScripts::
	.byte 0
JourneyAtlasCoast24_MapScripts::
	.byte 0
JourneyAtlasScene076_MapScripts::
	.byte 0
JourneyAtlasCoast31_MapScripts::
	.byte 0
JourneyAtlasSea440_MapScripts::
	.byte 0
JourneyAtlasSea441_MapScripts::
	.byte 0
JourneyAtlasSea442_MapScripts::
	.byte 0
JourneyAtlasSea443_MapScripts::
	.byte 0
JourneyAtlasSea444_MapScripts::
	.byte 0
JourneyAtlasSea445_MapScripts::
	.byte 0
JourneyAtlasSea446_MapScripts::
	.byte 0
JourneyAtlasSea447_MapScripts::
	.byte 0
JourneyAtlasSea448_MapScripts::
	.byte 0
JourneyAtlasSea449_MapScripts::
	.byte 0
JourneyAtlasSea450_MapScripts::
	.byte 0
JourneyAtlasSea451_MapScripts::
	.byte 0
JourneyAtlasSea452_MapScripts::
	.byte 0
JourneyAtlasCoast03_MapScripts::
	.byte 0
JourneyAtlasDiveAbismo_MapScripts::
	.byte 0
JourneyAtlasSea455_MapScripts::
	.byte 0
JourneyAtlasSea456_MapScripts::
	.byte 0
JourneyAtlasSea457_MapScripts::
	.byte 0
JourneyAtlasSea458_MapScripts::
	.byte 0
JourneyAtlasSea459_MapScripts::
	.byte 0
JourneyAtlasSea460_MapScripts::
	.byte 0
JourneyAtlasSea461_MapScripts::
	.byte 0
JourneyAtlasCoast21_MapScripts::
	.byte 0
JourneyAtlasScene077_MapScripts::
	.byte 0
JourneyAtlasSea464_MapScripts::
	.byte 0
JourneyAtlasSea465_MapScripts::
	.byte 0
JourneyAtlasSea466_MapScripts::
	.byte 0
JourneyAtlasSea467_MapScripts::
	.byte 0
JourneyAtlasSea468_MapScripts::
	.byte 0
JourneyAtlasSea469_MapScripts::
	.byte 0
JourneyAtlasSea470_MapScripts::
	.byte 0
JourneyAtlasSea471_MapScripts::
	.byte 0
JourneyAtlasSea472_MapScripts::
	.byte 0
JourneyAtlasSea473_MapScripts::
	.byte 0
JourneyAtlasSea474_MapScripts::
	.byte 0
JourneyAtlasScene078_MapScripts::
	.byte 0
JourneyAtlasScene079_MapScripts::
	.byte 0
JourneyAtlasSea477_MapScripts::
	.byte 0
JourneyAtlasCoast14_MapScripts::
	.byte 0
JourneyAtlasSea479_MapScripts::
	.byte 0
JourneyAtlasSea480_MapScripts::
	.byte 0
JourneyAtlasSea481_MapScripts::
	.byte 0
JourneyAtlasSea482_MapScripts::
	.byte 0
JourneyAtlasCoast28_MapScripts::
	.byte 0
JourneyAtlasScene080_MapScripts::
	.byte 0
JourneyAtlasSea485_MapScripts::
	.byte 0
JourneyAtlasSea486_MapScripts::
	.byte 0
JourneyAtlasCave01_MapScripts::
	.byte 0
JourneyAtlasSea488_MapScripts::
	.byte 0
JourneyAtlasSea489_MapScripts::
	.byte 0
JourneyAtlasSea490_MapScripts::
	.byte 0
JourneyAtlasSea491_MapScripts::
	.byte 0
JourneyAtlasSea492_MapScripts::
	.byte 0
JourneyAtlasSea493_MapScripts::
	.byte 0
JourneyAtlasSea494_MapScripts::
	.byte 0
JourneyAtlasSea495_MapScripts::
	.byte 0
JourneyAtlasSea496_MapScripts::
	.byte 0
JourneyAtlasScene081_MapScripts::
	.byte 0
JourneyAtlasSea498_MapScripts::
	.byte 0
JourneyAtlasSea499_MapScripts::
	.byte 0
JourneyAtlasCoast29_MapScripts::
	.byte 0
JourneyAtlasCave03_MapScripts::
	.byte 0
JourneyAtlasSea502_MapScripts::
	.byte 0
JourneyAtlasSea503_MapScripts::
	.byte 0
JourneyAtlasSea504_MapScripts::
	.byte 0
JourneyAtlasSea505_MapScripts::
	.byte 0
JourneyAtlasSea506_MapScripts::
	.byte 0
JourneyAtlasSea507_MapScripts::
	.byte 0
JourneyAtlasCoast00_MapScripts::
	.byte 0
JourneyAtlasSea509_MapScripts::
	.byte 0
JourneyAtlasSea510_MapScripts::
	.byte 0
JourneyAtlasCoast01_MapScripts::
	.byte 0
JourneyAtlasSea512_MapScripts::
	.byte 0
JourneyAtlasScene082_MapScripts::
	.byte 0
JourneyAtlasSea514_MapScripts::
	.byte 0
JourneyAtlasSea515_MapScripts::
	.byte 0
JourneyAtlasSea516_MapScripts::
	.byte 0
JourneyAtlasSea517_MapScripts::
	.byte 0
JourneyAtlasSea518_MapScripts::
	.byte 0
JourneyAtlasSea519_MapScripts::
	.byte 0
JourneyAtlasSea520_MapScripts::
	.byte 0
JourneyAtlasSea521_MapScripts::
	.byte 0
JourneyAtlasSea522_MapScripts::
	.byte 0
JourneyAtlasSea523_MapScripts::
	.byte 0
JourneyAtlasSea524_MapScripts::
	.byte 0
JourneyAtlasCave06_MapScripts::
	.byte 0
JourneyAtlasCave07_MapScripts::
	.byte 0
JourneyAtlasSea527_MapScripts::
	.byte 0
JourneyAtlasSea528_MapScripts::
	.byte 0
JourneyAtlasSea529_MapScripts::
	.byte 0
JourneyAtlasSea530_MapScripts::
	.byte 0
JourneyAtlasSea531_MapScripts::
	.byte 0
JourneyAtlasSea004_MapScripts::
	.byte 0
JourneyAtlasSea013_MapScripts::
	.byte 0
JourneyAtlasSea021_MapScripts::
	.byte 0
JourneyAtlasSea029_MapScripts::
	.byte 0
JourneyAtlasSea036_MapScripts::
	.byte 0
JourneyAtlasSea038_MapScripts::
	.byte 0
JourneyAtlasSea044_MapScripts::
	.byte 0
JourneyAtlasSea050_MapScripts::
	.byte 0
JourneyAtlasSea052_MapScripts::
	.byte 0
JourneyAtlasSea054_MapScripts::
	.byte 0
JourneyAtlasSea056_MapScripts::
	.byte 0
JourneyAtlasSea057_MapScripts::
	.byte 0
JourneyAtlasSea058_MapScripts::
	.byte 0
JourneyAtlasSea078_MapScripts::
	.byte 0
JourneyAtlasSea084_MapScripts::
	.byte 0
JourneyAtlasSea086_MapScripts::
	.byte 0
JourneyAtlasSea090_MapScripts::
	.byte 0
JourneyAtlasSea093_MapScripts::
	.byte 0
JourneyAtlasSea108_MapScripts::
	.byte 0
JourneyAtlasSea109_MapScripts::
	.byte 0
JourneyAtlasSea111_MapScripts::
	.byte 0
JourneyAtlasSea127_MapScripts::
	.byte 0
JourneyAtlasSea128_MapScripts::
	.byte 0
JourneyAtlasSea131_MapScripts::
	.byte 0
JourneyAtlasSea151_MapScripts::
	.byte 0
JourneyAtlasSea158_MapScripts::
	.byte 0
JourneyAtlasSea159_MapScripts::
	.byte 0
JourneyAtlasSea169_MapScripts::
	.byte 0
JourneyAtlasSea171_MapScripts::
	.byte 0
JourneyAtlasSea172_MapScripts::
	.byte 0
JourneyAtlasSea173_MapScripts::
	.byte 0
JourneyAtlasSea174_MapScripts::
	.byte 0
JourneyAtlasSea180_MapScripts::
	.byte 0
JourneyAtlasSea206_MapScripts::
	.byte 0
JourneyAtlasSea209_MapScripts::
	.byte 0
JourneyAtlasSea215_MapScripts::
	.byte 0
JourneyAtlasSea221_MapScripts::
	.byte 0
JourneyAtlasSea227_MapScripts::
	.byte 0
JourneyAtlasSea230_MapScripts::
	.byte 0
JourneyAtlasSea246_MapScripts::
	.byte 0
JourneyAtlasSea248_MapScripts::
	.byte 0
JourneyAtlasSea249_MapScripts::
	.byte 0
JourneyAtlasSea259_MapScripts::
	.byte 0
JourneyAtlasSea265_MapScripts::
	.byte 0
JourneyAtlasSea270_MapScripts::
	.byte 0
JourneyAtlasSea272_MapScripts::
	.byte 0
JourneyAtlasSea273_MapScripts::
	.byte 0
JourneyAtlasSea286_MapScripts::
	.byte 0
JourneyAtlasSea288_MapScripts::
	.byte 0
JourneyAtlasSea305_MapScripts::
	.byte 0
JourneyAtlasSea307_MapScripts::
	.byte 0
JourneyAtlasSea310_MapScripts::
	.byte 0
JourneyAtlasSea316_MapScripts::
	.byte 0
JourneyAtlasSea317_MapScripts::
	.byte 0
JourneyAtlasSea341_MapScripts::
	.byte 0
JourneyAtlasSea365_MapScripts::
	.byte 0
JourneyAtlasSea368_MapScripts::
	.byte 0
JourneyAtlasSea369_MapScripts::
	.byte 0
JourneyAtlasSea377_MapScripts::
	.byte 0
JourneyAtlasSea413_MapScripts::
	.byte 0
JourneyAtlasSea415_MapScripts::
	.byte 0
JourneyAtlasSea423_MapScripts::
	.byte 0
JourneyAtlasSea437_MapScripts::
	.byte 0
JourneyAtlasSea453_MapScripts::
	.byte 0
JourneyAtlasSea463_MapScripts::
	.byte 0
JourneyAtlasSea475_MapScripts::
	.byte 0
JourneyAtlasSea478_MapScripts::
	.byte 0
JourneyAtlasSea483_MapScripts::
	.byte 0
JourneyAtlasSea487_MapScripts::
	.byte 0
JourneyAtlasSea497_MapScripts::
	.byte 0
JourneyAtlasSea500_MapScripts::
	.byte 0
JourneyAtlasSea508_MapScripts::
	.byte 0
JourneyAtlasSea525_MapScripts::
	.byte 0
JourneyAtlasSea532_MapScripts::
	.byte 0
