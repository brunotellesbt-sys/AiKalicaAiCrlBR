# Earlier concept references

Native captures and evidence are included. Earlier concept images remain in the repository to keep this four-ROM archive below GitHub's file-size limit.

- [docs/design/proposta-acabamento-ilhas-lilycove-dewford.png](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/design/proposta-acabamento-ilhas-lilycove-dewford.png)
- [docs/design/proposta-acabamento-three-six-fallarbor.png](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/design/proposta-acabamento-three-six-fallarbor.png)
- [docs/design/proposta-frente-livre-treinadores.png](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/design/proposta-frente-livre-treinadores.png)
- [docs/design/proposta-gba-portos-ginasios.png](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/design/proposta-gba-portos-ginasios.png)
- [docs/design/proposta-guia-entrada-e-temas.png](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/design/proposta-guia-entrada-e-temas.png)
- [docs/design/proposta-gym-quatro-batalhas-obrigatorias.png](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/design/proposta-gym-quatro-batalhas-obrigatorias.png)
- [docs/design/proposta-gym-quatro-treinadores.png](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/design/proposta-gym-quatro-treinadores.png)
- [docs/design/proposta-ilha6-rampa-e-acesso-gym.png](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/design/proposta-ilha6-rampa-e-acesso-gym.png)
- [docs/design/proposta-interiores-diversificados.png](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/design/proposta-interiores-diversificados.png)
- [docs/design/proposta-montanha-lavender.png](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/design/proposta-montanha-lavender.png)
- [docs/design/proposta-oito-formatos-distintos.png](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/design/proposta-oito-formatos-distintos.png)
- [docs/design/proposta-sevii-surf-e-visao-treinadores.png](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/design/proposta-sevii-surf-e-visao-treinadores.png)
- [docs/images/fallarbor/proposal.png](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/images/fallarbor/proposal.png)
- [docs/images/harbor-concept-reference.png](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/images/harbor-concept-reference.png)
- [docs/images/island-harbors/Dewford-shore-reference.png](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/images/island-harbors/Dewford-shore-reference.png)
