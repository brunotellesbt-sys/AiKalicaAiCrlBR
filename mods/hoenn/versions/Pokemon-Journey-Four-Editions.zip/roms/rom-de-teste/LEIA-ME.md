# TESTE — candidata172

Esta ROM foi recompilada com as modificações atuais e mantém a supressão de
encounters e abordagens automáticas. A bateria incluída foi salva pelo menu na
ROM nova e passou novamente pelo Continue. A validação global da geografia
continua pendente; consulte [o manifesto](../CANDIDATA-172.json) e a
[continuidade técnica](../../docs/CONTINUIDADE-TECNICA-IA.md).

# ROM de teste da campanha e das rotas

Esta ROM inclui a [camada 171](../../docs/generated-area-review.md): canal vertical ao sul de One Island ligado ao mar horizontal, limites e rochas dos portos, câmeras e caverna Horizonte corrigidos. Mantém a mesma campanha das normais e conserva encontros aleatórios e abordagens automáticas desativados. [Registro em TXT](../../errors/2026-11-07-generated-area-review.txt).

Conserva a [campanha da camada 164](../../docs/badge-story.md): competição da 18ª insígnia que libera as duas Ligas, Galactic na 22ª, rivais por personagem e região inicial e Eren/Luffy na escala dos outros rivais. Mantém os 24 ginásios e as [correções costeiras da camada 163](../../docs/coastal-closures.md), incluindo praias animadas e retorno de Surf aos píeres. A abertura é testada sem save e com a bateria de inspeção desta pasta.

Abra `Pokemon-Journey-TESTE.gba` no emulador. Esta edição deriva de Gen1–9 Normal e contém as mesmas rotas, portos e cavernas das quatro ROMs normais.

A tela azul relatada não foi reproduzida no mGBA com os arquivos desta entrega, abrindo sem save e usando Continue com o save abaixo. A causa específica no My Boy permanece sem confirmação; [relatórios e capturas atuais](../../mods/hoenn/generated-area-review-validation/editions/TESTE/cold-boot/).

No player do GitHub Pages, selecione **TESTE · Explore without encounters**. O navegador confere o arquivo atual e mantém um save separado das quatro edições normais.

Os treinadores não abordam o personagem. Não há encontros aleatórios na grama, no Surf ou nas cavernas, nem por pesca, Sweet Scent ou Rock Smash. Conversar com treinadores e confirmar desafios nos altares continua funcionando. A competição e os eventos obrigatórios de campanha também continuam ativos; esta edição não pula sua progressão.

Para revisar rapidamente, use também `Pokemon-Journey-TESTE.sav` com o mesmo nome da ROM. É um save de inspeção criado no emulador: começa em Mossdeep, tem as 16 insígnias e um Pokémon com Surf, Fly, Dive e Waterfall. Não representa uma campanha jogada. Cada emulador pode exigir importar o arquivo de bateria `.sav`.

Esta ROM possui nome e código próprios e fica separada das quatro edições normais. Mantenha seu save de campanha na edição original. As ROMs normais conservam encontros e abordagens de treinadores.

Os lendários dos oito locais novos foram redistribuídos das cavernas mais cheias. Não há duplicação: as 105 espécies especiais, os registros de captura e a exigência das 16 insígnias foram preservados.

A barraca de Dewford e suas mecânicas acompanham as quatro edições normais. [Local, preços e serviços](../../docs/vendinha-dewford.md).
