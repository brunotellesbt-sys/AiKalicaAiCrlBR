# Pokémon Journey — quatro edições GBA

As quatro edições normais e a TESTE usam os mapas e a Pokédex validados da
camada 172. Nas normais, as sete ilhas com famílias terrestres agora têm
encontros na areia e locais correspondentes na Pokédex.
[Provas e detalhes](../../../docs/design/atlas-functional-review-2026-11-23/README.md).

Referência da entrega anterior validada: [canal sul de One Island, portos e cavernas — camada 171](../../../docs/generated-area-review.md). Liga a rota vertical ao mar horizontal sem redesenhar o mapa-múndi, corrige rochas, cantos e limites dos portos e conserva o retorno do Surf aos sete cais. Fecha entradas inativas da caverna Horizonte. A TESTE mantém os mesmos mapas, sem encontros aleatórios nem abordagem automática de treinadores. [Causas, soluções e prevenção em TXT](../../../errors/2026-11-07-generated-area-review.txt).

Conserva a [competição da 18ª insígnia, rivais e capítulo Galactic na 22ª](../../../docs/badge-story.md). A vitória na competição da Battle Frontier libera as duas Ligas com 18 insígnias; o capítulo Galactic passa para 22. Os rivais seguem o personagem e a região inicial, e os sprites de Eren e Luffy usam a escala dos outros rivais.

Conserva os [24 ginásios](../../../docs/ginasios-extras-e-travessias.md), os dois atendentes de Dewford e os sete terminais integrados às pontes das Sevii. Mantém as [encostas completas e praias animadas](../../../docs/coastal-closures.md). As quatro edições e a TESTE recebem a mesma campanha e os mesmos mapas.

Inclui [casas e feira de Mega Stones em Ever Grande](../../../docs/ever-grande-market.md), dois presentes únicos e Sootopolis com marcador vermelho. Inclui as formas Origin do PR #93, o mercado competitivo no exterior da Battle Frontier e o Hyper Training em Dewford.

Inclui a [correção do rio de Fallarbor](../../../docs/fallarbor-river.md): praia caminhável, margens completas e desembarque para a cidade.
[Formas Origin](../../../docs/formas-origin.md): Adamant Orb, Lustrous Orb e Griseous Orb agora também transformam ao equipar.

[Mercado externo da Battle Frontier](../../../docs/vendinha-dewford.md): 71 itens competitivos e Bottle Caps com um vendedor. O Hyper Training permanece em Dewford.

[48 câmaras nomeadas](../../../docs/cavernas-lendarias.md): todos os 105 lendários e especiais distribuídos por grupos relacionados.

[Oceano integrado e seis ligações do mapa](../../../docs/oceano-integrado.md): Surf aberto com bordas de pedra, preservando Mossdeep e Dewford do PR #90.

[Portos de Mossdeep e Dewford](../../../docs/portos-mossdeep-dewford.md): terminal original, ponte suspensa com escadas, terreno revisado e imagens com coordenadas.

[Novos terminais de Cinnabar, Cerulean e Petalburg](../../../docs/portos-cinnabar-cerulean-petalburg.md): fachadas nas coordenadas indicadas, navio interno e barco médio junto às pontes.

[Porto de Fuchsia / Rota 19](../../../docs/porto-fuchsia.md): terminal vermelho sobre a água, navio interno, um barqueiro dentro e barco médio junto à ponte.

[Novo porto de Sootopolis](../../../docs/porto-sootopolis.md): ponte ligada à terra,
terminal com capitão da rede mundial e submarino ampliado. Validado nas quatro edições.

Escolha uma edição e mantenha um backup do save original. Saves anteriores à ampliação da Bag usam outro formato e exigem Nova Partida. A revisão171 anterior validou uma bateria 168 no cais de Treasure Beach: a posição acompanha a ampliação uma única vez, inclusive após salvar e continuar novamente. Essa prova não certifica todas as builds antigas. Todas as edições possuem Kanto, Hoenn, Sevii e o capítulo Galactic.

No repositório, as quatro ROMs atuais também ficam em [`roms/`](../../../roms/README.md), com os mesmos hashes do [manifesto](versions.json).

| Edição | Pokémon | IVs dos oponentes importantes |
|---|---|---|
| [Gen 1–4 Normal](Pokemon-Journey-Gen1-4-Normal.gba) | Até #493, incluindo Megas e formas regionais correspondentes | Aleatórios |
| [Gen 1–4 Hard](Pokemon-Journey-Gen1-4-Hard.gba) | Até #493, incluindo Megas e formas regionais correspondentes | 31 |
| [Gen 1–9 Normal](Pokemon-Journey-Gen1-9-Normal.gba) | Até #1025 | Aleatórios |
| [Gen 1–9 Hard](Pokemon-Journey-Gen1-9-Hard.gba) | Até #1025 | 31 |

[Baixar as quatro edições em ZIP](Pokemon-Journey-Four-Editions.zip). [SHA-256](SHA256SUMS). [Manifesto e evidências](versions.json).

O ZIP contém exatamente as quatro ROMs normais. A [TESTE atual é um download separado](../../../roms/rom-de-teste/LEIA-ME.md), também disponível no player. Dentro do ZIP, `TESTE-DOWNLOAD.md` informa seu link e SHA-256; os metadados, a lista de checksum e o save de bateria da TESTE acompanham o pacote. As provas e capturas atuais estão incluídas. Os relatórios históricos da171 continuam no histórico Git e em `mods/hoenn/atlas-surf-layout-validation/baseline`, com seus hashes originais. O ZIP não representa uma reprodução offline de todo o histórico.

Rivais, líderes, Elite Four, campeões, chefes e administradores recebem builds competitivas, 510 EVs e IA avançada nas duas dificuldades. Treinadores comuns preservam o tratamento comum. Treinadores comuns usam a média atual −5/+2, inclusive dentro dos ginásios. Líderes usam −1/+5 e o principal fica obrigatoriamente em +5; quantidades continuam por ordem regional. Evoluções e golpes respeitam o nível final.

Os 16 ginásios originais conservam a ordem regional. Os oito extras consideram o total de insígnias e têm quatro treinadores em passagens obrigatórias. As duas Ligas exigem 18 insígnias e vitória na competição da Frontier; o circuito de 24 continua disponível. No player, a opção **TESTE** acompanha esta atualização, com save separado e sem encontros selvagens nem abordagens automáticas; conversar para desafiar continua possível.

Red, Leaf, Brendan e May podem começar em qualquer região. Surf, Dive e Waterfall são entregues pela família; Fly é o quarto HM. Os demais antigos HMs são TMs reutilizáveis, sem barreiras terrestres. As cavernas são iluminadas.

Leia o [guia completo](../../../docs/README.md), o [DOCX das equipes](../../../docs/equipes-ginasios-quatro-versoes.docx) e os [limites da validação](../INTEGRATION-STATUS.md). O jogo pode ser aberto num emulador GBA com flash de 128 KiB ou no player do GitHub Pages. Guarde backups dos saves.

[Imagens dos portos e detalhes desta atualização](../../../docs/atualizacao-costeira.md). As validações de PWT/mecânicas do PR #79 foram preservadas como históricas; a campanha inteira não foi jogada novamente nesta entrega.

[Atlas, oito viagens pelos mares e pontos das cavernas](../../../docs/navegacao-e-pendencias-finais.md). O GPS não altera níveis ou equipes; os recursos de nível 100 e repel mostrados nas viagens pertencem exclusivamente aos testes.

[Revisão das rotas e oito cavernas](../../../docs/revisao-surf-cavernas.md). A [ROM de teste separada](../../../roms/rom-de-teste/LEIA-ME.md) inclui um save de inspeção em Mossdeep, sem encontros aleatórios nem abordagem automática de treinadores. As quatro edições normais conservam essas batalhas.
