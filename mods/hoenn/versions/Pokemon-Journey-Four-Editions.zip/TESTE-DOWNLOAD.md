# Separate exploration edition

This archive contains the four normal editions. The current TESTE ROM is published separately at https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/tree/feat/coastal-habitat-polish/roms/rom-de-teste.

File: `Pokemon-Journey-TESTE.gba`

SHA-256: `5f31cf1886580efed0a0fc9b0e93d6bde9d7853be86646ae3e65b5aaf8702ccc`

Its current review metadata, checksum list and native battery save are included under `roms/rom-de-teste/`.
