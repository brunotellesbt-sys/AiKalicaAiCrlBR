# Separate exploration edition

This archive contains the four normal editions. The current TESTE ROM is published separately at https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/tree/fix/coast-scenery-review/roms/rom-de-teste.

File: `Pokemon-Journey-TESTE.gba`

SHA-256: `00bf3d1a221128382e70fa556076421c8ccabc2f401aceb891828c2af5ae40af`

Its current review metadata, checksum list and native battery save are included under `roms/rom-de-teste/`.
