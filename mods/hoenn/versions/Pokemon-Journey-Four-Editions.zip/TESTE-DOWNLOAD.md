# Separate exploration edition

This archive contains the four normal editions. The current TESTE ROM is published separately at https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/tree/fix/generated-world-audit/roms/rom-de-teste.

File: `Pokemon-Journey-TESTE.gba`

SHA-256: `57874edc8472deb479410ac4e7f35d12e6cd49e45cd38fbbfade7640c3a68b88`

Its current review metadata, checksum list and native battery save are included under `roms/rom-de-teste/`.
