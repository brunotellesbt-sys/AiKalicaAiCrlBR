# TESTE da candidata172

https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/raw/refs/heads/fix/atlas-surf-layout/roms/rom-de-teste/Pokemon-Journey-TESTE.gba

SHA-256: b7445c29804f36f188e0b753849ac4bb55fa605218c7486c04ee73d3fc7945ae

O save e os metadados acompanham este ZIP. Validacao global pendente.
