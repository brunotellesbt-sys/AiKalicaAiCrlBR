# Edição TESTE

O save de inspeção da TESTE está em roms/rom-de-teste/. Baixe a ROM TESTE correspondente na pasta roms/rom-de-teste do repositório. O SHA-256 consta em roms/rom-de-teste/review.json.
