# Separate exploration edition

This archive contains the four normal editions. The current TESTE ROM is published separately at https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/tree/feat/badge-story-qualifier/roms/rom-de-teste.

File: `Pokemon-Journey-TESTE.gba`

SHA-256: `be58ddd252c7ee58d7093b5620279b14c3fb1dd0fe241da23de35e35eb83fc61`

Its current review metadata, checksum list and native battery save are included under `roms/rom-de-teste/`.
