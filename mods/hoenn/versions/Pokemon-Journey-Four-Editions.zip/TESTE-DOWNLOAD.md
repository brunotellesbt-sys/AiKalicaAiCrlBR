# Separate exploration edition

This archive contains the four normal editions. The current TESTE ROM is published separately at https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/tree/fix/sevii-surf-boundaries/roms/rom-de-teste.

File: `Pokemon-Journey-TESTE.gba`

SHA-256: `091bc942a46356f73f7427306f297bf6640135a66b353dda815d43a30e89bcff`

Its current review metadata, checksum list and native battery save are included under `roms/rom-de-teste/`.
