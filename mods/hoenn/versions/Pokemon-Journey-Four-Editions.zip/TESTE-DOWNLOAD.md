# Separate exploration edition

This archive contains the four normal editions. The current TESTE ROM is published separately at https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/tree/fix/sevii-complete-coastlines/roms/rom-de-teste.

File: `Pokemon-Journey-TESTE.gba`

SHA-256: `678906d4fe351826a93aa4c2153a63ca8761e8b7f5e596395d5987df53eccae6`

Its current review metadata, checksum list and native battery save are included under `roms/rom-de-teste/`.
