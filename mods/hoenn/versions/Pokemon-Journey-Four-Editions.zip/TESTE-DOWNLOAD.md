# Separate exploration edition

This archive contains the four normal editions. The current TESTE ROM is published separately at https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/tree/fix/campaign-continuity-and-coast-cameras/roms/rom-de-teste.

File: `Pokemon-Journey-TESTE.gba`

SHA-256: `eacf2ae0ab3303e03e5f44aedcfa6fb7800de43ca48dbe059605e11163af2ae5`

Its current review metadata, checksum list and native battery save are included under `roms/rom-de-teste/`.
