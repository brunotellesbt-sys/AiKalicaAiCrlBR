# Separate exploration edition

This archive contains the four normal editions. The current TESTE ROM is published separately at https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/tree/fix/generated-area-review/roms/rom-de-teste.

File: `Pokemon-Journey-TESTE.gba`

SHA-256: `6eadb2619706d1ce503e26f7b24c4e98a07d81a5617bffd115c04f227c4a4fe6`

Its current review metadata, checksum list and native battery save are included under `roms/rom-de-teste/`.
