# TESTE da candidata172

https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/raw/refs/heads/fix/atlas-continuity-2026-11-16/roms/rom-de-teste/Pokemon-Journey-TESTE.gba

SHA-256: 3e32bea09c224fe9994aad5fe18eb13b4876ef0b5dbbe0324b52b638536f5a4d

O save e os metadados acompanham este ZIP. Validacao global pendente.
