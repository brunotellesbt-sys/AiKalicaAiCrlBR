# Separate exploration edition

This archive contains the four normal editions. The current TESTE ROM is published separately at https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/tree/feat/coastal-habitat-polish/roms/rom-de-teste.

File: `Pokemon-Journey-TESTE.gba`

SHA-256: `1943be74943ed91e160cba85cacfa6e5d5910738041d41dc08c42319802da5d9`

Its current review metadata, checksum list and native battery save are included under `roms/rom-de-teste/`.
