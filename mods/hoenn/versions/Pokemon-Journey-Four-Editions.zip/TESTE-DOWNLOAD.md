# TESTE da candidata172

https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/raw/refs/heads/fix/atlas-continuity-2026-11-16/roms/rom-de-teste/Pokemon-Journey-TESTE.gba

SHA-256: d95b2053e11fcae542319f242bf88ba2b03dee7a159bc99570e70dc916c215ab

O save e os metadados acompanham este ZIP. Validacao global pendente.
