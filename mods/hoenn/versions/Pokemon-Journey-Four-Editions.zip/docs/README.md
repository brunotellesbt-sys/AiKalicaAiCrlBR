# Pokémon Journey — documentação do jogo

Kanto, Hoenn e Sevii formam um mundo conectado por rotas marítimas. O jogo e seus diálogos estão em inglês; este guia está em português.

As quatro edições são Gen 1–4 Normal, Gen 1–4 Hard, Gen 1–9 Normal e Gen 1–9 Hard. As edições até a geração 4 permitem Megas e formas regionais das espécies com número nacional até 493, mas não suas evoluções de gerações posteriores.

As quatro ROMs atuais ficam em [`roms/`](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/tree/main/roms), atualizadas pelo empacotamento. O pacote com guias está em [instruções das quatro edições](../START-HERE.md).

- [História e missões obrigatórias](historia-e-missoes.md)
- [Batalhas, níveis e regras](batalhas-e-regras.md)
- [PWT — torneios, arena, builds temporárias e validação](pwt-em-desenvolvimento.md)
- [Encontros por local — Gen 1–4](encontros-gen1-4.md)
- [Encontros por local — Gen 1–9](encontros-gen1-9.md)
- [Lendários, míticos e Paradoxos](lendarios-miticos-paradoxos.md)
- [Itens, Mega Stones e evoluções](itens-e-evolucoes.md)
- [Equipes dos ginásios nas quatro edições — DOCX](equipes-ginasios-quatro-versoes.docx)
- [Equipes extraídas das ROMs — dados completos](gym-teams-native.json)
- [Sala completa da prisão Galactic](images/team-galactic-final-room.png)
- [Detalhe das três celas](images/team-galactic-final-chamber.png)

## Começar e salvar

Escolha a edição antes de iniciar o emulador. Escolha Hoenn, Kanto ou Sevii na abertura, depois Red, Leaf, Brendan ou May, e finalmente a cidade e confirme. A aparência e o sexo do protagonista são independentes da região inicial. Na escolha da cidade, B retorna à região e “No” retorna à lista de cidades. Kanto/Sevii usam Oak e Hoenn usa Birch.

Converse com os familiares para receber Surf, Dive e Waterfall. Eles podem ser usados sem insígnias, com um Pokémon apto a aprender o golpe. A Mach Bike é a bicicleta única; obter uma em uma região impede receber outra na outra região.

Comece um save novo nesta entrega e mantenha backups. Cada edição do player web tem seu próprio save. Use o menu do jogo para salvar e o menu do emulador para exportar uma cópia; apagar os dados do navegador pode apagar seus saves.

## Controles

No navegador: setas movem, X = A, Z = B, Enter = Start, Shift = Select, A/S = L/R. No celular, use os controles do emulador. No mapa integrado, R alterna o zoom de 2×; na AREA da Pokédex, A alterna o zoom. No cartão de treinador, L/R ou Select alterna as duas páginas: oito insígnias de Hoenn e oito de Kanto, 16 no total.

As imagens da sala mostram os objetos cadastrados no mapa. No jogo, os personagens aparecem conforme a etapa da missão, e as grades se abrem durante o desfecho.

## Validação

Veja os [resultados e limites dos testes](VALIDATION.md). Os atributos extremos vistos em algumas capturas de testes são preparados apenas na memória do emulador, não nos base stats da ROM. A auditoria dos atributos abrange 1.571 espécies/formas e as Megas da referência; os registros incluem 318 habilidades e 870 itens.
