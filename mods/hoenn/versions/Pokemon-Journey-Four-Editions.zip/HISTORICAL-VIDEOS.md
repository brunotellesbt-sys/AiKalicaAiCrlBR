# Earlier native recordings

These recordings retain their original ROM identities; they are historical evidence, not tests of this release.

- [docs/videos/surf-connections-repaired.mp4](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/videos/surf-connections-repaired.mp4)
- [docs/videos/western-river-fallarbor.mp4](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/docs/videos/western-river-fallarbor.mp4)
- [mods/hoenn/extra-gyms-validation/baseline/western-river-fallarbor.mp4](https://github.com/brunotellesbt-sys/AiKalicaAiCrlBR/blob/main/mods/hoenn/extra-gyms-validation/baseline/western-river-fallarbor.mp4)
